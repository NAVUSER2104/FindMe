﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Dapper;
using Dapper.Contrib.Extensions;
using NAVDashboard.Api.Framework.Data;
using static Dapper.SqlMapper;

namespace NAVDashboard.Api.Framework.OrmWrapper
{
    public class DapperOrmDbContext : IOrmDbContext
    {
        public const int USER_ERR_BACKEND_FROM = 50000;
        public const int USER_ERR_BACKEND_UPTO = 50100;
        public const int CommandTimeOut = 1200;
        private readonly IDbConnection DbConnection;
        public DapperOrmDbContext(string dbConnectionString)
        {
            DbConnection = new SqlConnection(dbConnectionString);
        }
        
        public IEnumerable<T> ExecuteQuery<T>(string sql, object param = null, CommandType? dbCommandType = CommandType.StoredProcedure)
        {
            try
            {
                DbConnection.Open();
                return DbConnection.Query<T>(sql, param: param, commandType: dbCommandType, commandTimeout: CommandTimeOut);
            }
            finally
            {
                DbConnection.Close();
            }
        }

        public DataSet ExecuteDataSet(string sql, Dictionary<string, object> paramList, CommandType? dbCommandType = CommandType.StoredProcedure)
        {
            try
            {
                DbConnection.Open();
                return ExecuteDataSet(dbCommandType.Value, sql, GetSqlParamArrFromDict(paramList));
            }
            finally
            {
                DbConnection.Close();
            }
        }

        private DataSet ExecuteDataSet(CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            DataSet ds = new DataSet();
            PrepareCommand(cmd, null, commandType, commandText, commandParameters);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(ds);
            return ds;
        }

        private SqlParameter[] GetSqlParamArrFromDict(Dictionary<string, object> paramLst)
        {
            if (paramLst == null)
                return null;
            int iArrIndex = 0;
            SqlParameter tmpParam;
            SqlParameter[] parameterValues = new SqlParameter[paramLst.Count];

            foreach (KeyValuePair<string, object> keyValuePair in paramLst)
            {
                tmpParam = new SqlParameter(keyValuePair.Key, keyValuePair.Value);
                parameterValues[iArrIndex] = tmpParam;
                iArrIndex++;
            }
            return parameterValues;
        }

        private SqlParameter[] GetSqlParamArrFromDict(Dictionary<string, object> inputParamLst, Dictionary<string, object> outputParamLst)
        {
            if (inputParamLst == null && outputParamLst == null || (!inputParamLst.Any() && !outputParamLst.Any()))
                return null;
            int iArrIndex = 0;
            int paramCount = 0;
            if (inputParamLst != null && inputParamLst.Any())
                paramCount += inputParamLst.Count;
            if (outputParamLst != null && outputParamLst.Any())
                paramCount += outputParamLst.Count;
            SqlParameter tmpParam;
            SqlParameter[] parameterValues = new SqlParameter[paramCount];

            if (inputParamLst != null && inputParamLst.Any())
            {
                foreach (KeyValuePair<string, object> keyValuePair in inputParamLst)
                {
                    tmpParam = new SqlParameter(keyValuePair.Key, keyValuePair.Value);
                    parameterValues[iArrIndex] = tmpParam;
                    iArrIndex++;
                }
            }

            if (outputParamLst != null && outputParamLst.Any())
            {
                foreach (KeyValuePair<string, object> keyValuePair in outputParamLst)
                {
                    tmpParam = new SqlParameter(keyValuePair.Key, keyValuePair.Value);
                    tmpParam.Direction = ParameterDirection.InputOutput;
                    parameterValues[iArrIndex] = tmpParam;
                    iArrIndex++;
                }
            }
            return parameterValues;
        }

        private void PrepareCommand(SqlCommand command, SqlTransaction transaction, CommandType commandType, string commandText, SqlParameter[] commandParameters)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandText == null || commandText.Length == 0) throw new ArgumentNullException("commandText");

            // If the provided connection is not open, we will open it
            if (DbConnection.State != ConnectionState.Open)
            {
                DbConnection.Open();
            }

            // Associate the connection with the command
            command.Connection = (SqlConnection)DbConnection;

            // Set the command text (stored procedure name or SQL statement)
            command.CommandText = commandText;

            // If we were provided a transaction, assign it
            if (transaction != null)
            {
                if (transaction.Connection == null) throw new ArgumentException("The transaction was rollbacked or commited, please provide an open transaction.", "transaction");
                command.Transaction = transaction;
            }

            // Set the command type
            command.CommandType = commandType;
            //Set the Time out property
            command.CommandTimeout = 0;

            // Attach the command parameters if they are provided
            if (commandParameters != null && commandParameters.Any())
            {
                AttachParameters(command, commandParameters);
            }
        }

        public void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
        {
            if (command == null) throw new ArgumentNullException("command");
            if (commandParameters != null)
            {
                foreach (SqlParameter p in commandParameters)
                {
                    if (p != null)
                    {
                        // Check for derived output value with no value assigned
                        if ((p.Direction == ParameterDirection.InputOutput ||
                            p.Direction == ParameterDirection.Input ||
                            p.Direction == ParameterDirection.Output) &&
                            (p.Value == null))
                        {
                            p.Value = DBNull.Value;
                        }
                        command.Parameters.Add(p);
                    }
                }
            }
            // add return value parameter, its value will be checked after command execution and if it is non zero 
            // exception will be raised (mohitb, 4/21/2009)
            if (command.CommandType == CommandType.StoredProcedure)
            {
                SqlParameter retValParam = new SqlParameter();
                retValParam.ParameterName = "RetVal";
                retValParam.Direction = ParameterDirection.ReturnValue;
                command.Parameters.Add(retValParam);
            }
        }

        public Tuple<IEnumerable<T1>, IEnumerable<T2>> GetMultiple<T1, T2>(Func<GridReader, IEnumerable<T1>> func1, Func<GridReader, IEnumerable<T2>> func2, string sql, object param = null, CommandType? dbCommandType = CommandType.StoredProcedure)
        {
            var objs = getMultiple(sql, param, dbCommandType.Value, func1, func2);
            return Tuple.Create(objs[0] as IEnumerable<T1>, objs[1] as IEnumerable<T2>);
        }


        private List<object> getMultiple(string sql, object param, CommandType dbCommandType, params Func<GridReader, object>[] readerFuncs)
        {
            var returnResults = new List<object>();
            try
            {
                DbConnection.Open();
                var gridReader = DbConnection.QueryMultiple(sql, param: param, commandType: dbCommandType, commandTimeout: CommandTimeOut);

                foreach (var readerFunc in readerFuncs)
                {
                    var obj = readerFunc(gridReader);
                    returnResults.Add(obj);
                }
            }
            finally
            {
                DbConnection.Close();
            }

            return returnResults;
        }

        public dynamic ExecuteNonQuery(string sql, object param = null, CommandType? dbCommandType = null)
        {
            try
            {
                DbConnection.Open();
                return DbConnection.Execute(sql, param: param, commandType: dbCommandType, commandTimeout: 300);
            }
            finally
            {
                DbConnection.Close();
            }
        }

        public List<object> GetMultiple(string sql, object param, CommandType dbCommandType, params Func<GridReader, object>[] readerFuncs)
        {
            var returnResults = new List<object>();
            try
            {
                DbConnection.Open();
                var gridReader = DbConnection.QueryMultiple(sql, param: param, commandType: dbCommandType, commandTimeout: CommandTimeOut);

                foreach (var readerFunc in readerFuncs)
                {
                    var obj = readerFunc(gridReader);
                    returnResults.Add(obj);
                }
            }
            finally
            {
                DbConnection.Close();
            }

            return returnResults;
        }

        public DataSet ExecuteDataSet(string sql, Dictionary<string, object> inputParamList, ref Dictionary<string, object> outputParamList, ref string errMsg, CommandType? dbCommandType = CommandType.StoredProcedure)
        {
            try
            {
                DbConnection.Open();
                return ExecuteDataSet(dbCommandType.Value, sql, ref outputParamList, GetSqlParamArrFromDict(inputParamList, outputParamList));
            }
            catch (SqlException ex)
            {
                if (ex.Number > USER_ERR_BACKEND_FROM && ex.Number < USER_ERR_BACKEND_UPTO)
                {
                    errMsg = ex.Message;
                    return new DataSet();
                }

                throw;
            }
            finally
            {
                DbConnection.Close();
            }
        }
        private DataSet ExecuteDataSet(CommandType commandType, string commandText, ref Dictionary<string, object> outputParamList, params SqlParameter[] commandParameters)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            DataSet ds = new DataSet();
            PrepareCommand(cmd, null, commandType, commandText, commandParameters);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            adapter.Fill(ds);

            if (outputParamList != null && outputParamList.Any())
            {
                foreach (KeyValuePair<string, object> keyValuePair in outputParamList.ToList())
                {
                    outputParamList[keyValuePair.Key] = cmd.Parameters[keyValuePair.Key].Value;
                }
            }

            return ds;
        }

        public int ExecuteNonQuery(string sql, object param)
        {
            try
            {
                DbConnection.Open();
                return DbConnection.Execute(sql, param, null, null, CommandType.StoredProcedure);
            }
            finally
            {
                DbConnection.Close();
            }
        }


        public T ExecuteScalar<T>(string sql, object param = null, CommandType? dbCommandType = CommandType.StoredProcedure)
        {
            try
            {
                DbConnection.Open();
                return DbConnection.ExecuteScalar<T>(sql, param: param, commandType: dbCommandType, commandTimeout: CommandTimeOut);
            }
            finally
            {
                DbConnection.Close();
            }
        }  
    }

}
