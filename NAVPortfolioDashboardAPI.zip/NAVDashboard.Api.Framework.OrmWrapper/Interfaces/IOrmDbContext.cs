﻿using System;
using System.Collections.Generic;
using System.Text; 
using System.Data;
using static Dapper.SqlMapper;
using System.Data.SqlClient;
using NAVDashboard.Api.Framework.Data;

namespace NAVDashboard.Api.Framework.OrmWrapper
{
    public interface IOrmDbContext
    {
        IEnumerable<T> ExecuteQuery<T>(string sql, object param = null, CommandType? commandType = CommandType.StoredProcedure);
        int ExecuteNonQuery(string sql, object param);
        Tuple<IEnumerable<T1>, IEnumerable<T2>> GetMultiple<T1, T2>(Func<GridReader, IEnumerable<T1>> func1, Func<GridReader, IEnumerable<T2>> func2, string sql, object param = null, CommandType? dbCommandType = CommandType.StoredProcedure);
        DataSet ExecuteDataSet(string sql, Dictionary<string, object> paramList, CommandType? dbCommandType = CommandType.StoredProcedure);
        List<object> GetMultiple(string sql, object param, CommandType dbCommandType, params Func<GridReader, object>[] readerFuncs);
        DataSet ExecuteDataSet(string sql, Dictionary<string, object> inputParamList, ref Dictionary<string, object> outputParamList, ref string ErrMsg, CommandType? dbCommandType = CommandType.StoredProcedure);
        T ExecuteScalar<T>(string sql, object param = null, CommandType? dbCommandType = CommandType.StoredProcedure); 
    }
}
