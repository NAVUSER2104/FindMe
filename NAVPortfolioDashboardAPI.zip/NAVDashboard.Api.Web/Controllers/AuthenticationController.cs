﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.BusinessLayer;
using NAVDashboard.Api.Framework.Data;
using System;

namespace NAVDashboard.Api.Web.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly IAuthenticationBusiness _authenticateBusiness;
        private readonly ILogger<AuthenticationController> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AuthenticationController(IAuthenticationBusiness portfolioBusiness, ILogger<AuthenticationController> logger, IHttpContextAccessor httpContextAccessor)
        {
            _authenticateBusiness = portfolioBusiness;
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }


        [HttpGet]
        public string Ping()
        {
            return "Grettings!! APIStatus API is up";
        }

        
        [AllowAnonymous]       
        [HttpGet]
        public IActionResult Login(string userName)
        {

            _logger.LogInformation($"Login Start Request" + userName);

            IActionResult response = Unauthorized();
            var userData = _authenticateBusiness.AuthenticateUser(userName);

            if (userData != null)
            {
                var tokenString = _authenticateBusiness.GenerateJSONWebToken(userData);
                response = Ok(new { access_token = tokenString });
            }


            _logger.LogInformation($"Login ENd Request" + userName);
            return response;
        }

        
        [HttpGet]        
        public ActionResult<Users> GetUserAdDetails()
        {
            try
            {
                var userName = _authenticateBusiness.GetUserName(_httpContextAccessor);
                if (userName == null)
                {
                    _logger.LogInformation($"Error occured while fetching the username for GetUserAdDetails.");
                    return NotFound();
                }
                _logger.LogInformation($"Method GetADUserByUserName called for username: {userName}");

                var result = _authenticateBusiness.FetchUserDetailsByUserName(userName);
                if (result.UserName == null)
                    return Ok("User does not exist with userName :" + userName);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occured while fetching the user details by UserName.");
                return StatusCode(500, ex.InnerException != null ? ex.InnerException.Message : ex.Message);
            }
        }
    }
}