﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.BusinessLayer;
using NAVDashboard.Api.Framework.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NAVDashboard.Api.Web.Controllers
{
     [Route("api/[controller]/[action]")]
     [ApiController]
     public class ClientwiseDeliveryLogController : ControllerBase
     {
          private readonly IClientwiseDeliveryLogBusiness _clientwiseDeliveryLogBusiness;
          private readonly ILogger<ClientwiseDeliveryLogController> _logger;

          public ClientwiseDeliveryLogController(IClientwiseDeliveryLogBusiness clientwiseDeliveryLogBusiness, ILogger<ClientwiseDeliveryLogController> logger)
          {
               _clientwiseDeliveryLogBusiness = clientwiseDeliveryLogBusiness;
               _logger = logger;
          }

          [HttpGet]
          public string Ping()
          {
               return "Grettings!! ClientwiseDeliveryLog API is up";
          }

          [HttpGet]
          public IActionResult GetClientwiseDeliveryLog(DateTime asOfDateTime)
          {
               try
               {
                    return Ok(new { Data = _clientwiseDeliveryLogBusiness.GetClientwiseDeliveryLog(asOfDateTime) });
               }
               catch (Exception ex)
               {
                    _logger.LogError("Error in Method GetClientwiseDeliveryLog:-" + ex.ToString());
                    return StatusCode(500, new { Data = ex.Message });
               }
          }

        [HttpGet]
        public IActionResult GetClientPortfolioStatus(DateTime asOfDateTime)
        {
            try
            {
                return Ok(new { Data = _clientwiseDeliveryLogBusiness.GetClientPortfolioStatus(asOfDateTime) });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetClientPortfolioStatus:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }

        [HttpGet]
        public IActionResult GetClientFundSetupDetail()
        {
            try
            {
                return Ok( _clientwiseDeliveryLogBusiness.GetClientFundSetupDetail());
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetClientPortfolioStatus:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }
    }
}