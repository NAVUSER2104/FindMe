﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.BusinessLayer;
using NAVDashboard.Api.Framework.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NAVDashboard.Api.Web.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PortfolioLogController : ControllerBase
    {
        private readonly IPortfolioLogBusiness _portfolioBusiness;
        private readonly ILogger<PortfolioLogController> _logger;

        public PortfolioLogController(IPortfolioLogBusiness portfolioBusiness, ILogger<PortfolioLogController> logger)
        {
            _portfolioBusiness = portfolioBusiness;
            _logger = logger;
        }

        [HttpGet]
        public string Ping()
        {
            return "Grettings!! PortfolioLog API is up";
        }

        [HttpGet]
        public IActionResult GetProcessWisePortfolioStatus(DateTime asOfDateTime, string groupName, string userName)
        {
            try
            {
                return Ok(new { Data = _portfolioBusiness.GetProcessWisePortfolioStatus(asOfDateTime, groupName, userName) });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetProcessWisePortfolioStatus:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }

        [HttpGet]

        public IActionResult GetFundPortfolioSummary(DateTime asOfDateTime, string processName, string groupName, string userName)
        {
            try
            {
                return Ok(new { Data = _portfolioBusiness.GetFundPortfolioSummary(asOfDateTime, processName, groupName,userName )});
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetFundPortfolioSummary:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }

        [HttpGet]

        public IActionResult GetGroupData()
        {
            try
            {
                return Ok(_portfolioBusiness.GetGroupData());
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetGroupData:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }
    }
}