﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.BusinessLayer;
using NAVDashboard.Api.Framework.Data;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NAVDashboard.Api.Web.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ApiStatusController : ControllerBase
    {
        private readonly IApiStatusBusiness _apiStatusBusiness;
        private readonly ILogger<ApiStatusController> _logger;

        public ApiStatusController(IApiStatusBusiness portfolioBusiness, ILogger<ApiStatusController> logger)
        {
            _apiStatusBusiness = portfolioBusiness;
            _logger = logger;
        }

        [HttpGet]
        public string Ping()
        {
            return "Grettings!! APIStatus API is up";
        }
         
        [HttpGet]
        public IActionResult GetApiStatus(string applicationName, string serverName)
        {
            try
            {
                return Ok(new { Data = _apiStatusBusiness.GetApiStatus(applicationName,serverName) });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetApiStatus:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult SendApiNotification([FromBody]ApiStatusItemData objApiStatusItemData)
        {
            try
            {
                return Ok(new { Data = _apiStatusBusiness.SendApiNotification(objApiStatusItemData) });
            }
            catch (Exception ex)
            {
                _logger.LogError("Error in Method GetApiStatus:-" + ex.ToString());
                return StatusCode(500, new { Data = ex.Message });
            }
        }
    }
}