﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NAVDashboard.Api.BusinessLayer;
using NETCore.MailKit.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace NAVDashboard.Api.Web
{
    public static class GlobalErrorMiddleware
    {
        public static void ConfigureExceptionHandler(this IApplicationBuilder app, IEmailService emailService, IOptionsMonitor<AppConfigurationService> optionsMonitor)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";
                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if (contextFeature != null)
                    {
                        SendErrorEmail(emailService, contextFeature.Error, optionsMonitor.CurrentValue);
                        await context.Response.WriteAsync(new ErrorDetails()
                        {
                            Message = "Internal Server Error",
                            StatusCode = context.Response.StatusCode
                        }.ToString());
                    }

                });
            });
        }

        public static void ConfigureExceptionHandler(this IApplicationBuilder app, ILogger logger)
        {
            app.UseExceptionHandler(appError =>
            {
                appError.Run(async context =>
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                    context.Response.ContentType = "application/json";

                    var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                    if (contextFeature != null)
                    {                        
                        await context.Response.WriteAsync(new ErrorDetails()
                        {
                            StatusCode = context.Response.StatusCode,
                            Message = "Internal Server Error: " + contextFeature.Error.Message
                        }.ToString());
                    }
                });
            });
        }

        public static void SendErrorEmail(IEmailService _EmailService, Exception error, AppConfigurationService appConfiguration)
        {
            string automateDesc = "Entity Web API ";
            string subject = appConfiguration.EnvironmentName + "Error in Entity Web API " + automateDesc + error.Message;
            StringBuilder body = new StringBuilder();
            body.Append("An error occured in Entity Web API " + automateDesc + ". Its details are as follows.\r\n");
            body.Append(string.Format("Exception: {0}Time: {1}Method: {2}Message: {3}",
                            error.GetType().Name + Environment.NewLine, DateTime.Now + Environment.NewLine, error.TargetSite.Name +
                            Environment.NewLine, error.Message + Environment.NewLine + error.StackTrace + Environment.NewLine));
            _EmailService.Send(appConfiguration.ErrorMailTo, subject, body.ToString(), false);
        }
    }
}