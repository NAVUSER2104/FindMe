using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.AspNetCore.Server.HttpSys;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using NAVDashboard.Api.BusinessLayer;
using NAVDashboard.Api.Framework.Core;
using NAVDashboard.Api.Framework.OrmWrapper;
using NAVDashboard.Api.Framework.Repository;
using NAVDashboard.Api.Web.Controllers;
using NETCore.MailKit.Core;
using NETCore.MailKit.Extensions;
using NETCore.MailKit.Infrastructure.Internal;
using System.IO.Compression;
//using Microsoft.AspNetCore.Authentication.JwtBearer;





namespace NAVDashboard.Api.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration, Microsoft.AspNetCore.Hosting.IHostingEnvironment env)
        {
            Configuration = new ConfigurationBuilder().SetBasePath(env.ContentRootPath).AddJsonFile("appsettings.json").Build();
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // Add framework services.
            services.Configure<GzipCompressionProviderOptions>(options => options.Level = CompressionLevel.Fastest);
            services.AddResponseCompression(options =>
            {
                options.Providers.Add<GzipCompressionProvider>();
            });
            
            services.AddAuthentication(HttpSysDefaults.AuthenticationScheme);
            services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options => options.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            });


            services.AddSwaggerGen(x =>
            {
                x.SwaggerDoc("v1", new OpenApiInfo
                {
                    Version = "V1",
                    Title = "NAV Dashboard API's",
                    Description = "NAV Dashboard API's"
                });

                //TODO: User Assembly name
                var xmlPath = System.AppDomain.CurrentDomain.BaseDirectory + @"NAVDashboard.Api.Web.xml";
                x.IncludeXmlComments(xmlPath);
            });

            services.AddLogging(builder =>
            {
                builder.AddFilter("Microsoft", LogLevel.Error)
                .AddFilter("System", LogLevel.Error)
                .AddFilter("NToastNotify", LogLevel.Error)
                .AddConsole();
            });

            AddDependencyResolver(services);
            services.AddControllers();
            services.AddHttpContextAccessor();

        }

        private void AddDependencyResolver(IServiceCollection services)
        {
            services.AddTransient<IPortfolioLogBusiness, PortfolioLogBusiness>();
            services.AddTransient<IClientwiseDeliveryLogBusiness, ClientwiseDeliveryLogBusiness>();
            services.AddTransient<IApiStatusBusiness, ApiStatusBusiness>();
            services.AddTransient<IAuthenticationBusiness, AuthenticationBusiness>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

            services.Configure<AppConfigurationService>(Configuration.GetSection("ApplicationSettings"));

            var serviceProvider = services.BuildServiceProvider();
            AppConfigurationService ConfigSettings = serviceProvider.GetService<IOptionsMonitor<AppConfigurationService>>().CurrentValue;

            string configSecureKey = ConfigSettings.ConfigSecureKey;

            services.AddTransient<IOrmDbContext, DapperOrmDbContext>(dapperOrmDbContext =>
            {
                return new DapperOrmDbContext(ConfigDecryption.Decrypt(configSecureKey, ConfigSettings.NAVDashboardConnectionString));
            });


            services.AddTransient<IPortfolioLogRepository>(portfolioLogRepository =>
            {
                return new PortfolioLogRepository(ConfigDecryption.Decrypt(configSecureKey, ConfigSettings.NAVDashboardConnectionString));
            });
            services.AddTransient<IClientwiseDeliveryLogRepository>(clientwiseDeliveryLogRepository =>
            {
                return new ClientwiseDeliveryLogRepository(ConfigDecryption.Decrypt(configSecureKey, ConfigSettings.NAVDashboardConnectionString));
            });
            services.AddTransient<IApiStatusRepository>(ApiStatusRepository =>
            {
                return new ApiStatusRepository(ConfigDecryption.Decrypt(configSecureKey, ConfigSettings.NAVDashboardConnectionString));
            });
            services.AddTransient<IAuthenticationRepository>(AuthenticationRepository =>
            {
                return new AuthenticationRepository(ConfigDecryption.Decrypt(configSecureKey, ConfigSettings.NAVDashboardConnectionString));
            });

            services.AddMailKit(optionBuilder =>
            {
                optionBuilder.UseMailKit(new MailKitOptions()
                {
                    //get options from sercets.json
                    Server = ConfigSettings.SMTPServer,
                    Port = ConfigSettings.SMTPPort,
                    SenderName = ConfigSettings.SMTPSenderName,
                    SenderEmail = ConfigSettings.SMTPSenderEmail,
                    // can be optional with no authentication 
                    Account = ConfigSettings.SMTPUserName,
                    Password = ConfigSettings.SMTPPassword,
                    // enable ssl or tls
                    Security = true
                });
            });

        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, IEmailService emailService, IOptionsMonitor<AppConfigurationService> appConfiguration)
        {

            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.ConfigureExceptionHandler(emailService, appConfiguration);
            }

            char[] separator = { ';' };
            string[] dashboardUrl = Configuration.GetSection("ApplicationSettings:NAVPortfolioDashboardUrl").Value.Split(separator);

            app.UseCors(builder =>
            {
                builder.WithOrigins(dashboardUrl).AllowAnyMethod().AllowAnyHeader().AllowCredentials();
            });

            app.UseResponseCompression();
            app.UseAuthentication();

            app.UseSwagger();
            app.UseRouting();
            app.UseSwaggerUI(x =>
            {
                x.SwaggerEndpoint("./v1/swagger.json", "NAV Dashboard API v1");
            });
            app.ConfigureExceptionHandler(loggerFactory.AddLog4Net(new Log4NetProviderOptions("log4net.config", true)).CreateLogger<PortfolioLogController>());
            app.ConfigureExceptionHandler(loggerFactory.AddLog4Net(new Log4NetProviderOptions("log4net.config", true)).CreateLogger<ClientwiseDeliveryLogController>());
            app.ConfigureExceptionHandler(loggerFactory.AddLog4Net(new Log4NetProviderOptions("log4net.config", true)).CreateLogger<ApiStatusController>());
            app.ConfigureExceptionHandler(loggerFactory.AddLog4Net(new Log4NetProviderOptions("log4net.config", true)).CreateLogger<AuthenticationController>());

            //app.UseMvc();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
