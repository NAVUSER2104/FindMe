﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.Framework.Core;
using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.Repository;


namespace NAVDashboard.Api.BusinessLayer
{
     public class ClientwiseDeliveryLogBusiness : IClientwiseDeliveryLogBusiness
     {
          private readonly IClientwiseDeliveryLogRepository _clientwiseDeliveryLogRepository;
          private readonly ILogger<ClientwiseDeliveryLogBusiness> _logger;

          public ClientwiseDeliveryLogBusiness(IClientwiseDeliveryLogRepository clientwiseDeliveryLogRepository, ILogger<ClientwiseDeliveryLogBusiness> logger)
          {
               _clientwiseDeliveryLogRepository = clientwiseDeliveryLogRepository;
               _logger = logger;
          }

          public ClientwiseDeliveryLogData GetClientwiseDeliveryLog(DateTime asOfDateTime)
          {
               _logger.LogInformation("Call attempted in ClientwiseDeliveryLogBusiness.GetClientwiseDeliveryLog");
               return _clientwiseDeliveryLogRepository.GetClientwiseDeliveryLog(asOfDateTime);
          } 
        public ClientwiseDeliveryLogData GetClientPortfolioStatus(DateTime asOfDateTime)
          {
               _logger.LogInformation("Call attempted in ClientwiseDeliveryLogBusiness.GetClientwiseDeliveryLog");
               return _clientwiseDeliveryLogRepository.GetClientPortfolioStatus(asOfDateTime);
          }

        public ClientFundSetupData GetClientFundSetupDetail()
        {
            _logger.LogInformation("Call attempted in ClientwiseDeliveryLogBusiness.GetClientFundSetupDetail");
            return _clientwiseDeliveryLogRepository.GetClientFundSetupDetail();
        }
     }
}
