﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using NAVDashboard.Api.Framework.Core;
using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.Data.Portfolio;
using NAVDashboard.Api.Framework.Repository;


namespace NAVDashboard.Api.BusinessLayer
{
     public class PortfolioLogBusiness : IPortfolioLogBusiness
     {
          private readonly IPortfolioLogRepository _portfolioRepository;
          private readonly ILogger<PortfolioLogBusiness> _logger;

          public PortfolioLogBusiness(IPortfolioLogRepository portfolioRepository, ILogger<PortfolioLogBusiness> logger)
          {
               _portfolioRepository = portfolioRepository;
               _logger = logger;
          } 
        
        public PortfolioLogData GetProcessWisePortfolioStatus(DateTime asOfDateTime, string groupName, string userName)
        {
               _logger.LogInformation("Call attempted in PortfolioBusiness.GetProcessWisePortfolioStatus");
               return _portfolioRepository.GetProcessWisePortfolioStatus(asOfDateTime, groupName, userName);
          }
        public PortfolioFundData GetFundPortfolioSummary(DateTime asOfDateTime, string processName, string groupName, string userName)
        {
            _logger.LogInformation("Call attempted in PortfolioBusiness.GetFundPortfolioSummary");
            return _portfolioRepository.GetFundPortfolioSummary(asOfDateTime, processName, groupName,userName);
        }

        public List<GroupData> GetGroupData()
        {
            _logger.LogInformation("Call attempted in PortfolioBusiness.GetFundPortfolioSummary");
            return _portfolioRepository.GetGroupData();
        }
    }
}
