﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.Repository;
using System;
using System.DirectoryServices;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace NAVDashboard.Api.BusinessLayer
{
    public class AuthenticationBusiness : IAuthenticationBusiness
    {
        private readonly IAuthenticationRepository _authenticationRepository;
        private readonly ILogger<AuthenticationBusiness> _logger;
        private readonly IOptionsMonitor<AppConfigurationService> OptionsMonitorService;

        public AuthenticationBusiness(IAuthenticationRepository authenticationRepository, ILogger<AuthenticationBusiness> logger, 
                IOptionsMonitor<AppConfigurationService> optionsMonitorService)
        {
            _authenticationRepository = authenticationRepository;
            _logger = logger;
            OptionsMonitorService = optionsMonitorService;
        }

        public string GenerateJSONWebToken(UserData userInfo)
        {
            // 1. Create Security Token Handler
            var tokenHandler = new JwtSecurityTokenHandler();

            // 2. Create Private Key to Encrypted
            var tokenKey = Encoding.ASCII.GetBytes(OptionsMonitorService.CurrentValue.JwtKey);

            //3. Create JETdescriptor
            var tokenDescriptor = new SecurityTokenDescriptor()
            {
                Subject = new ClaimsIdentity(
                    new Claim[]
                    {
                        new Claim("userName", userInfo.Username),
                        new Claim("application", Convert.ToString(userInfo.ApplicationName)),
                        new Claim("userID", userInfo.UserId.ToString())
                    }),
                Expires = DateTime.UtcNow.AddHours(1),
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(tokenKey), SecurityAlgorithms.HmacSha256)
            };
            //4. Create Token
            var token = tokenHandler.CreateToken(tokenDescriptor);

            // 5. Return Token from method
            return tokenHandler.WriteToken(token);
        }

        public UserData AuthenticateUser(string userName)
        { 
            return _authenticationRepository.AuthenticateUser(userName);
        }

        public string GetUserName(IHttpContextAccessor _httpContextAccessor)
        {
            var userName = _httpContextAccessor.HttpContext.User?.Identity?.Name;
            var user = userName;
            if (!string.IsNullOrEmpty(userName))
            {
                var windowUser = userName.Split('\\');
                if (windowUser.Length == 2)
                {
                    user = windowUser[1].ToUpper();
                }
            }
            return user;
        }

        private SearchResultCollection SearchResultAD(string filter, string domainPath)
        {
            DirectoryEntry searchRoot = new DirectoryEntry(domainPath);
            DirectorySearcher search = new DirectorySearcher(searchRoot);
            search.Filter = filter;
            search.SearchScope = SearchScope.Subtree;
            search.PageSize = 100000;
            return search.FindAll();
        }

        public Users FetchUserDetailsByUserName(string userName)
        {
            Users userDetails = new Users();
            var result = SearchResultAD("(&(objectClass=user)(SamaccountName=" + userName + "))", OptionsMonitorService.CurrentValue.DomainPath);

            if (result != null)
            {
                if (result.Count > 0)
                {
                    SearchResult resultFinal = result[0];
                    if (resultFinal.Properties.Contains("SamaccountName"))
                    {
                        PrepareUserData(userDetails, resultFinal);
                    }
                }
            }
            return userDetails;
        }

        private Users PrepareUserData(Users userDetails, SearchResult result)
        {
            userDetails.Email = (String)result.Properties["mail"][0];
            userDetails.UserName = (String)result.Properties["samaccountname"][0];
            userDetails.DisplayName = (String)result.Properties["displayname"][0];

            if (result.Properties.Contains("department"))
                userDetails.Department = result.Properties["department"][0].ToString();

            if (result.Properties.Contains("employeeid"))
                userDetails.EmployeeID = result.Properties["employeeid"][0].ToString().Replace("EmployeeID:", string.Empty);

            return userDetails;
        }
    }


}
