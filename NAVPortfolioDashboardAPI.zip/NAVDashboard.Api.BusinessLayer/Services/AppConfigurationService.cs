﻿using NAVDashboard.Api.Framework.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.BusinessLayer
{
    public class AppConfigurationService : ApiBaseConfiguration
    {
        public string NAVDashboardConnectionString { get; set; }
        public string InvContractNoteFolderName { get; set; }
        public int RePublishTimeInterval { get; set; }
        public string DoubleEntryAPIEndpoint { get; set; }
        public int RetryAttempts { get; set; }
        public string ConfigSecureKey { get; set; }
        public string IndiaServerHosts { get; set; }
        public string IndiaServerUserName { get; set; }
        public string IndiaServerPassword { get; set; }
        public string USServerHosts { get; set; }
        public string USServerUserName { get; set; }
        public string USServerPassword { get; set; }
    }
}
