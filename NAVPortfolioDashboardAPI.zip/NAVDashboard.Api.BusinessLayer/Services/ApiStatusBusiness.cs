﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Mail;
using System.ServiceProcess;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NAVDashboard.Api.Framework.Core;
using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.Repository;
using Newtonsoft.Json;

namespace NAVDashboard.Api.BusinessLayer
{
    public class ApiStatusBusiness : IApiStatusBusiness
    {
        private readonly IApiStatusRepository _apiStatusRepository;
        private readonly ILogger<ApiStatusBusiness> _logger;
        private readonly IOptionsMonitor<AppConfigurationService> OptionsMonitorService;

        public ApiStatusBusiness(IApiStatusRepository apiStatusRepository, ILogger<ApiStatusBusiness> logger, IOptionsMonitor<AppConfigurationService> optionsMonitorService)
        {
            _apiStatusRepository = apiStatusRepository;
            _logger = logger;
            OptionsMonitorService = optionsMonitorService;
        }

        public ApiStatusData GetApiStatus(string applicationName, string serverName)
        {
            //  Dictionary<string, string> dicServiceS = GetServiceRunningStatus("INSAPPDEVV24", OptionsMonitorService.CurrentValue.IndiaServerUserName, OptionsMonitorService.CurrentValue.IndiaServerPassword);
            //   var jsonD = JsonConvert.SerializeObject(dicServiceS);

            _logger.LogInformation("Call attempted in ApiStatusBusiness.GetApiStatus");

            ApiStatusData objApiStatusData = _apiStatusRepository.GetApiStatus(applicationName, serverName);

            foreach (var name in objApiStatusData.Items.Select(s => s.ServerName).Distinct())
            {
                Dictionary<string, string> dicServiceStatus = GetServiceRunningStatus(name, OptionsMonitorService.CurrentValue.IndiaServerUserName, OptionsMonitorService.CurrentValue.IndiaServerPassword);

                foreach (var item in objApiStatusData.Items.Where(s => s.ServerName == name))
                {
                    string status = string.Empty;
                    if (dicServiceStatus.TryGetValue(item.ServiceName, out status))
                    {
                        item.Status = status;
                    }
                }
            }

            return objApiStatusData;
        }

        public bool SendApiNotification(ApiStatusItemData objApiStatusItemData)
        {
            string mailBody = string.Empty;
            string subject = "NAV Portfolio Service Not Working-P1";

            if (!string.IsNullOrEmpty(objApiStatusItemData.ServiceName))
            {
                mailBody += GenerateHtml(objApiStatusItemData, "Service Detail");
            }

            return SendEmail(mailBody, subject, objApiStatusItemData.userName);

        }

        private string GenerateHtml(ApiStatusItemData apiData, string dataHeading)
        {
            StringBuilder mailBody = new StringBuilder();

            mailBody.Append("<!DOCTYPE html><html lang='en' xmlns='http://www.w3.org/1999/xhtml' xmlns:o='urn:schemas-microsoft-com:office:office'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><meta name='x-apple-disable-message-reformatting'><title></title>");
            mailBody.Append("<style>table, td, div, h1, p {font-family: Arial, sans-serif;}</style></head>");
            mailBody.Append("<body style='margin:0;padding:0;'><table role='presentation' style='width:100%;border-collapse:collapse;border:0;border-spacing:0;background:#ffffff;'><tr><td align='center' style='padding:0;'><table role='presentation' style='width:602px;border-collapse:collapse;border:1px solid #cccccc;border-spacing:0;text-align:left;'><tr><td align='left' style='padding:30px 0 30px 30px;background:#013264;'>");
            mailBody.Append("<h1 style='font-size:24px;margin:0;font-family:Arial,sans-serif;color:#ffffff;'>NAV Backoffice</h1></td>");
            mailBody.Append("</tr><tr><td style='padding:5px 30px 10px 30px;'><table role='presentation' style='width:100%;border-collapse:collapse;border:0;border-spacing:0;'><tr><td style='padding:5px 0 0 0;color:#153643;'><h1 style='font-size:22px;margin:0;font-family:Arial,sans-serif;'>");
            mailBody.Append(dataHeading);
            mailBody.Append("</h1></td></tr><tr><td style='padding:0;color:#153643;'><table role='presentation' style='width:100%;border-collapse:collapse;border:0;border-spacing:0;'><tr><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;margin-top:20px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Application Name");
            mailBody.Append("</h1><p style='margin:0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.ApplicationName);
            mailBody.Append("</p></td><td style='width:20px;padding:0;font-size:0;line-height:0;'>&nbsp;</td><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;margin-top:20px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Server Name");
            mailBody.Append("</h1><p style='margin:0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.ServerName);
            mailBody.Append("</p></td></tr><tr><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;margin-top:20px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Service Name");
            mailBody.Append("</h1><p style='margin:0 0 12px 0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.ServiceName);
            mailBody.Append("</p></td><td style='width:20px;padding:0;font-size:0;line-height:0;'>&nbsp;</td><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;margin-top:20px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Service Description");
            mailBody.Append("</h1><p style='margin:0 0 12px 0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.ServiceDescription);
            mailBody.Append("</p></td></tr><tr><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Status");
            mailBody.Append("</h1><p style='margin:0 0 12px 0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.Status);
            mailBody.Append("</p></td><td style='width:20px;padding:0;font-size:0;line-height:0;'>&nbsp;</td><td style='width:260px;padding:0;vertical-align:top;color:#153643;'><h1 style='font-size:16px;font-family:Arial,sans-serif;'>");
            mailBody.Append("Email sent by User");
            mailBody.Append("</h1><p style='margin:0 0 12px 0;font-size:16px;line-height:5px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.userName);
            mailBody.Append("</p></td></tr></table></td></tr><tr><td style='padding:10px 0 0 0;color:#153643;'><h1 style='font-size:16px;margin:0;font-family:Arial,sans-serif;'>Issue Description</h1><p style='margin:0 0 12px 0;font-size:16px;line-height:20px;font-family:Arial,sans-serif;'>");
            mailBody.Append(apiData.ServiceName + " Service is not working, please restart the service to resume its working. In case of any concern, Kindly connect to respective IT team.");
            mailBody.Append("</p></td></tr></table></td></tr><tr><td style='padding:15px;background:#ee4c50;'><table role='presentation' style='width:100%;border-collapse:collapse;border:0;border-spacing:0;font-size:9px;font-family:Arial,sans-serif;'><tr><td style='padding:0;width:50%;' align='left'><p style='margin:0;font-size:14px;line-height:16px;font-family:Arial,sans-serif;color:#ffffff;'>&reg;2021 NAV CONSULTING</p></td></tr></table></td></tr></table></td></tr></table></body></html>");

            return mailBody.ToString();
        }

        public bool SendEmail(string mailBody, string subject, string loginName)
        {
            bool emailStatus = false;
            MailMessage message = null;
            try
            {
                loginName = "rohitt";
                string loginUserEmailID = loginName + "@navbackoffice.com";

                message = new MailMessage();
                message.From = new MailAddress(OptionsMonitorService.CurrentValue.SMTPSenderEmail);
                message.To.Add(loginUserEmailID);
                message.To.Add(OptionsMonitorService.CurrentValue.ErrorMailTo);
                message.IsBodyHtml = true;

                message.Subject = string.Format(subject).ToString().Replace("\r", "").Replace("\n", "");
                message.Body = mailBody.ToString();
                message.Headers.Add("Importance", "High");

                SmtpClient client = new SmtpClient(OptionsMonitorService.CurrentValue.SMTPServer);

                // if user name provided then use it to authenticate to mail server, otherwise use default credentials
                if (OptionsMonitorService.CurrentValue.SMTPUserName != string.Empty)
                {
                    client.Credentials = new System.Net.NetworkCredential(OptionsMonitorService.CurrentValue.SMTPUserName, OptionsMonitorService.CurrentValue.SMTPPassword);
                }
                else
                {
                    client.UseDefaultCredentials = true;
                }

                client.Send(message);
                emailStatus = true;
            }

            catch (Exception ex)
            {
                emailStatus = false;
                _logger.LogInformation("Problem in sending portfolio service notification email", ex);
            }
            finally
            {
                if (message != null)
                {
                    message.Attachments.Dispose();
                }

            }
            return emailStatus;
        }

        string GetHtmlFromList<T>(T dataList, string dataHeading)
        {
            string html = string.Empty;
            if (dataList != null)
            {
                var item = dataList;
                var columns = item.GetType().GetProperties().Select(x => x.Name).ToList();

                html += "<h3>" + dataHeading + "</h3>";
                html += dataList.ToHtmlTable(columns);
            }
            return html;
        }


        private Dictionary<string, string> GetServiceRunningStatus(string host, string username, string password)
        {
            Dictionary<string, string> dicServiceStatus = new Dictionary<string, string>();

            string ns = @"root\cimv2";
            string query = "select * from Win32_Service";

            ConnectionOptions options = new ConnectionOptions();
            if (!string.IsNullOrEmpty(username) && host.ToLower() != Dns.GetHostName().ToLower())
            {
                options.Username = username;
                options.Password = password;
            }

            ManagementScope scope =
                new ManagementScope(string.Format(@"\\{0}\{1}", host, ns), options);
            scope.Connect();

            ManagementObjectSearcher searcher =
                new ManagementObjectSearcher(scope, new ObjectQuery(query));
            ManagementObjectCollection retObjectCollection = searcher.Get();
            foreach (ManagementObject mo in retObjectCollection)
            {
                //Console.WriteLine(mo.GetText(TextFormat.Mof));

                if (Convert.ToString(mo["PathName"]).Contains("C:\\NAVITApps\\"))
                {
                    dicServiceStatus.Add(Convert.ToString(mo["Name"]), Convert.ToString(mo["state"]));
                }
            }

            return dicServiceStatus;
        }

    }

    public static class ExtensionMethods
    {
        public static string ToHtmlTable<T>(this T list, List<string> headerList)
        {
            var sb = new StringBuilder();

            sb.Append($"<table style='border: 1px solid black;  border-collapse: collapse;width:100%'>");
            if (headerList != null)
            {
                sb.Append($"<tr style='border: 1px solid black;'>");
                foreach (var header in headerList)
                {
                    sb.Append($"<th style='border: 1px solid black;'>{header}</th>");
                }
                sb.Append("</tr>");
            }

            sb.Append($"<tr style='border: 1px solid black;'>");
            foreach (var column in headerList)
                sb.Append($"<td style='border: 1px solid black;'>{list.GetType().GetProperty(column).GetValue(list, null)}</td>");
            sb.Append("</tr>");

            sb.Append("</table>");

            return sb.ToString();
        }
    }

}
