﻿using NAVDashboard.Api.Framework.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.BusinessLayer
{
    public interface IApiStatusBusiness
    {
        ApiStatusData GetApiStatus(string applicationName, string serverName);
        bool SendApiNotification(ApiStatusItemData objApiStatusItemData);
    }
}
