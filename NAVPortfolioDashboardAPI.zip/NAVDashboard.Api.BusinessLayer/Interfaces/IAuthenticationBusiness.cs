﻿using Microsoft.AspNetCore.Http;
using NAVDashboard.Api.Framework.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.BusinessLayer
{
    public interface IAuthenticationBusiness
    {
        string GenerateJSONWebToken(UserData userInfo);
        UserData AuthenticateUser(string userName);
        string GetUserName(IHttpContextAccessor _httpContextAccessor);
        Users FetchUserDetailsByUserName(string userName);
    }
}
