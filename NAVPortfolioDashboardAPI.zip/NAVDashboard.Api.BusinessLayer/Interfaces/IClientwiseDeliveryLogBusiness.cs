﻿using NAVDashboard.Api.Framework.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.BusinessLayer
{
    public interface IClientwiseDeliveryLogBusiness
    {
        ClientwiseDeliveryLogData GetClientwiseDeliveryLog(DateTime asOfDateTime);
        ClientwiseDeliveryLogData GetClientPortfolioStatus(DateTime asOfDateTime);
        ClientFundSetupData GetClientFundSetupDetail();
    }
}
