﻿using System;

namespace NAVDashboard.Api.Framework.Data
{
    public class UserData
    {
        public UserData()
        {
            Status = string.Empty;
            ApplicationName = "NAVMain2";
        }

        public int UserId { get; set; }
        public string ApplicationName { get; set; }
        public string Username { get; set; }
        public string EmailAddress { get; set; }
        public string Status { get; set; }
    }

    public class Users
    {
        public string Email { get; set; }
        public string EmployeeID { get; set; }
        public string UserName { get; set; }
        public string DisplayName { get; set; }
        public string Department { get; set; }
    }
}
