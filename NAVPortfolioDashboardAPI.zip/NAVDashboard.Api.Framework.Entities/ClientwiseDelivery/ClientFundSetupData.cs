﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data
{
    public class ClientFundSetupData
    { 
        public IList<ClientFundSetupItemData> Items { get; set; } = new List<ClientFundSetupItemData>();
    }

    public class ClientFundSetupItemData
    {
        public string Name { get; set; }
        public List<int> Data { get; set; } = new List<int>();
    }
}
