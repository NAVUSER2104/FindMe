﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data
{
    public class ClientwiseDeliveryLogData
    {
        public DateTime ProcessDate { get; set; }
        public DateTime AsOfDateTime { get; set; }

        public IList<ClientwiseDeliveryLogItemData> Items { get; set; } = new List<ClientwiseDeliveryLogItemData>();
    }

    public class ClientwiseDeliveryLogItemData
    {
        public string PortfolioStatus { get; set; }
        public decimal Percentage { get; set; }
    }
}
