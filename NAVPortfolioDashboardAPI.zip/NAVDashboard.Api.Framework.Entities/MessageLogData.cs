﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data
{
    public class MessageLogData
    {
        public int MessageCode { get; set; }
        public bool MessageStatus { get; set; }
        public string MessageDescription { get; set; }
    }
}
