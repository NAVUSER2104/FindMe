﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data
{
     public class PortfolioLogData
     {
          public DateTime ProcessDate { get; set; }
          public DateTime AsOfDateTime { get; set; }
         
          public string GroupId { get; set; }

          public IList<PortfolioLogItemData> Items { get; set; } = new List<PortfolioLogItemData>();
     }

     public class PortfolioLogItemData
     {
          public string ProcessName { get; set; }
          public decimal Percentage { get; set; }
     }
    public class PortfolioFundData
    {
        public DateTime ProcessDate { get; set; }
        public DateTime AsOfDateTime { get; set; }
        public string Name { get; set; }
        public IList<PortfolioLogFundData> Items { get; set; } = new List<PortfolioLogFundData>();
    }
    public class PortfolioLogFundData
    {
        public int ClientId { get; set; }
        public string ClientName { get; set; }
        public string AccountName { get; set; }
        public string Status { get; set; }
    }
}
