﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data.Portfolio
{
    public class GroupData
    {
        public string GroupId { get; set; }
        public string GroupName { get; set; }
    } 
}
