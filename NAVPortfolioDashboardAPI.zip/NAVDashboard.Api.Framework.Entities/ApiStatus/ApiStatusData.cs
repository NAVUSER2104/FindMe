﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Data
{
    public class ApiStatusData
    {
        public IList<ApiStatusItemData> Items { get; set; } = new List<ApiStatusItemData>();
    }
    public class ApiStatusItemData
    {
        public ApiStatusItemData()
        {
            Status = string.Empty;
        }
        public int Id { get; set; }
        public string ApplicationName { get; set; }
        public string ServerName { get; set; }
        public string ServiceName { get; set; }
        public string ServiceUrl { get; set; }
        public string ServiceDescription { get; set; }
        public string Status { get; set; }
        public string userName { get; set; }
    }
}
