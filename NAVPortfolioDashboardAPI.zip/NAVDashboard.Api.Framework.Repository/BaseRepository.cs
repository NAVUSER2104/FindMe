﻿using System;

namespace NAVDashboard.Api.Framework.Repository
{
    public abstract class BaseRepository
    {
        //protected readonly IDataProvider DataProvider;
        //public BaseRepository(string connectionString)
        //{
        //    DataProvider = Framework.DataProvider.Factory.DataProviderFactory.CreateConnection(connectionString);
        //}
    }
}
