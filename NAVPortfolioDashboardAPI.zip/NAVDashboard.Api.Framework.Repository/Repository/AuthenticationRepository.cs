﻿using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.OrmWrapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;


namespace NAVDashboard.Api.Framework.Repository
{
    public class AuthenticationRepository : BaseRepository, IAuthenticationRepository
    {
        private readonly IOrmDbContext OrmDbContext;

        public AuthenticationRepository(string connectionString)
        {
            OrmDbContext = new DapperOrmDbContext(connectionString);
        }

        public UserData AuthenticateUser(string userName)
        {
            return OrmDbContext.ExecuteQuery<UserData>("dbo.GuiGetUsers", new { userName = userName, isActive= 1 }).FirstOrDefault();
        }
    }
}

