﻿using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.OrmWrapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;


namespace NAVDashboard.Api.Framework.Repository
{
    public class ClientwiseDeliveryLogRepository : BaseRepository, IClientwiseDeliveryLogRepository
    {
        private readonly IOrmDbContext OrmDbContext;

        public ClientwiseDeliveryLogRepository(string connectionString)
        {
            OrmDbContext = new DapperOrmDbContext(connectionString);
        }

        private ClientwiseDeliveryLogData ReadMockData()
        {
            ClientwiseDeliveryLogData clientwiseDeliveryLogData = null;
            string fileName = "MockData" + Path.DirectorySeparatorChar + "ClientwiseDeliveryLogData.json";
            using (StreamReader streamReader = new StreamReader(fileName))
            {
                var jsonReader = new JsonTextReader(streamReader);
                clientwiseDeliveryLogData = new JsonSerializer().Deserialize<ClientwiseDeliveryLogData>(jsonReader);
            }

            return clientwiseDeliveryLogData != null ? clientwiseDeliveryLogData : new ClientwiseDeliveryLogData();
        }

        private void WriteMockData()
        {
            List<(string, decimal)> nameValueTupleList =
                new List<(string, decimal)>
                {
                    ("GrantPark", Convert.ToDecimal(61.41)),
                    ("LGT", Convert.ToDecimal(11.84)),
                    ("Crabel",Convert.ToDecimal(10.85)),
                    ("Crown managed", Convert.ToDecimal(4.67)),
                    ("Cheskpeck", Convert.ToDecimal(4.18)),
                    ("Beach", Convert.ToDecimal(1.64)),
                    ("ACIM", Convert.ToDecimal(1.6)),
                    ("Prelude", Convert.ToDecimal(1.2)),
                    ("Blue Diamond", Convert.ToDecimal(2.61))
                };

            ClientwiseDeliveryLogData clientwiseDeliveryLogData = new ClientwiseDeliveryLogData() { ProcessDate = DateTime.Now.Date };

            for (int index = 0; index < nameValueTupleList.Count; index++)
            {
                clientwiseDeliveryLogData.Items.Add(new ClientwiseDeliveryLogItemData
                {
                    // PortfolioStatus = index + 1,
                    Percentage = nameValueTupleList[index].Item2
                });
            }

            string fileName = "MockData" + Path.DirectorySeparatorChar + "ClientwiseDeliveryLogData.json";
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                var jsonWriter = new JsonTextWriter(streamWriter);
                jsonWriter.Formatting = Formatting.Indented;
                new JsonSerializer().Serialize(jsonWriter, clientwiseDeliveryLogData);
            }
        }

        public ClientwiseDeliveryLogData GetClientwiseDeliveryLog(DateTime asOfDateTime)
        {
            //WriteMockData();

            ClientwiseDeliveryLogData clientwiseDeliveryLogData = ReadMockData();
            clientwiseDeliveryLogData.AsOfDateTime = asOfDateTime;
            return (clientwiseDeliveryLogData != null) ? clientwiseDeliveryLogData : new ClientwiseDeliveryLogData();

        }

        public ClientwiseDeliveryLogData GetClientPortfolioStatus(DateTime asOfDateTime)
        {
            ClientwiseDeliveryLogData objClientwiseDeliveryLogData = new ClientwiseDeliveryLogData();
            objClientwiseDeliveryLogData.AsOfDateTime = asOfDateTime;

            List<ClientwiseDeliveryLogItemData> lstClientwiseDeliveryLogItemData = new List<ClientwiseDeliveryLogItemData>();

            dynamic result = OrmDbContext.ExecuteQuery<dynamic>("dbo.GetClientPortfolioStatus", new { asOfDateTime }).ToList();

            foreach (var item in result)
            {
                objClientwiseDeliveryLogData.ProcessDate = item.ProcessDate;
                ClientwiseDeliveryLogItemData objClientwiseDeliveryLogItemData = new ClientwiseDeliveryLogItemData
                {
                    PortfolioStatus = item.PortfolioStatus,
                    Percentage = item.Percentage
                };

                lstClientwiseDeliveryLogItemData.Add(objClientwiseDeliveryLogItemData);
            }

            objClientwiseDeliveryLogData.Items = lstClientwiseDeliveryLogItemData;

            return objClientwiseDeliveryLogData;
        }

        public ClientFundSetupData GetClientFundSetupDetail()
        {
            ClientFundSetupData objClientFundSetupData = new ClientFundSetupData();
            List<ClientFundSetupItemData> lstClientFundSetupItemData = new List<ClientFundSetupItemData>();

            dynamic result = OrmDbContext.ExecuteQuery<dynamic>("dbo.GetClientFundSetup").ToList();
            ClientFundSetupItemData setUpClientData = new ClientFundSetupItemData
            {
                Name = "Client"
            };

            ClientFundSetupItemData setUpFundData = new ClientFundSetupItemData
            {
                Name = "Fund"
            };

            ClientFundSetupItemData setUpBrokerAccountData = new ClientFundSetupItemData
            {
                Name = "BrokerAccount"
            };

            for (int i = 0; i < result.Count; i++)
            {
                if (i == 0)
                {
                    setUpClientData.Data.Add(result[i].Client);
                    setUpFundData.Data.Add(result[i].Fund);
                    setUpBrokerAccountData.Data.Add(result[i].BrokerAccount);
                }
                else
                {
                    setUpClientData.Data.Add(result[i].Client + setUpClientData.Data[i - 1]);
                    setUpFundData.Data.Add(result[i].Fund + setUpFundData.Data[i - 1]);
                    setUpBrokerAccountData.Data.Add(result[i].BrokerAccount + setUpBrokerAccountData.Data[i - 1]);
                }
            }

            //foreach (var item in result)
            //{
            //    setUpClientData.Data.Add(item.Client);
            //    setUpFundData.Data.Add(item.Fund);
            //    setUpBrokerAccountData.Data.Add(item.BrokerAccount);
            //}

            lstClientFundSetupItemData.Add(setUpClientData);
            lstClientFundSetupItemData.Add(setUpFundData);
            lstClientFundSetupItemData.Add(setUpBrokerAccountData);

            objClientFundSetupData.Items = lstClientFundSetupItemData;
            return objClientFundSetupData;
        }
    }
}

