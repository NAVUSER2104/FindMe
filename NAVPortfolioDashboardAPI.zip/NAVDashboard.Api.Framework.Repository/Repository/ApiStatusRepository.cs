﻿using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.OrmWrapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;


namespace NAVDashboard.Api.Framework.Repository
{
    public class ApiStatusRepository : BaseRepository, IApiStatusRepository
    {
        private readonly IOrmDbContext OrmDbContext;

        public ApiStatusRepository(string connectionString)
        {
            OrmDbContext = new DapperOrmDbContext(connectionString);
        }

        private ApiStatusData ReadMockData(string applicationName, string serverName)
        {
            //WriteMockData();

            ApiStatusData apiStatusData = null;
            string fileName = "MockData" + Path.DirectorySeparatorChar + "NAVPortfolioApiData.json";
            using (StreamReader streamReader = new StreamReader(fileName))
            {
                var jsonReader = new JsonTextReader(streamReader);
                apiStatusData = new JsonSerializer().Deserialize<ApiStatusData>(jsonReader);
            }
            if (!string.IsNullOrEmpty(applicationName))
            {
                apiStatusData.Items = apiStatusData.Items.Where(s => s.ApplicationName == applicationName).ToList();
            }
            if (!string.IsNullOrEmpty(serverName))
            {
                apiStatusData.Items = apiStatusData.Items.Where(s => s.ServerName == serverName).ToList();
            }

            return apiStatusData != null ? apiStatusData : new ApiStatusData();
        }

        private void WriteMockData()
        {
            List<(string, string, string, string, string)> nameValueTupleList =
                new List<(string, string, string, string, string)>
                {
                    ("INSAPPDEVV24","NAVMain","MainPNLServiceProductType","","MainPNLServiceProductType"),
                    ("INSAPPDEVV24","NAVMDM","MDMEntityPerformanceImprovementService","","MDM Service"),
                    ("INSAPPDEVV24","NAVMDM","MDMIntegrationService-WeekendWorking","","MDMIntegrationService-WeekendWorking"),
                    ("INSAPPDEVV24","NAVMDM","MDMIntegrationWIthServerMainUAT","","MDMIntegrationWIthServerMainUAT"),
                    ("INSAPPDEVV24","NAVMain2","MDMMain2HolidayService","","MDMMain2HolidayService"),
                    ("INSAPPDEVV24","NAVMDM","MDMServiceForRelease","","MDMServiceForRelease"),
                    ("INSAPPDEVV24","NAVMDM","MDMSubscriberService","","MDMSubscriberService"),
                    ("INSAPPDEVV24","NAVMain","NavCommonServiceMain","","NavCommonServiceMain"),
                    ("INSAPPDEVV24","NAVMain2","NavCommonServiceMain2","","NavCommonServiceMain2"),
                    ("INSAPPDEVV24","NAVMain2","NavCommonServiceMain2new","","NavCommonServiceMain2new"),
                    ("INSAPPDEVV24","NAVMain2","NavCorporateActionService","","NavCorporateActionService"),
                    ("INSAPPDEVV24","NAVMain2","NAVExtractionService","","NAVExtractionService"),
                    ("INSAPPDEVV24","NAVMain2","NAVFactoredTradeService","","NAVFactoredTradeService"),
                    ("INSAPPDEVV24","NAVMain2","NAVFactorTradeServiceMain2","","NAVFactorTradeServiceMain2"),
                    ("INSAPPDEVV24","NAVMain2","NavFactorTradeServiceNew","","NavFactorTradeServiceNew"),
                    ("INSAPPDEVV24","NAVMain2","NavFileService","","NavFileService"),
                    ("INSAPPDEVV24","NAVMain2","NAVFundOnBoardExtractionService","","NAVFundOnBoardExtractionService"),
                    ("INSAPPDEVV24","NAVMain2","NAVFundOnBoardSignOffService","","NAVFundOnBoardSignOffService"),
                    ("INSAPPDEVV24","NAVMain2","NavMain2MDMIntegrationService","","NavMain2MDMIntegrationService"),
                    ("INSAPPDEVV24","NAVMain2","NAVMain2PNLChecks","","NAVMain2PNLChecks"),
                    ("INSAPPDEVV24","NAVMain2","NAVMain2PNLChecks2","","NAVMain2PNLChecks2"),
                    ("INSAPPDEVV24","NAVMain","NavMainIntegration1GraylogService","","NavMainIntegration1GraylogService"),
                    ("INSAPPDEVV24","NAVMain","NAVMAINIntegrationService","","NAVMAINIntegrationService"),
                    ("INSAPPDEVV24","NAVMain","NAVMAINIntegrationServiceSqlIndia2008","","NAVMAINIntegrationServiceSqlIndia2008"),
                    ("INSAPPDEVV24","NAVMain","NavMainPNLService","","NavMainPNLService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDmBrokerAttributeService","","NavMDmBrokerAttributeService"),
                    ("INSAPPDEVV24","NAVMDM","NAVMDMBrokerAttributeUATService","","NAVMDMBrokerAttributeUATService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMDoubleEntryService","","NavMDMDoubleEntryService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMEntityPhase3Service","","NavMDMEntityPhase3Service"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMIntegrationServiceMain","","NavMDMIntegrationServiceMain"),
                    ("INSAPPDEVV24","NAVMain","NavMDMIntegrationServiceMainDev","","NavMDMIntegrationServiceMainDev"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMNewAttributesUAT","","NavMDMNewAttributesUAT"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMNewAttributesValidationService","","NavMDMNewAttributesValidationService"),
                    ("INSAPPDEVV24","NAVMDM","NAVMDMPublisherService","","NAVMDMPublisherService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMReleaseService","","NavMDMReleaseService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMService","","NavMDMService"),
                    ("INSAPPDEVV24","NAVMDM","NavMdmServiceForLinux","","NavMdmServiceForLinux"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMServiceTest","","NavMDMServiceTest"),
                    ("INSAPPDEVV24","NAVMDM","NAVMDMSubscriberService","","NAVMDMSubscriberService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMTPSIntegrationAPIService","","NavMDMTPSIntegrationAPIService"),
                    ("INSAPPDEVV24","NAVMDM","NavMDMWeekendHoliday","","NavMDMWeekendHoliday"),
                    ("INSAPPDEVV24","NAVMain2","NavPNLMain2DevService","","NavPNLMain2DevService"),
                    ("INSAPPDEVV24","NAVMain2","NAVPNLMain2Improvement","","NAVPNLMain2Improvement"),
                    ("INSAPPDEVV24","NAVMain","NavPNLReconService","","NavPNLReconService"),
                    ("INSAPPDEVV24","NAVMain2","NAVPNLSERVICE","","NAVPNLSERVICE"),
                    ("INSAPPDEVV24","NAVMain2","NavPNLServiceEqPrd","","NavPNLServiceEqPrd"),
                    ("INSAPPDEVV24","NAVMin2","NAVPNLServiceExchRate","","NAVPNLServiceExchRate"),
                    ("INSAPPDEVV24","NAVMain2","NAVPNLServiceLOG","","NAVPNLServiceLOG"),
                    ("INSAPPDEVV24","NAVMain2","NavPNLServiceMain2Dev2","","NavPNLServiceMain2Dev2"),
                    ("INSAPPDEVV24","NAVMain2","NavPNLServiceMain2UAT","","NavPNLServiceMain2UAT"),
                    ("INSAPPDEVV24","NAVMain2","NavPortfolioAutomate","","NavPortfolioAutomate"),
                    ("INSAPPDEVV24","NAVMain2","NAVPricingValuation","","NAVPricingValuation"),
                    ("INSAPPDEVV24","NAVMDM","NAVPublishService","","NAVPublishService"),
                    ("INSAPPDEVV24","NAVMain2","NAVReconService","","NAVReconService"),
                    ("INSAPPDEVV24","NAVMain2","NavReleaseFactoredTradeService","","NavReleaseFactoredTradeService"),
                    ("INSAPPDEVV24","NAVMain2","NAVSecurityExtractionService","","NAVSecurityExtractionService"),
                    ("INSAPPDEVV24","NAVMain2","NavSecurityImapctServiceDev","","NavSecurityImapctServiceDev"),
                    ("INSAPPDEVV24","NAVMain2","NAVSecurityImpactMain2","","NAVSecurityImpactMain2"),

                };

            ApiStatusData apiStatusData = new ApiStatusData();

            for (int index = 0; index < nameValueTupleList.Count; index++)
            {
                apiStatusData.Items.Add(new ApiStatusItemData
                {
                    Id = index + 1,
                    ServerName = nameValueTupleList[index].Item1,
                    ApplicationName = nameValueTupleList[index].Item2,
                    ServiceName = nameValueTupleList[index].Item3,
                    ServiceUrl = nameValueTupleList[index].Item4,
                    ServiceDescription = nameValueTupleList[index].Item5
                });
            }

            string fileName = "MockData" + Path.DirectorySeparatorChar + "NAVPortfolioApiData.json";
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                var jsonWriter = new JsonTextWriter(streamWriter);
                jsonWriter.Formatting = Formatting.Indented;
                new JsonSerializer().Serialize(jsonWriter, apiStatusData);
            }
        }

        public ApiStatusData GetApiStatus(string applicationName, string serverName)
        {
            ApiStatusData apiStatusData = ReadMockData(applicationName, serverName);
            return (apiStatusData != null) ? apiStatusData : new ApiStatusData();
        }
    }
}

