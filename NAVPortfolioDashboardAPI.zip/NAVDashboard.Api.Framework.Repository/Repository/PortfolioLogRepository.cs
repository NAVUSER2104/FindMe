﻿using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.OrmWrapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using NAVDashboard.Api.Framework.Data.Portfolio;

namespace NAVDashboard.Api.Framework.Repository
{
    public class PortfolioLogRepository : BaseRepository, IPortfolioLogRepository
    {
        private readonly IOrmDbContext OrmDbContext;

        public PortfolioLogRepository(string connectionString)
        {
            OrmDbContext = new DapperOrmDbContext(connectionString);
        }
        private PortfolioLogData ReadMockData()
        {
            PortfolioLogData portfolioLogData = null;
            string fileName = "MockData" + Path.DirectorySeparatorChar + "PortfolioLogData.json";
            using (StreamReader streamReader = new StreamReader(fileName))
            {
                var jsonReader = new JsonTextReader(streamReader);
                portfolioLogData = new JsonSerializer().Deserialize<PortfolioLogData>(jsonReader);
            }

            return portfolioLogData != null ? portfolioLogData : new PortfolioLogData();
        }

        private void WriteMockData()
        {
            List<(string, decimal)> nameValueTupleList =
                new List<(string, decimal)>
                {
                    ("All", 40),
                    ("Client Reading", 15),
                    ("Generation",100),
                    ("Sign off", 8),
                    ("Broker Reading", 2),
                    ("Recon", 7),
                    ("Post Recon", 11),
                    ("Client data transfer",  5),
                    ("Performance Status", 20)
                };

            PortfolioLogData portfolioLogData = new PortfolioLogData() { /*Id = 1,*/ ProcessDate = DateTime.Now.Date };

            for (int index = 0; index < nameValueTupleList.Count; index++)
            {
                portfolioLogData.Items.Add(new PortfolioLogItemData
                {
                    //Id = index + 1,
                    ProcessName = nameValueTupleList[index].Item1,
                    Percentage = nameValueTupleList[index].Item2
                });
            }

            string fileName = "MockData" + Path.DirectorySeparatorChar + "PortfolioLogData.json";
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                var jsonWriter = new JsonTextWriter(streamWriter);
                jsonWriter.Formatting = Formatting.Indented;
                new JsonSerializer().Serialize(jsonWriter, portfolioLogData);
            }
        }

        public PortfolioLogData GetProcessWisePortfolioStatus(DateTime asOfDateTime,string groupName, string userName)
        {
            PortfolioLogData objPortfolioLogData = new PortfolioLogData();
            objPortfolioLogData.AsOfDateTime = asOfDateTime;
            

            List<PortfolioLogItemData> lstPortfolioLogItemData = new List<PortfolioLogItemData>();

            dynamic result = OrmDbContext.ExecuteQuery<dynamic>("dbo.GetProcessWisePortfolioStatus", new { asOfDateTime, groupName, userName }).ToList();

            foreach (var item in result)
            {
                objPortfolioLogData.ProcessDate = item.ProcessDate;
                PortfolioLogItemData objPortfolioLogItemData = new PortfolioLogItemData
                {
                    ProcessName = item.ProcessName,
                    Percentage = item.Percentage
                };

                lstPortfolioLogItemData.Add(objPortfolioLogItemData);
            }

            objPortfolioLogData.Items = lstPortfolioLogItemData;

            return objPortfolioLogData;
        }

        //Umcomment htis when SP is available
        /*public PortfolioFundData GetFundPortfolioSummary(DateTime asOfDateTime, string name)
        {
            WriteMockData();
            PortfolioFundData objPortfolioLogData = new PortfolioFundData();
            //objPortfolioLogData.AsOfDateTime = asOfDateTime;
            //objPortfolioLogData.Name = name;

            List<PortfolioLogFundData> lstPortfolioLogItemData = new List<PortfolioLogFundData>();

            dynamic result = ReadMockData();

            foreach (var item in result)
            {
                objPortfolioLogData.ProcessDate = item.ProcessDate;
                PortfolioLogFundData objPortfolioLogItemData = new PortfolioLogFundData
                {
                    ClientId = item.ClientId,
                    ClientName = item.ClientName,
                    AccountName = item.AccountName,
                    Status = item.Status
                };

                lstPortfolioLogItemData.Add(objPortfolioLogItemData);
            }

            objPortfolioLogData.Items = lstPortfolioLogItemData;

            return objPortfolioLogData;
        }*/


        //Remove the below ReadMock and GetFundPortfolioSUmmary when SP is available
        private PortfolioFundData ReadMockDataTable(DateTime asOfDateTime, string name)
        {

            PortfolioFundData portfolioLogData = null;
            string fileName = "MockData" + Path.DirectorySeparatorChar + "PortfolioLogDataTable.json";
            using (StreamReader streamReader = new StreamReader(fileName))
            {
                var jsonReader = new JsonTextReader(streamReader);
                portfolioLogData = new JsonSerializer().Deserialize<PortfolioFundData>(jsonReader);
            }


            if (!string.IsNullOrEmpty(name))
            {
                portfolioLogData.Items = portfolioLogData.Items.Where(s => s.AccountName != null).ToList();
            }

            return portfolioLogData != null ? portfolioLogData : new PortfolioFundData();

        }
        public PortfolioFundData GetFundPortfolioSummary(DateTime asOfDateTime, string processName, string groupName, string userName)
        {
            //PortfolioFundData portfolioLogData = ReadMockDataTable(asOfDateTime, name);
            //return (portfolioLogData != null) ? portfolioLogData : new PortfolioFundData();         
            
            PortfolioFundData objPortfolioLogData = new PortfolioFundData();

            List<PortfolioLogFundData> lstPortfolioLogItemData = new List<PortfolioLogFundData>();
            
            dynamic result = OrmDbContext.ExecuteQuery<dynamic>("dbo.GetFundWisePortfolioStatus", new { timeStamp =asOfDateTime, groupName = groupName, processName= processName,userName= userName }).ToList();
            foreach (var item in result)
            {
                objPortfolioLogData.ProcessDate = asOfDateTime;
                PortfolioLogFundData objPortfolioLogItemData = new PortfolioLogFundData
                {
                    ClientId = item.ClientID,
                    ClientName = item.ClientName,
                    AccountName = item.FundName,
                    Status = item.Status
                };

                lstPortfolioLogItemData.Add(objPortfolioLogItemData);
            }

            objPortfolioLogData.Items = lstPortfolioLogItemData;

            return objPortfolioLogData;

        }


        public List<GroupData> GetGroupData()
        {
            return OrmDbContext.ExecuteQuery<GroupData>("dbo.GetGroupsApi").ToList();
        }
    }
}

