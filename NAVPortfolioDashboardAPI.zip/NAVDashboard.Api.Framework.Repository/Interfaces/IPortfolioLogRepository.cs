﻿using NAVDashboard.Api.Framework.Data;
using NAVDashboard.Api.Framework.Data.Portfolio;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Repository
{
     public interface IPortfolioLogRepository
     { 
        PortfolioLogData GetProcessWisePortfolioStatus(DateTime asOfDateTime, string groupName, string userName);
        PortfolioFundData GetFundPortfolioSummary(DateTime asOfDateTime, string processName, string groupName, string userName);

        List<GroupData> GetGroupData();
    }
}
