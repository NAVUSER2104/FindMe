﻿using NAVDashboard.Api.Framework.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Repository
{
     public interface IAuthenticationRepository
    {
        UserData AuthenticateUser(string userName);
     }
}
