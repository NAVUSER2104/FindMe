﻿using NAVDashboard.Api.Framework.Data;
using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Repository
{
     public interface IApiStatusRepository
     {
        ApiStatusData GetApiStatus(string applicationName, string serverName);
     }
}
