﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Core
{
    public static class AppKeys
    {
        public const int DefaultID = -9999;
        public const string CONST_ENDDATE = "12/31/9998";
        public const string CONST_NAVDashboardWEB = "NAVDashboard-Web"; 
        public const string PublishEntity = "PublishEntity";
        public const string Put = "Put";
        public const string Get = "Get";
        public const string Delimiter = "/";

        public const int NA = 2;
    }
}
