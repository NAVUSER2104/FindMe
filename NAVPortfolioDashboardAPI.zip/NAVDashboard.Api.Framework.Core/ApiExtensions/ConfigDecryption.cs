﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace NAVDashboard.Api.Framework.Core
{
    public class ConfigDecryption
    {
        public static string Decrypt(string secureKey, string encodeString)
        {
            TripleDES tripleDESCrypto = null;
            string @string;
            try
            {
                if (string.IsNullOrWhiteSpace(encodeString) || string.IsNullOrWhiteSpace(secureKey))
                {
                    throw new Exception("Invalid input");
                }
                byte[] array = Convert.FromBase64String(encodeString);
                MD5 mD5CryptoServiceProvider = MD5.Create();
                byte[] key2 = mD5CryptoServiceProvider.ComputeHash(Encoding.UTF8.GetBytes(secureKey));
                mD5CryptoServiceProvider.Dispose();
                tripleDESCrypto = TripleDES.Create();
                tripleDESCrypto.Key = key2;
                tripleDESCrypto.Mode = CipherMode.ECB;
                tripleDESCrypto.Padding = PaddingMode.PKCS7;
                ICryptoTransform cryptoTransform = tripleDESCrypto.CreateDecryptor();
                byte[] bytes = cryptoTransform.TransformFinalBlock(array, 0, array.Length);
                tripleDESCrypto.Dispose();
                @string = Encoding.UTF8.GetString(bytes);
            }
            finally
            {
                if (tripleDESCrypto != null)
                {
                    tripleDESCrypto.Dispose();
                }
            }
            return @string;
        }
    }
}
