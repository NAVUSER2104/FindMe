﻿using System.IO;
using System.Net;
using System.Net.Http;
using System.Runtime.Serialization.Json;
using System.Threading.Tasks;

namespace NAVDashboard.Api.Framework.Core
{
    public class SecureKeysVault
    {
        private static string SecureKey;
        public static string GetConfigSecureKey(string loginServiceEndPoint, short applicationId)
        {
            //GetSecureKeyFromLoginService(loginServiceEndPoint, applicationId).GetAwaiter().GetResult();
            //return SecureKey;
            return string.Empty;
        }

        //private static async Task<string> GetSecureKeyFromLoginService(string loginServiceEndPoint, short applicationId)
        //{
        //    //LoginServiceSoapClient loginSvc = new LoginServiceSoapClient(LoginServiceSoapClient.EndpointConfiguration.LoginServiceSoap, loginServiceEndPoint);
        //    //GetApplicationKeyByIDResponse reponse = await loginSvc.GetApplicationKeyByIDAsync(applicationId, string.Empty);
        //    //SecureKey = reponse.Body.GetApplicationKeyByIDResult.ToString();
        //    //return reponse.Body.strErrorText;
        //}

        public static T GetDataListFromWebservice<T>(string requestUrl, string methodType, T tweet)
        {
            // Endpoit - is the URI we will be dealing with
            var request = (HttpWebRequest)HttpWebRequest.Create(requestUrl);

            // Indicate that we are dealing with JSON object
            // to the Web Server
            request.Accept = "application/json";
            request.ContentType = "application/json";

            // HTTP Verb Method Type: Get/Put/Post
            request.Method = methodType;

            var response = request.GetResponse();
            if (response.ContentLength == 0)
            {
                response.Close();
            }


            var serializer = new DataContractJsonSerializer(typeof(T));


            // Deserialize from JSON object back to a .net object
            var responseStream = response.GetResponseStream();

            var result = (T)serializer.ReadObject(responseStream);

            return result;

        }
    }
}
