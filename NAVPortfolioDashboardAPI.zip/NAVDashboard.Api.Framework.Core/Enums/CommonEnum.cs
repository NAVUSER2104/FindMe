﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Core
{
    public static class CommonEnum
    {
        public enum ApplicationMode
        {
            Unknown = 0,
            Development = 1,
            UAT = 2,
            Live = 3
        }
        public enum AddValueInCombo
        {
            None = 0,
            All = -1,
            Select = -2
        }

        public enum AttributeControlType
        {
            Combo = 1,
            Date = 2,
            TextBox = 3,
            CheckBox = 4,
            CheckBoxCombo = 5
        }
        public enum EntityEnum
        {
            EntityShortName = -1,
            EntityMediumName = -2,
            EntityLongName = -3,
            EntityReportingName = -4,
            EntityReportingNameType = -5,
            EntityType = -6,
            BusinessClientRelationshipID = -7,
            NavStartDate = -9,
            FundBehaviour = -11,
            TradingBehaviour = -12,
            FundType = -13,
            FundStartingBehaviour = -14,
            FundStructure = -15,
            FiscalYearBeginMonth = -16,
            WeekBeginDay = -17,
            PnsType = -18,
            FundStartDateInTheMarket = -19,
            SLAPriority = -21,
            FundDomicile = -22,
            Currency = -23,
            ParentEntityID = -24,
            ParentEntityType = -25
        }
        public enum ReportingNameType
        {
            Short = 0,
            Medium = 1,
            Long = 2
        }
        public enum EntityType
        {
            Fund = 0,
            Fof = 2
        }

        public enum FundType
        {
            Onshore = 0,
            Offshore = 1,
            NA = 2
        }

        public enum PublishEntityDataType
        {
            EntityProperties = 0,
            Attribute = 1,
            Relationship = 2,
            DeliveryMapping = 3,
            TransactionalMapping = 4,
            PPM = 5,
            GroupMapping = 6,
            RelationshipConstraint = 7,
            Frequency = 8
        }

        public enum EntityAttributeNames
        {
            Domicile = -22,
            Currency = -23,
            CountryHoliday = 101
        }

        public enum EntityStatus
        {
            Discarded = -1,
            Draft = 0,
            SubmitedForReview = 1,
            PendingReview = 2,
            InTrasit = 3,
            FailedInTrasit = 4,
            NAVDashboardValidationFailed = 5,
            Reviewed = 6,
            EntityPublishFailed = 7,
            EntitySavedAndPublished = 8
        };

    }
}
