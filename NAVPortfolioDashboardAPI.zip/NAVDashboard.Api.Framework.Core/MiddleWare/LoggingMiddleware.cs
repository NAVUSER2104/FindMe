﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace NAVDashboard.Api.Framework.Core.MiddleWare
{
    public class LoggingMiddleware
    {
        // Name of the Response Header, Custom Headers starts with "X-"  
        private const string RESPONSE_HEADER_RESPONSE_TIME = "X-Response-Time-ms";
        // Handle to the next Middleware in the pipeline  
        private readonly RequestDelegate Next;
        private readonly ILogger Logger;

        public LoggingMiddleware(RequestDelegate next, ILogger logger)
        {
            Next = next;
            Logger = logger;
        }
        public Task InvokeAsync(HttpContext context)
        {
            string paramString = string.Empty;
            if (context.Request.Method == "GET")
            {
                paramString = context.Request.QueryString.Value;
            }
            else if (context.Request.Method == "POST")
            {
                context.Request.EnableBuffering();
                using (var reader = new StreamReader(context.Request.Body, encoding: Encoding.UTF8, detectEncodingFromByteOrderMarks: false, bufferSize: 5000, leaveOpen: true))
                {
                    paramString = reader.ReadToEnd();
                    // Reset the request body stream position so the next middleware can read it
                    context.Request.Body.Position = 0;
                }
            }


            // Start the Timer using Stopwatch  
            var watch = new Stopwatch();
            watch.Start();
            context.Response.OnStarting(() =>
            {
                // Stop the timer information and calculate the time   
                watch.Stop();
                string logMessageBody = string.Format("Request Path : {0} : Params : {1}  $ {2} ", context.Request.Path.Value, paramString, watch.ElapsedMilliseconds);
                logMessageBody = logMessageBody.Replace("{", "").Replace("}", "");
                Logger.LogInformation(logMessageBody, null);
                return Task.CompletedTask;
            });
            // Call the next delegate/middleware in the pipeline   
            return Next(context);
        }
    }
}
