﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;
using static NAVDashboard.Api.Framework.Core.CommonEnum;

namespace NAVDashboard.Api.Framework.Core
{
    public class ApiBaseConfiguration : IApiBaseConfiguration
    {

        [Range(10, 10, ErrorMessage = "Invalid Application id")]
        public short ApplicationId { get; set; }

        [Required]
        public string LoginServiceEndPoint { get; set; }

        public string NAVDashboardServiceUrl { get; set; }

        public string EnvironmentID { get; set; }

        public string EnvironmentName
        {
            get
            {

                ApplicationMode applicationMode;
                //if invalid Application mode is defined then use Unknown one
                if (Enum.TryParse(EnvironmentID, out applicationMode))
                {
                    if (Enum.IsDefined(typeof(ApplicationMode), applicationMode))
                        return applicationMode.ToString() + " Environment - ";
                    else
                        applicationMode = ApplicationMode.Unknown;

                }
                else
                {
                    applicationMode = ApplicationMode.Unknown;
                }
                return applicationMode.ToString() + " Environment - ";
            }
        }

        public string ErrorMailTo { get; set; }
        public string SMTPServer { get; set; }
        public int SMTPPort { get; set; }
        public string SMTPSenderName { get; set; }
        public string SMTPSenderEmail { get; set; }
        public string SMTPUserName { get; set; }
        public string SMTPPassword { get; set; }

        public string JwtKey { get; set; }
        public string JwtIssuer { get; set; }

        public string DomainPath { get; set; }
    }
}
