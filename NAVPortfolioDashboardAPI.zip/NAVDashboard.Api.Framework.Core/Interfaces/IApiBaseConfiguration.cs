﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAVDashboard.Api.Framework.Core
{
    public interface IApiBaseConfiguration
    {
        short ApplicationId { get; set; }
        string LoginServiceEndPoint { get; set; }

        string NAVDashboardServiceUrl { get; set; }
    }
}
