export interface FlagType {
    isRefreshing: boolean,
    isLoggingOut: boolean
}
