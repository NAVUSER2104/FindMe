import { AxiosRequestConfig } from "axios";
import * as R from 'ramda';
import config from 'react-global-configuration';

//Relative
import { setMessage } from "components/alerts/reducerAlert";
import { store } from "redux/store";
import { HTTP_OK, TOKEN_EXPIRED, TOKEN_INVALID, TOKEN_MISSING } from "helpers/constants";
import history from 'helpers/history';
import dashboardServiceInstance from "adapters/dashboardService";
import { FlagType } from "components/hoc/auth/type";
import AuthHttpHandlers from "components/hoc/auth/hooks/useAuthHttpHandlers";
import { setApplication } from "redux/reducerPersist";
import LoginReducer from "screens/login/reducerLogin";


const addAuthorizationHeaders = (config: AxiosRequestConfig) => 
{
debugger;
    const { loginReducer } = store.getState();
    config.headers['Authorization'] = `Bearer ${loginReducer.accessToken}`; //Add token in headers before request is sent
}

const reprocessFailedRequests = async (error: any, flagObj: FlagType, failedQueue: Array<any>) => {
    try {

        debugger;
        
        const originalRequest = R.prop('config', error);
        if (R.path(['response', 'data', 'status'], error) === TOKEN_EXPIRED && !originalRequest._retry) {

            if (flagObj.isRefreshing) // Some request is already sent to refresh the token, wait for its arrival
            {
                return await waitForRefreshToken(originalRequest, failedQueue)
            }
            return await sendRefreshCallWithQueue(flagObj, originalRequest, failedQueue)
        }
        else if ([TOKEN_MISSING, TOKEN_INVALID].includes(error.response.data.status)) {
            return await handleLogoutQueue(flagObj)
        }
    } catch (e) {
        console.log('Error in reprocessing token refresh request: ')
    }
    throw error;
}

const waitForRefreshToken = async (originalRequest: any, failedQueue: Array<any>) => {
    let token = await getRefreshToken(failedQueue)
    originalRequest.headers['Authorization'] = 'Bearer ' + token
    return dashboardServiceInstance()(originalRequest)
}

const sendRefreshCallWithQueue = async (flagObj: FlagType, originalRequest: any, failedQueue: Array<any>) => {
    flagObj.isRefreshing = true;

    try {
        debugger
        originalRequest._retry = true;
        let accessToken = await handleRefresh()
        processQueue(null, accessToken, failedQueue);

        return dashboardServiceInstance()(originalRequest);

    } catch (err) {
        failedQueue.length = 0;
        await handleLogoutQueue(flagObj, "session")
    } finally {
        flagObj.isRefreshing = false
    }
}

const handleRefresh = async () => {
    debugger
    const isProductionEnv = config.get('productionEnv') === "true";
    let accessToken: any = isProductionEnv ? await AuthHttpHandlers.post_refreshCall() : localStorage.getItem('Token')
        
   // let accessToken: any = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6IlZlZHByYWthc2giLCJhcHBsaWNhdGlvbiI6Ik5BVk1haW4yIiwidXNlcklEIjoiMjk3IiwibmJmIjoxNjM3MjM5NDk4LCJleHAiOjE2MzcyNDMwOTgsImlhdCI6MTYzNzIzOTQ5OH0.3QZPquE-m2q2nYMba5B5C8YnLHUBZKWYn_WMRwNcvWA';    
    
    let userData = extractUserClaim(accessToken);
     store.dispatch(LoginReducer.setAuthToken(accessToken))
     store.dispatch(LoginReducer.setUserData(userData));
    store.dispatch(setApplication(userData.application))
    return accessToken;
}

const processQueue = (error: any, token = null, failedQueue: Array<Promise<any>>) => {
    failedQueue.forEach((prom: any) => {
        if (error) {
            prom.reject(error);
        }
        else {
            prom.resolve(token)
        }

    });
    failedQueue.length = 0
}

const getRefreshToken = async (failedQueue: Array<any>) => {
    return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject })
    })
}

const handleLogoutQueue = async (flagObj: FlagType, type: string = "") => {

    if (!flagObj.isLoggingOut) {
        if (type === "session") {
            store.dispatch(setMessage({ message: 'Session expired. Please login again.', type: 'error' }))
            localStorage.removeItem('rload')
            history.push('/login')
            window.location.reload()
            return
        }
        flagObj.isLoggingOut = true;
        await handleLogout()
        flagObj.isLoggingOut = false;
    }
}

const handleLogout = async () => {
    try {
        //debugger
        let { status } = await AuthHttpHandlers.post_logoutCall()
        if (status === HTTP_OK) {
             store.dispatch(LoginReducer.setLogOut());
             store.dispatch(LoginReducer.logoutSuccess());
        }
    } catch (e) { }
    finally {
        localStorage.removeItem('rload')
        if (config.get('productionEnv') === "false") {
            localStorage.removeItem('Token')
        }
        history.push('/login')
        window.location.reload()
    }
}

const extractUserClaim = (token: string | undefined) => {
    if (token) {
        
        debugger;
        const splittedToken = R.split('.', token);
        const payload = JSON.parse(atob(splittedToken[1]));
        return {
            userID: payload.userID,
            //roleID: payload.roles[0],
            //loginID: payload.loginID,
            userName: payload.userName,
            //email: payload.email,
            application: payload.application
        };
    }
    return {};
}

const SecurityHandlers = {
    addAuthorizationHeaders,
    reprocessFailedRequests,
    handleRefresh,
    extractUserClaim,
    handleLogout,
}
export default SecurityHandlers