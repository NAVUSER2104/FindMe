// absolute imports
import * as R from 'ramda';
import CryptoJs from 'crypto-js';

// relative imports
import UrlStore from 'adapters/urlStore';
import authServiceInstance from 'adapters/authService';
import dashboardServiceInstance from 'adapters/dashboardService'; 
import { LoginRequest } from 'screens/login/type';
import { store } from 'redux/store';
import { SignUpRequest } from 'screens/signUp/type';
import DateHelpers from 'helpers/dateHelpers';
import UrlHelpers from 'helpers/urlHelpers';

const post_refreshCall = async () => 
{
  debugger;
    let { persistReducer } = store.getState()
    var res = await authServiceInstance().post(UrlStore.AuthUrl.RefreshToken, { grant_type: 'refresh_token', application: persistReducer.application }, {
        withCredentials: true
    });
    return R.path(['data', 'access_token'], res)
}

const post_loginCall = async (values: LoginRequest, type: boolean) => 
{
debugger;
    /*const user = {
        username: R.prop('username', values),
        password: CryptoJS.SHA256(R.prop('password', values)).toString(),
        application: R.prop('application', values)
    }
   */
    const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.AuthUrl.LoginUser,
                {
                    userName: R.prop('username', values)
                }
            );
            return await authServiceInstance().get(relativeUrl);
 
}
 
const post_registerCall = async (values: SignUpRequest) => {
    const user = {
        userName: R.prop('userName', values),
        password: CryptoJS.SHA256(R.prop('password', values)).toString(),
        email: R.prop('email', values),
    }
    return await authServiceInstance().post(UrlStore.AuthUrl.RegisterUser, user, {
        withCredentials: true
    });
}


const post_loginServiceID = async (userName: string) => {
    try {
        let res = await dashboardServiceInstance().post(UrlStore.LoginUrl.UpdateLoginServiceID, `"${userName}"`, {
            headers: {
                'Content-Type': 'application/json'
            }
        });
        return R.prop('data', res);
    } catch (e) { return 0 }
}

const post_logoutCall = async () => await authServiceInstance().post(UrlStore.AuthUrl.Logout, {}, {
    withCredentials: true
});

const AuthHttpHandlers = {
    post_refreshCall,
    post_loginCall, 
    post_registerCall,
    post_loginServiceID,
    post_logoutCall,
}
export default AuthHttpHandlers;