// absolute imports
import RamdaExtensions from 'helpers/ramda';
import { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';

// relative imports
  

const useReduxStateFill = (isAuthenticated: boolean) => { 
    const dispatch = useDispatch();
      

    useEffect(() => {
        if (isAuthenticated) {
            populateRedux()
        }
    }, [])

    const populateRedux = () => {
        (async () => {
            try {
                 
                var assignedFundsList, customGroupsList;
                 
                await assignedFundsList
                await customGroupsList

            } catch (e) { console.log(e) }
        })()
    }
}

export default useReduxStateFill;