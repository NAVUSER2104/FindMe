// absolute imports
import { FC, Fragment } from 'react';
import { RouteComponentProps } from 'react-router';
import { useSelector } from 'react-redux';
import { Redirect } from 'react-router';
import * as R from 'ramda';
// relative imports
//import LoginReducer from "screens/login/reducerLogin";
import useReduxStateFill from 'components/hoc/auth/hooks/useReduxStateFill'; 
import { menus } from 'components/navigations/SidebarNav';
import RamdaExtensions from 'helpers/ramda';
import { MenuItems } from 'components/navigations/type';
import { persistSelector } from 'redux/reducerPersist';

// If user is not authorized, render to Access Denied screen
const isAuthorized = (props: RouteComponentProps<any>, application: string) => {
    const route = props?.match?.path;
    if (route) {
        let menuItem: MenuItems = { key: '', subMenus: [], name: ''};
        R.forEach(x => {
            if (x.subMenus && !x.subMenus.length) {  // no submenu present
                if (R.equals(`/${x.key}`?.toLowerCase(), route?.toLowerCase())) {
                    menuItem = x
                }
            } else { // submenus present
                let result = x.subMenus.find(subMenu => R.equals(`/${x.key}/${subMenu.key}`?.toLowerCase(), route?.toLowerCase()))
                if (result) {
                    menuItem = result
                }
            }
        }, menus);

        if(!RamdaExtensions.empty(menuItem) && ( !menuItem.application || R.equals(menuItem.application?.toLowerCase(), application?.toLowerCase()))){
            return true;
        }
    }
    return false;
}
// If user not authenticated render out to root
const Authentication = (ComposedComponent: Function): FC<RouteComponentProps<any>> => function Auth(props: RouteComponentProps<any>) {
   // const { isAuthenticated } = useSelector(LoginReducer.loginSelector);  // get the redux value using the reducer
    const { application } = useSelector(persistSelector)
   // useReduxStateFill(isAuthenticated)

    // if (!isAuthenticated) {
    //     return <Redirect to={{ pathname: '/login', state: { from: props.location.pathname } }} />
    // }
    //else 
    if (!isAuthorized(props, application)) {
        return <Redirect to={{ pathname: '/AccessDenied', state: { from: props.location.pathname } }} />;
    }
    else {
        return (
            <Fragment>
                
                <ComposedComponent {...props} />
            </Fragment>
        )
    }
};

export default Authentication;