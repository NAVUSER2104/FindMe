import React, { FC } from 'react';

const EmptyLayout: FC = (props) => {
  return (
    <React.Fragment>
      {props.children}
    </React.Fragment>
  );
}
export default EmptyLayout;