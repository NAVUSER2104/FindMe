// absolute imports
import React, { FC, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Row, Col, Typography } from 'antd';
import { RouteComponentProps } from 'react-router';

// relative imports
import DateHelpers from 'helpers/dateHelpers';
import AlertContainer from 'components/alerts/AlertContainer';
import { alertSelector, setMessage } from 'components/alerts/reducerAlert';
import Login from 'screens/login/Login';
import SignUp from 'screens/signUp/SignUp';
import LoginHelpers from 'screens/common/login/hooks/useLoginHook';
import ForgotPassword from 'screens/forgotPassword/ForgotPassword';


// image & less, css
import Logo from 'assets/images/login-logo.png';
const { Text } = Typography;

const LoginLayout: FC<RouteComponentProps<any>> = (props: RouteComponentProps<any>) => {

    const [isLoginPage, setLoginPage] = useState(true)
    const [isForgotPasswordPage, setForgotPasswordPage] = useState(false)
    const [adData, setAdData] = useState()
    const { message, type } = useSelector(alertSelector);  // get the redux value using the reducer
    const dispatch = useDispatch()

    useEffect(() => {
        (async () => await LoginHelpers().fetchAdDetails(setAdData))()
    }, [])

    const onClose = () => dispatch(setMessage({ message: '', type: '' }));

    return (
        <React.Fragment>
            <Row className="vh-100">
                <Col lg={12} md={12} className="login-bg login-logo-overlay">
                    <Row align="middle" justify="center" className="h-100">
                        <Col>
                            <img src={Logo} alt="" className="d-block login-logo" />
                            <h2 className="login-title text-center py-1 text-uppercase mb-5 font-weight-light text-white">NAV Portfolio System</h2>
                        </Col>
                    </Row>
                </Col>
                <Col lg={12} md={12} className="login-bg p-0">
                    <Row align="middle" justify="center" className="h-100">
                        <Col lg={20} md={20}>
                            {isForgotPasswordPage ? <ForgotPassword {...props} adData={adData} /> :
                                (isLoginPage ? <Login {...props} adData={adData} /> : <SignUp {...props} adData={adData} />)}
                            <div className="w-100 text-center">
                                <Text>Don't have an account?
                                    {
                                        isLoginPage ? <span className="ml-2 text-link cursor-pointer" onClick={() => {
                                            setLoginPage(false)
                                            setForgotPasswordPage(false)
                                        }}> SignUp </span>
                                            : <span className="ml-2 text-link cursor-pointer" onClick={() => {
                                                setLoginPage(true)
                                                setForgotPasswordPage(false)
                                            }}>Login </span>
                                    }
                                    | <span className="text-link cursor-pointer" onClick={() => setForgotPasswordPage(true)}>
                                        Forgot Password</span>
                                </Text>
                                <br />
                                <small className="text-muted">© {DateHelpers.getCopyrightYear()} NAV Consulting, Inc. All Rights Reserved.</small>
                                {message &&
                                    <Row className="w-100 py-2">
                                        <Col md={12} lg={12} xl={12} className="flex-column mx-auto align-self-center" style={{ zIndex: 10 }}>
                                            <AlertContainer message={message} type={type} onClose={onClose} />
                                        </Col>
                                    </Row>
                                }
                            </div>
                        </Col>
                    </Row>
                </Col>
            </Row>
        </React.Fragment>
    )
};

export default LoginLayout;