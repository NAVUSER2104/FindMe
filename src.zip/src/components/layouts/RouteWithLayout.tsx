import { Route } from 'react-router-dom';

const RouteWithLayout = ({ Component, ...rest }: { [x: string]: any; Component: any }) => (
  <Route {...rest} render={props =>
      <Component {...props} />
  }
  />
);
export default RouteWithLayout;