// absolute imports
import React, { FC } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Layout } from 'antd';


// relative imports
import SidebarNav from 'components/navigations/SidebarNav';
import { sidebarSelector, setCollapsed } from 'components/navigations/reducerSidebar';

const MainLayout: FC = (props) => {
    const dispatch = useDispatch();
    const sidebarState = useSelector(sidebarSelector);
    const toggle = () => dispatch(setCollapsed(!sidebarState.collapsed));

    return (
        <React.Fragment>
            <Layout style={{ minHeight: "100vh" }}>
                <SidebarNav collapsed={sidebarState.collapsed} handleToggle={toggle} />
                <Layout>
                    <div className={`main-wrapper-container ${sidebarState.collapsed ? "sidebar-collasped" : "sidebar-expaned"}`}>
                       {props.children}
                    </div>
                </Layout>
            </Layout>
        </React.Fragment>
    );
}

export default MainLayout;