export interface IOptions {
    displayValue?: string,
    id: string;
    selected: boolean;
    icon?: React.ReactNode;
    size?: 'small' | 'middle' | 'large' | undefined;
}

export interface IButtonGroupProps {
    data: Array<IOptions>;
    handler: (currentKeyValue: IOptions, data: Array<IOptions>) => void;
}