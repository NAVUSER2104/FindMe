// absolute imports
import { FC } from 'react';
import { Button, Layout } from 'antd';

// relative imports
import { IButtonGroupProps, IOptions } from 'components/buttonGroup/type';
import useButtonGroupHook from 'components/buttonGroup/hooks/useButtonGroupHook';
import RamdaExtensions from 'helpers/ramda';

const { Content } = Layout;
const CustomButtonGroup: FC<IButtonGroupProps> = (props: IButtonGroupProps) => {
    const { onClick, state } = useButtonGroupHook(props);

    return (
        <Content>
            {RamdaExtensions.mapIndexed((record: IOptions, index: number) => (
                <Button className='mr-01' key={index} size={record.size} type={record.selected ? "primary" : "default"} value={record.id} icon={record.icon}
                    onClick={(event) => onClick(event, record.id)}>{record.displayValue}</Button>
            ), state.buttonData)}
        </Content>
    );
}

export default CustomButtonGroup