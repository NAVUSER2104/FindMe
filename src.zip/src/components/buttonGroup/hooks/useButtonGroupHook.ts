// absolute imports
import { useEffect, useState } from 'react';
import * as R from 'ramda';

// relative imports
import { IButtonGroupProps, IOptions } from "components/buttonGroup/type";

const useButtonGroupHook = (props: IButtonGroupProps) => {
    const [state, setState] = useState({
        buttonData: props.data,
    });

    useEffect(() => {
        setState({ buttonData: props.data });
    }, [props.data]);

    const onClick = (e: any, key: any) => {
        let changedValueData: any;
        const changedData: any = R.forEach((record: IOptions) => {
            if (record.id === key) {
                record.selected = !record.selected;
                changedValueData = record;
                return;
            }
        }, state.buttonData);
        setState((prev) => ({ ...prev, buttonData: changedData }));
        if (typeof (props.handler) === "function") {
            props.handler(changedValueData, changedData);
        }
    };

    return {
        state,
        onClick,
    }
}

export default useButtonGroupHook;