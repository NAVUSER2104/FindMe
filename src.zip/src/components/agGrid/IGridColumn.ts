import { IsColumnFunc, GetDataFunc } from "components/agGrid/CommonFunctions";
import { ValueFormatter } from "helpers/enum";

export type CheckBoxColorsType = "green" | "red" | "blue" | "purple" | "orange" | "white" | "darkblue" | "grey";
type EditType = "Text" | "Number" | "Checkbox" | "Combo" | "Multiline";
export type IconsType = "lock" | "unlock" | "edit" | "copy" | "delete" | "plus" | "minus" | "close" | "check" | "warning";

interface IComponent {
  style?: {};
  className?: string;
  enabled?: boolean | IsColumnFunc;
  onClick?: (params: any) => void;
  data?: any;
}

export interface IButtonComponent extends IComponent {
  name?: string;
}

export interface ICustomComponent extends IComponent {
  comp: JSX.Element | React.Component | React.FC | null;
  compType?: "element" | "component";
}

export interface ComponentSelectorResult { component?: string; params?: any; }
export interface ICellRendererComp extends ICellRenderer { }
export interface ICellRenderer { refresh(params: any): boolean; }
export interface ICellRendererFunc { (params: any): HTMLElement | string; }

export interface IDateComponent {
  className?: string;
  readOnly?: boolean | IsColumnFunc;
  value: Date | Date[];
  format: string;
  defaultDate?: Date | Date[];
  onChange?: (params: any, data: any) => void;
  data?: any;
}

interface GridColumnEdit {
  editType: EditType;
  comboData?: [] | GetDataFunc;
  enabled?: boolean | IsColumnFunc;
  hidden?: boolean | IsColumnFunc;
  /** If below value is defined then we will ignore the field value and use below else field value */
  checkBoxValue?: boolean | IsColumnFunc;
  /**if defined then we apply the given color on checkbox else it will render as normal */
  checkBoxColor?: CheckBoxColorsType | ((params: any) => CheckBoxColorsType);
}

export interface IDefGridColumn {
  minWidth?: number;
  sortable?: boolean;
  filter?: string | boolean;
  resizable?: boolean;
  enableRowGroup?: boolean;
  enableValue?: boolean;
  enablePivot?: boolean
}

export interface IHeader {
  /** true, if you want checkbox in grid header*/
  checkBox?: boolean | IsColumnFunc;
  /** Enable/Disable header checkbox*/
  disableCheckBox?: boolean | IsColumnFunc;
  /**which icon you want to add */
  icon?: IconsType | ((params: any) => IconsType);
  /**If you want to give custom color to icon */
  iconColor?: string;
  /** change the size of icon; you can also define size in px as per your requirement */
  iconSize?: "small" | "medium" | "large" | string;
  /** Default icon will be visible before text*/
  iconPosition?: "beforeText" | "afterText";
  /**if you want to add custom css class on your header along with ag grid classes */
  cssClass?: string;
  /**On click of header. In case of checkbox below event will not work */
  onClick?: (params: any) => void;
}

export interface IGridColumn {
  /** header name of column */
  headerName: string;
  /** column in data set*/
  field?: string;
  /** if you want to use any custom componenet*/
  cType?: "Normal" | "Button" | "Date" | "Custom";
  colId?: string;
  hide?: boolean;
  pinned?: boolean;
  resizable?: boolean;
  sortable?: boolean;
  filter?: string | boolean;
  editable?: boolean | IsColumnFunc;
  editor?: GridColumnEdit;
  cellEditorSelector?: (params: any) => void; 
  /** enable grouping from tool bar*/
  enableRowGroup?: boolean;
  /** enable aggregation from tool bar*/
  enableValue?: boolean;
  /** enable pivot from tool bar*/
  enablePivot?: boolean;
  minWidth?: number;
  maxWidth?: number;
  /** define the componenet prperties which you wanted to use*/
  component?: IButtonComponent | IDateComponent | ICustomComponent;
  cellStyle?: {} | ((params: any) => {});
  cellClass?: string | string[] | ((cellClassParams: any) => string | string[]);
  tooltipField?: string;
  tooltip?: (params: any) => string;
  tooltipValueGetter?: (params: any) => string;
  singleClickEdit?: boolean;
  /**true, if you want to group data on the basis of this column*/
  rowGroup?: boolean;
  /**Provide the child columns*/
  children?: IGridColumn[];
  /** Set to true to render a selection checkbox in the column. */
  checkboxSelection?: boolean | IsColumnFunc;
  /** If true, a 'select all' checkbox will be put into the header */
  headerCheckboxSelection?: boolean | IsColumnFunc;
  /** If true, the header checkbox selection will work on filtered items*/
  headerCheckboxSelectionFilteredOnly?: boolean;
  /** Whether to show the column when the group is open / closed. */
  columnGroupShow?: "open" | "closed";
  cellRenderer?: { new(): ICellRendererComp; } | ICellRendererFunc | string;
  cellRendererSelector?: (params: any) => ComponentSelectorResult;
  cellRendererParams?: any;
  cellRendererFramework?: any;
  valueFormatter?: ValueFormatter | ((data: any) => void);
  suppressMenu?: boolean;
  valueGetter?: (params: any) => void;
  onCellClicked?: (params: any) => void;
  type?: "numericColumn" | "rightAligned";
  /**If you want to customize your header such as adding checkbox or icon */
  customHeader?: IHeader;
}