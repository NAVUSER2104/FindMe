// absolute imports
import React, { Component } from "react";
import { Button, DatePicker } from "antd";
import moment from "moment";
import {
  UnlockTwoTone,
  LockTwoTone,
  EditTwoTone,
  CopyTwoTone,
  DeleteTwoTone,
  PlusCircleTwoTone,
  MinusCircleTwoTone,
  CloseCircleTwoTone,
  CheckCircleTwoTone,
  WarningTwoTone,
} from "@ant-design/icons";

// relative imports
import { IButtonComponent, ICustomComponent, IDateComponent, IHeader, IconsType } from "components/agGrid/IGridColumn";
import { GetValueForComp, GetColumnPropFromRow, ErrorHandler } from "components/agGrid/CommonFunctions";

// less
import "assets/styles/components/componentStyle.less";

export class ButtonComponent extends Component<IButtonComponent> {
  render() {
    if (this.props.data !== undefined) {
      return (
        <Button
          style={this.props.style}
          className={this.props.className}
          onClick={() => (this.props.onClick !== undefined ? this.props.onClick(this.props) : undefined)}
          disabled={GetValueForComp(this.props.enabled, this.props)}
          name={this.props.name}
        ></Button>
      );
    } else return null;
  }
}

export class CustomComponent extends Component<ICustomComponent> {
  component = () => {
    if (this.props.comp && this.props.data) {
      return React.cloneElement(this.props.comp as JSX.Element, {
        style: this.props.style,
        className: this.props.className,
        disabled: !GetValueForComp(this.props.enabled, this.props),
        onClick: () => (this.props.onClick !== undefined ? this.props.onClick(this.props) : undefined),
      });
    } else {
      return null;
    }
  };
  render() {
    return this.component();
  }
}

export class DateComponent extends Component<IDateComponent | any> {
  render() {
    if (this.props.data !== undefined) {
      return (
        <DatePicker
          className={this.props.className}
          onChange={(e, data) => (this.props.onChange !== undefined ? this.props.onChange(this.props, data) : undefined)}
          format={this.props.format}
          defaultValue={this.props.getValue() === "Invalid date" || this.props.getValue() === undefined ? undefined : moment(this.props.getValue())}
          disabled={GetValueForComp(this.props.readOnly, this.props)}
        />
      );
    } else {
      return null;
    }
  }
}

export class CustomHeaderComponent extends Component<IHeader | any> {
  private myRef: any;
  state: any;
  constructor(props: any) {
    super(props);
    this.myRef = React.createRef();
    this.state = {
      checked: false,
      checkBox: true,
      disableCheckBox: false,
      showIcon: false,
      icon: null,
      iconBeforeText: true,
      isSortedAsc: false,
    };
  }

  componentDidMount() {
    const checkBox = GetValueForComp(this.props.checkBox, this.props);
    const disableCheckBox = GetValueForComp(this.props.disableCheckBox, this.props);
    const iconName = GetValueForComp(this.props.icon, this.props);
    const iconColor = this.props.iconColor;
    const iconSize = this.props.iconSize ? this.props.iconSize : "medium";
    const icon = this.getIcon(iconName, iconColor, iconSize);
    const showIcon = icon === undefined ? false : true;
    const iconBeforeText = this.props.iconPosition === undefined || this.props.iconPosition === "beforeText";
    const checkBoxValue = GetValueForComp(this.props.checkBoxValue, this.props);
    this.setState({
      checkBox: checkBox === undefined ? false : checkBox,
      disableCheckBox: disableCheckBox === undefined ? false : disableCheckBox,
      showIcon: showIcon,
      icon: icon,
      iconBeforeText: iconBeforeText,
      checked: checkBoxValue
    });
  }

  getIcon = (iconName: IconsType, iconColor: string, iconSize: string) => {
    let icon;
    switch (iconName) {
      case "lock":
        icon = <LockTwoTone />;
        break;
      case "unlock":
        icon = <UnlockTwoTone />;
        break;
      case "edit":
        icon = <EditTwoTone />;
        break;
      case "copy":
        icon = <CopyTwoTone />;
        break;
      case "delete":
        icon = <DeleteTwoTone />;
        break;
      case "plus":
        icon = <PlusCircleTwoTone />;
        break;
      case "minus":
        icon = <MinusCircleTwoTone />;
        break;
      case "close":
        icon = <CloseCircleTwoTone />;
        break;
      case "check":
        icon = <CheckCircleTwoTone />;
        break;
      case "warning":
        icon = <WarningTwoTone />;
        break;
      default:
        return undefined;
    }
    return React.cloneElement(icon, {
      style: { "font-size": iconSize },
      twoToneColor: iconColor,
    });
  };

  updateState = (e: any) => {
    const currentVal = e.target.checked;
    this.setState({ checked: currentVal });
    this.selectAllRows(currentVal);
  };

  selectAllRows = (bool: boolean) => {
    try {
      const field = this.props.field;
      this.props.api.forEachNode((row: any) => {
        const colProp = GetColumnPropFromRow(row, field, "edit");
        let colVal = true;
        if (colProp !== undefined) {
          colVal = GetValueForComp(colProp, row);
        }
        //if checkbox is diabled then exclude that checkbox
        if (colVal) {
          const rowData = row.data;
          rowData[field] = rowData[field] !== null ? bool : null;
        }
      });
      this.props.api.refreshCells();
    } catch (error) {
      ErrorHandler("selectAllRows", error, bool);
    }
  };

  showMenu = () => {
    if (this.myRef) {
      this.props.showColumnMenu(this.myRef.current);
    }
  };

  handleClick = (e: any) => {
    if (!this.state.checkBox && this.props.onClick !== undefined) {
      this.props.onClick(this.props);
    } else {
      const sortDesc = this.state.isSortedAsc;
      this.props.setSort(sortDesc ? "desc" : "asc", e.shiftKey);
      this.setState({ isSortedAsc: !sortDesc });
    }
  };

  render() {
    return (
      <div className={"customHeader ag-cell-label-container ag-header-cell-sorted-none " + this.props.cssClass}>
        <span
          hidden={this.props.isSuppressMenu}
          ref={this.myRef}
          id={this.props.field}
          className="ag-header-icon ag-header-cell-menu-button"
          aria-hidden="true"
          onClick={this.showMenu}
        >
          <span className="ag-icon ag-icon-menu" unselectable="on" role="presentation"></span>
        </span>
        <div className="ag-header-cell-label">
          {this.state.checkBox ? (
            <input
              type="checkbox"
              className="chkbx"
              name={this.props.displayName}
              onChange={(e: any) => this.updateState(e)}
              disabled={this.state.disableCheckBox}
              checked={this.state.checked}
            />
          ) : null}
          <div className="content">
            <div className="icon">{this.state.showIcon && this.state.iconBeforeText ? this.state.icon : null}</div>
            <div>
              <span onClick={(e) => this.handleClick(e)} className="ag-header-cell-text valign-middle">
                {this.props.displayName}
              </span>
              <span className="icon mr-1">{this.state.showIcon && !this.state.iconBeforeText ? this.state.icon : null}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
