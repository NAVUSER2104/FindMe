export interface IsColumnFunc {
  (params: any): boolean;
}

export function GetValue(value: any, data: any, params: any) {
  if (value !== undefined && typeof value === "function" && data !== undefined && data.length > 0) {
    return value(params);
  } else {
    return value;
  }
}

export function GetValueForComp(value: any, params: any) {
  if (value !== undefined && typeof value === "function") {
    return value(params);
  } else {
    return value;
  }
}

export interface GetDataFunc {
  (params: any): [];
}

function GetColumnFromRow(row: any, column: string) {
  if (row !== undefined && row.columnController.columnDefs !== undefined) {
    for (const col of row.columnController.columnDefs) {
      if (col.headerName !== undefined && col.headerName === column) {
        return col;
      }
    }
  }
}

export function GetColumnPropFromRow(row: any, column: string, property: string) {
  const col = GetColumnFromRow(row, column);
  if (col !== undefined) {
    return col[property];
  }
}

export function ErrorHandler(functionName: string, exception: any, ...params: any) {
  console.log("Error occured in Function: " + functionName + " exception: " + exception + " params: " + params);
}

export function sizeColumnsToFit(gridApi: any){
  const handler = setTimeout(() => {
    if (gridApi && gridApi.api) {
      gridApi.api.sizeColumnsToFit();
    }
  }, 150);
  return () => {
    clearTimeout(handler);
  };
};