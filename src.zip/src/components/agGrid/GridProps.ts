import { IGridColumn, IDefGridColumn } from "components/agGrid/IGridColumn";
import { IsColumnFunc } from "components/agGrid/CommonFunctions";

export interface ITreeData {
  /**column name which contains heirarchical data*/
  dataKey: string;
  /** header name of column*/
  headerName: string;
  /** column in data set*/
  field: string;
  minWidth?: number;
  maxWidth?: number;
}
export interface IProps {
  /**grid data that you want to show in grid*/
  data: any;
  /** List of columns*/
  columns: IGridColumn[];
  /** default properties that you want to set on all columns*/
  defColumns: IDefGridColumn;
  /** to show/hide loading in grid*/
  showLoading?: boolean;
  /** if you want alternate colors in rows [default true]*/
  showRowAlternateColors?: boolean;
  /** if you want different colors in editable columns [default false]*/
  highlightEditableColumn?: boolean;
  stopEditingWhenGridLosesFocus?: boolean;
  enableBrowserTooltips?: boolean;
  /**array of columns which you want to hide from grid*/
  hiddenColumnList?: string[];
  /** array of columns on which you want to apply grouping*/
  groupBy?: string[];
  /** array of columns which you want to allow grouping from menu bar*/
  groupByMenuBar?: string[];
  /**callback tells the grid to use the 'id' attribute for IDs, IDs should always be strings */
  getRowNodeId?: (params: any) => number;
  /**when grid first initialize, provide GridApi*/
  onGridInitialize?: (params: any) => void;
  /** fires after you use setRowData*/
  onRowDataChanged?: (params: any) => void;
  /** fires whenevr the editable column value change*/
  onCellValueChanged?: (key: string, params: any) => void;
  /**set row style*/
  getRowStyle?: (params: any) => void;
  /* set row class rules*/
  rowClassRules?: any;
  /** set cell style*/
  setCellStyle?: (key: string, params: any) => void;
  suppressScrollOnNewData?: boolean;
  headerHeight?: number;
  rowBuffer?: number;
  suppressHorizontalScroll?: boolean;
  /**if provided it will render the given compennet for each row. you will get grid data in props of your component*/
  detailedRowComponent?: React.Component | React.FC;
  detailRowHeight?: number;
  /**if your data has tree data*/
  treeData?: ITreeData;
  /**If ture and grouping is enabled then group row will be use entire width to show group name */
  groupUseEntireRow?: boolean;
  /**If full width row is defined then this in that row below given component will render */
  fullWidthCellRendererComponenet?: React.Component | React.FC;
  rowSelection?: "single" | "multiple";
  isRowSelectable?: IsColumnFunc;
  onRowSelected?: (params: any) => void;
  detailCellRendererParams?: any;
  suppressRowClickSelection?: boolean;
  /**To export detail grid columns if any; provide field name */
  detailedGridColumns?: string[];
  showDataLoadingMessage?: boolean;
  enableRangeSelection?: boolean;
  suppressMultiRangeSelection?: boolean;
  onRangeSelectionChanged?: (params: any) => void;
  pinnedData?: any;
  onRowClicked?: (params: any) => void;
}

export interface IState {
  gridApi: any;
  columnDefs: any;
  showLoading: boolean;
  /**true, if expand all is clicked*/
  allNodeExpanded: boolean;
  /**grid data*/
  data: any;
  /**true; if data grouping is defined in grid*/
  isGroupingDefined: boolean;
  /**true; if we have added any custom column in grid to provide expand/collapse button*/
  isCustomGroupColumnAdded: boolean;
  /**List of columns on which grouping is enabled*/
  groupedColumns: string[];
}
