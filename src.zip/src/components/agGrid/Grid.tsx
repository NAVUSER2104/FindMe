// asbolute imports
import React from "react";
import { AgGridReact } from "ag-grid-react";

// relative imports
import { IProps, IState } from "components/agGrid/GridProps";
import { IGridColumn } from "components/agGrid/IGridColumn";
import { IsColumnFunc, GetValue, ErrorHandler } from "components/agGrid/CommonFunctions";
import { ButtonComponent, DateComponent, CustomComponent, CustomHeaderComponent } from "components/agGrid/CustomComponent";
import { NumericEditor } from "components/agGrid/hooks/CustomEditors";
import DateHelpers from "helpers/dateHelpers";
import { ValueFormatter } from "helpers/enum";
import openNotification from "components/notification/notification";

// css, less & icons
import "ag-grid-community/dist/styles/ag-grid.css";

import "assets/styles/components/gridStyle.less";
import * as R from "ramda";
import RamdaExtensions from "helpers/ramda";

class WebGrid extends React.Component<IProps, IState> {
  state: IState = {
    gridApi: null,
    columnDefs: null,
    showLoading: false,
    allNodeExpanded: false,
    data: [],
    isGroupingDefined: false,
    isCustomGroupColumnAdded: false,
    groupedColumns: [],
  };

  /** Define default values of props */
  static defaultProps: IProps = {
    data: [],
    columns: [],
    defColumns: { sortable: true, filter: true, resizable: true },
    showLoading: false,
    stopEditingWhenGridLosesFocus: false,
    enableBrowserTooltips: false,
    showRowAlternateColors: true,
    highlightEditableColumn: false,
    headerHeight: 30,
    rowBuffer: 100,
    showDataLoadingMessage: false,
  };

  //#region variables
  gridOptions: any = null;
  columnsDef: any = null;
  rowIndex: number = 0;
  rowClassRules: {} = {};
  treeColumnDef: {} = {};
  frameworkComponent = {
    buttonComponent: ButtonComponent,
    dateComponent: DateComponent,
    customComponent: CustomComponent,
    numericEditor: NumericEditor,
    customHeaderComponent: CustomHeaderComponent,
  };
  waitMessageAdded: boolean = false;
  //#endregion

  //#region Class events
  componentDidMount() {
    try {
      this.prepareGridOptions();
      this.setAndUpdateData();
    } catch (ex) {
      ErrorHandler("componentDidMount", ex, null);
    }
  }

  /** Prepare the grid columns from supplied column definations or from data itself */
  prepareColumns = (isRepetative: boolean) => {
    this.columnsDef = this.initColumns(this.props, isRepetative);
    if (R.path(["detailCellRendererParams", "detailGridOptions"], this.props)) {
      this.props.detailCellRendererParams.detailGridOptions.columnDefs = this.initColumns(
        this.props.detailCellRendererParams.detailGridOptions,
        isRepetative
      );
      delete this.props.detailCellRendererParams.detailGridOptions.columns;
    }
  };

  /** Prepare grid options */
  prepareGridOptions = () => {
    try {
      this.prepareColumns(false);
      const defColumnDef = this.initDefColumns(this.props);
      this.getRowClassRules();
      this.getTreeColumnDef();
      this.gridOptions = {
        suppressLoadingOverlay: true,
        detailCellRendererFramework: this.props.detailedRowComponent !== undefined ? this.props.detailedRowComponent : undefined,
        masterDetail: true,
        detailRowHeight: this.props.detailRowHeight,
        showRowGroup: this.props.detailedRowComponent !== undefined ? true : undefined,
        treeData: this.props.treeData !== undefined ? true : undefined,
        getDataPath: this.props.treeData !== undefined ? this.getDataPath : undefined,
        autoGroupColumnDef: this.props.treeData !== undefined ? this.treeColumnDef : undefined,
        getRowStyle: this.getRowStyle,
        rowClassRules: this.props.rowClassRules !== undefined ? { ...this.rowClassRules, ...this.props.rowClassRules } : this.rowClassRules,
        headerHeight: this.props.headerHeight,
        rowBuffer: this.props.rowBuffer,
        suppressScrollOnNewData: this.props.suppressScrollOnNewData,
        getRowNodeId: this.props.getRowNodeId,
        suppressHorizontalScroll: this.props.suppressHorizontalScroll,
        fullWidthCellRendererFramework: this.props.fullWidthCellRendererComponenet,
        groupUseEntireRow: this.props.treeData === undefined ? this.props.groupUseEntireRow : false,
        defaultColDef: defColumnDef,
        detailCellRendererParams: this.props.detailCellRendererParams,
        groupDefaultExpanded: this.props.detailCellRendererParams !== undefined,
        detailRowAutoHeight: this.props.detailCellRendererParams !== undefined,
        sideBar: {
          toolPanels: [
            {
              id: "columns",
              labelDefault: "Columns",
              labelKey: "columns",
              iconKey: "columns",
              toolPanel: "agColumnsToolPanel",
            },
            {
              id: "filters",
              labelDefault: "Filters",
              labelKey: "filters",
              iconKey: "filter",
              toolPanel: "agFiltersToolPanel",
            },
          ],
          hiddenByDefault: true,
        },
        getContextMenuItems: (params: any) => this.getContextMenuItems(params),
        isFullWidthCell: (rowNode: any) => this.isFullWidthCell(rowNode),
        defaultExportParams: {
          getCustomContentBelowRow: this.getCustomContentBelowRow,
        },
        excelStyles: [
          {
            id: "header",
            interior: {
              color: "#aaaaaa",
              pattern: "Solid",
            },
          },
        ],
        //getMainMenuItems: this.getMainMenuItems,//if you want customize column menu
      };
    } catch (error) {
      ErrorHandler("prepareGridOptions", error, null);
    }
  };

  /** Show/Hide loading on grid */
  showLoading = (api: any) => {
    if (this.props.showLoading || this.state.showLoading) {
      api.showLoadingOverlay();
      this.waitMessage();
    } else {
      api.hideOverlay();
    }
  };

  waitMessage = () => {
    if (!this.waitMessageAdded && this.props.showDataLoadingMessage) {
      setTimeout(() => {
        this.waitMessageAdded = false;
        if (this.props.showLoading || this.state.showLoading) {
          openNotification({
            notificationType: "Info",
            message: "Data loading is taking time. Please wait..",
          });
          this.waitMessage();
        }
      }, 30000);
      this.waitMessageAdded = true;
    }
  };

  componentDidUpdate(prevProps: IProps) {
    if (this.state.gridApi && this.state.gridApi !== undefined) {
      if (this.props.data !== prevProps.data) {
        if (
          (this.props.columns === undefined || this.props.columns.length === 0) &&
          (this.columnsDef === undefined || this.columnsDef.length === 0) &&
          this.props.data !== undefined
        ) {
          this.prepareColumns(false);
        }
        this.setAndUpdateData();
      } else if (this.props.showLoading !== prevProps.showLoading) {
        this.showLoading(this.state.gridApi);
      } else {
        this.setAndUpdateData();
      }
      if (this.props.columns !== prevProps.columns) {
        this.prepareColumns(true);
      }
      if (this.props.data !== undefined && this.props.data.length === 0 && !this.props.showLoading && !this.state.showLoading) {
        this.state.gridApi.showNoRowsOverlay();
      }
      this.waitMessage();
    }
  }

  //#endregion

  //#region private events
  onGridReady = (params: any) => {
    try {
      this.setState((prev) => ({ ...prev, gridApi: params.api }));
      if (this.props.onGridInitialize !== undefined) this.props.onGridInitialize(params);
    } catch (error) {
      ErrorHandler("onGridReady", error, params);
    }
  };

  /** If you wanted to apply any classes on rows on the basis of some condition. Here we are applying alternate colors */
  getRowClassRules = () => {
    try {
      if (this.props.showRowAlternateColors) {
        this.rowClassRules = {
          "row-odd": (params: any) => {
            return params.node.rowIndex % 2 !== 0;
          },
          "row-even": (params: any) => {
            return params.node.rowIndex % 2 === 0;
          },
        };
      }
    } catch (error) {
      ErrorHandler("getRowClassRules", error, null);
    }
  };

  /** If you are using Tree data; then you need to specify the column which has the hierarchy data */
  getDataPath = (data: any) => {
    try {
      return data.mapperCol;
    } catch (error) {
      ErrorHandler("getDataPath", error, data);
    }
  };

  /**If cell will take the entire width of grid row */
  isFullWidthCell = (rowNode: any) => {
    try {
      if (this.props.treeData !== undefined && this.state.groupedColumns.length > 0 && this.props.groupUseEntireRow) {
        return this.state.groupedColumns[rowNode.level] !== undefined;
      }
      return false;
    } catch (error) {
      ErrorHandler("isFullWidthCell", error, rowNode);
    }
  };

  /** Copy the data from props to state
   * if detailedRowComponent is defined and our first cell is using custom component then we add 1 dummy column to provide expand collapse functionality
   * If treeData is defined then we are building the hierarchy data from our data
   */
  setAndUpdateData = () => {
    try {
      let data: any = [];
      if (this.props.detailedRowComponent !== undefined && this.state.isCustomGroupColumnAdded) {
        if (this.props.data !== undefined) {
          for (const d of this.props.data) {
            d["@grpCol"] = " ";
            data.push(d);
          }
        }
      } else if (this.props.treeData !== undefined && this.props.treeData.dataKey !== undefined) {
        data = this.flattenChildrenRecursively(this.props.data, this.props.treeData.dataKey);
      } else {
        data = this.props.data;
      }
      this.setState((prev) => ({ ...prev, data: data }));
    } catch (error) {
      ErrorHandler("setAndUpdateData", error, null);
    }
  };

  /** If we set TreeData = true then by default grid creates 1 Group column so here we override the properties of that group column */
  getTreeColumnDef = () => {
    try {
      if (this.props.treeData !== undefined && this.props.treeData.dataKey !== undefined) {
        const field: string = this.props.treeData.field;
        const groupedColumns = this.state.groupedColumns;
        this.treeColumnDef = {
          headerName: this.props.treeData.headerName,
          minWidth: this.props.treeData.minWidth,
          maxWidth: this.props.treeData.maxWidth,
          valueGetter: (params: any) => {
            if (params.data !== undefined) {
              return params.data[field];
            } else {
              if (groupedColumns.length > 0) {
                const colName = groupedColumns[params.node.level];
                return this.getGroupNameValue(params.node.allLeafChildren, colName);
              }
            }
          },
          cellRendererParams: {
            suppressCount: true,
          },
        };
      }
    } catch (error) {
      ErrorHandler("getTreeColumnDef", error, null);
    }
  };

  /** Get the value of the group column when tree + group is defined */
  getGroupNameValue = (childRows: any, colName: string) => {
    try {
      if (childRows !== undefined && childRows.length > 0) {
        for (const child of childRows) {
          if (child.data !== undefined) {
            return child.data[colName];
          }
        }
      }
    } catch (error) {
      ErrorHandler("getGroupNameValue", error, [childRows, colName]);
    }
  };

  /** If TreeData is defined then we have to flattern our Parent/child data */
  flattenChildrenRecursively = (data: any, heirarchyKey: string, parent: any = null, childHierarchy: any = null) => {
    try {
      let newData: any = [];

      if (data) {
        data.forEach((initialRow: any, parentIndex: number) => {
          let parentHierarchy: any = [];
          if (!parent) {
            const mapperColVal = this.buildTreeAndGroupData(initialRow);
            parentHierarchy = mapperColVal;
          }
          initialRow = Object.assign({ mapperCol: parentHierarchy }, initialRow);

          if (parent) {
            initialRow.parent = parent;
            parentHierarchy = [...childHierarchy];
            initialRow.mapperCol = parentHierarchy;
          }
          parentHierarchy.push(parentIndex);
          newData.push(initialRow);

          if (initialRow[heirarchyKey]) {
            newData = [...newData, ...this.flattenChildrenRecursively(initialRow[heirarchyKey], heirarchyKey, initialRow, parentHierarchy)];
          }
        });
      }

      return newData;
    } catch (error) {
      ErrorHandler("flattenChildrenRecursively", error, [data, heirarchyKey, parent, childHierarchy]);
    }
  };

  /** When tree + group data is defined we are generating a mappercol with the combination of heirarchy data and groups*/
  buildTreeAndGroupData = (dataRow: any) => {
    try {
      let mapperCol = [];
      if (this.state.groupedColumns.length > 0) {
        for (const column of this.state.groupedColumns) {
          const dataVal = dataRow[column];
          if (dataVal !== undefined) {
            mapperCol.push(dataVal);
          }
        }
      }
      return mapperCol;
    } catch (error) {
      ErrorHandler("buildTreeAndGroupData", error, dataRow);
    }
  };

  getCustomContentBelowRow = (params: any) => {
    let childData: any = [];
    const detailedGridColumns = this.props.detailedGridColumns;
    if (detailedGridColumns !== undefined && detailedGridColumns.length > 0) {
      let headers: any = [];
      let body: any = [];
      headers.push(this.cell("", "header"));
      body.push(this.cell("", "body"));
      for (const column of detailedGridColumns) {
        if (column !== "") {
          headers.push(this.cell(column, "header"));
          body.push(this.cell(params.node.data[column], "body"));
        }
      }
      childData.push(headers);
      childData.push(body);
    }
    return childData;
  };

  cell = (text: string, styleId: string) => {
    return {
      styleId: styleId,
      data: {
        type: /^\d+$/.test(text) ? "Number" : "String",
        value: String(text),
      },
    };
  };

  /** If you want to change the column menu items */
  // getMainMenuItems = (params: any) => {
  //   return params.defaultItems;
  // };

  /** Updating default context menus
   * Adding an option of SideBar to show/hide sidebar
   * If grouping is enabled on grid then add expand/collapse all button
   */
  getContextMenuItems = (params: any) => {
    try {
      var result: any = ["copy", "copyWithHeaders", "export"];
      if (params.api && params.api !== undefined) {
        result.push({
          name: "SideBar",
          checked: params.api.isSideBarVisible(),
          action: () => {
            params.api.setSideBarVisible(!params.api.isSideBarVisible());
          },
          tooltip: "Show/Hide SideBar",
        });
        //Expand/Collapse option for detailed row
        if (this.props.detailedRowComponent !== undefined || this.state.isGroupingDefined || this.props.treeData !== undefined) {
          result.push({
            name: "Expand/Collapse All",
            checked: this.state.allNodeExpanded,
            action: () => {
              const isExpended = this.state.allNodeExpanded;
              params.api.forEachNode(function (node: any) {
                node.expanded = !isExpended;
              });
              this.setState((prev) => ({ ...prev, allNodeExpanded: !isExpended }));
              params.api.onGroupExpandedOrCollapsed();
            },
            tooltip: "Expand/Collapse all rows",
          });
        }
      }
      return result;
    } catch (error) {
      ErrorHandler("getContextMenuItems", error, params);
    }
  };

  onRowDataChanged = (params: any) => {
    try {
      if (this.props.onRowDataChanged !== undefined) this.props.onRowDataChanged(params);
    } catch (error) {
      ErrorHandler("onRowDataChanged", error, params);
    }
  };

  cellValueChanged = (key: string, params: any) => {
    try {
      if (this.props.onCellValueChanged !== undefined) this.props.onCellValueChanged(key, params);
    } catch (error) {
      ErrorHandler("cellValueChanged", error, [key, params]);
    }
  };

  //   getProperty<T, K extends keyof T>(obj: T, key: K) {
  //     return obj[key];
  //   }

  /** If we want to render button componenet in grid column */
  getBtnComponenet = (field: string, col: any, props: any) => {
    try {
      col["cellRenderer"] = "buttonComponent";
      const btn = props;
      col["cellRendererParams"] = {
        name: btn.name,
        enabled: btn.enabled,
        style: btn.style,
        className: btn.className,
        onClick:
          btn.onClick !== undefined
            ? (p: any) => {
              btn.onClick(p);
            }
            : undefined,
      };
      return col;
    } catch (error) {
      ErrorHandler("getBtnComponenet", error, [field, col, props]);
    }
  };

  /** If we want to render custom (JSX.Element) expected from parent form that will render as componenet in grid column */
  getCustomComponenet = (field: string, col: any, props: any) => {
    try {
      const cus = props;
      if (cus.compType !== "component") {
        col["cellRenderer"] = "customComponent";
      } else {
        col["cellRendererFramework"] = cus.comp;
      }
      col["cellRendererParams"] = {
        enabled: cus.enabled,
        style: cus.style,
        className: cus.className,
        comp: cus.comp,
        onClick:
          cus.onClick !== undefined
            ? (p: any) => {
              cus.onClick(p);
            }
            : undefined,
      };
      return col;
    } catch (error) {
      ErrorHandler("getCustomComponenet", error, [field, col, props]);
    }
  };

  /** If we want to render date componenet in grid column */
  getDateComponenet = (field: string, col: any, props: any) => {
    try {
      col["cellRenderer"] = "dateComponent";
      const dt = props;
      col["cellRendererParams"] = {
        format: dt.format,
        value: dt.value,
        readOnly: dt.readOnly === undefined ? true : dt.readOnly,
        style: dt.style,
        className: dt.className === undefined ? "date-component" : dt.className + " date-component",
        defaultDate: dt.defaultDate,
        onChange:
          dt.onChange !== undefined
            ? (p: any, d: any) => {
              dt.onChange(p, d);
            }
            : undefined,
      };
      return col;
    } catch (error) {
      ErrorHandler("getDateComponenet", error, [field, col, props]);
    }
  };

  /** If css class defined as function then compute the value and provide the applied classes */
  setCssClass = (col: any, cssClass: string | string[] | ((cellClassParams: any) => string | string[])) => {
    try {
      const colType = typeof cssClass;
      let cssClassValue = col["cellClass"];

      if (colType === "function") {
        col["cellClass"] = (params: any) => {
          let cValue = cssClassValue;
          const css = GetValue(cssClass, this.props.data, params);
          if (cValue !== undefined) {
            cValue.push(css);
          } else {
            cValue = [css];
          }
          return cValue;
        };
      } else if (col["cellClass"] !== undefined) {
        col["cellClass"].push(cssClass);
      } else {
        col["cellClass"] = colType === "object" ? cssClass : [cssClass];
      }
      return col;
    } catch (error) {
      ErrorHandler("setCssClass", error, [col, cssClass]);
    }
  };

  /** Add properies on to column as per the defination defined in props
   * Hide all the columns defined in hiddenColumnList
   * Group the data on all the columns defined in groupBy
   * Apply grouping through menu on all the columns defined in groupByMenuBar
   */
  applyPropsToColumns = (field: string, col: any) => {
    try {
      if (this.props.hiddenColumnList !== undefined && this.props.hiddenColumnList.length > 0) {
        const isAvailable = this.props.hiddenColumnList.find((f) => f === field);
        if (isAvailable) {
          col["hide"] = true;
        }
      }
      if (this.props.groupBy !== undefined && this.props.groupBy.length > 0) {
        const isAvailable = this.props.groupBy.find((f) => f === field);
        let groupedColumns = this.state.groupedColumns;
        if (isAvailable) {
          col["rowGroup"] = true;
          if (!groupedColumns.find((c) => c === field)) {
            groupedColumns.push(field);
          }
          this.setState((prev) => ({ ...prev, isGroupingDefined: true, groupedColumns: groupedColumns }));
        }
      }
      if (this.props.groupByMenuBar !== undefined && this.props.groupByMenuBar.length > 0) {
        const isAvailable = this.props.groupByMenuBar.find((f) => f === field);
        if (isAvailable) {
          col["enableRowGroup"] = true;
        }
      }
      return col;
    } catch (error) {
      ErrorHandler("applyPropsToColumns", error, [field, col]);
    }
  };

  /** If we want to render checkbox componenet in grid column */
  checkBoxRenderer = (params: any, isEditable: boolean | undefined | IsColumnFunc, editorProps: any) => {
    try {
      var div = document.createElement("div");
      div.style.height = "100%";
      div.style.width = "100%";
      div.style.textAlign = "left";
      div.style.paddingLeft = "30%";
      div.style.verticalAlign = "center";
      var span = document.createElement("span");
      var input = document.createElement("input");
      var label = document.createElement("label");
      span.appendChild(input);
      span.appendChild(label);
      input.type = "checkbox";

      input.setAttribute("id", `${params.column.colId}${params.rowIndex}`);
      label.setAttribute("for", `${params.column.colId}${params.rowIndex}`);

      if (editorProps.checkBoxValue === undefined && params.value === null) {
        span.classList.add("disabled-chkbox");
        input.disabled = true;
      } else {
        if (editorProps.checkBoxValue !== undefined) {
          const value = GetValue(editorProps.checkBoxValue, this.props.data, params);
          input.checked = value;
        } else if (params.value !== undefined) {
          input.checked = params.value;
        }
        input.addEventListener("click", (event) => {
          params.setValue(input.checked);
        });
        const editable = GetValue(isEditable, this.props.data, params);
        if (editable !== undefined && !editable) {
          span.classList.add("disabled-chkbox");
          input.disabled = true;
        }
      }
      let color: string = "blue";
      span.classList.add("chkbox");

      if (editorProps.enabled !== undefined) {
        const value = GetValue(editorProps.enabled, this.props.data, params);
        input.disabled = !value;
        if (!value) span.classList.add("gray-chkbox");
      }

      if (editorProps.checkBoxColor !== undefined) {
        color = GetValue(editorProps.checkBoxColor, this.props.data, params);
      }

      if (color !== undefined && color !== "") {
        span.classList.add(color + "-chkbox");
      }
      div.appendChild(span);
      return div;
    } catch (error) {
      ErrorHandler("checkBoxRenderer", error, [params, isEditable, editorProps]);
    }
  };

  /** Add different types of editors on the column as per the requiement */
  getSimpleEdititng = (field: string, col: any, props: any, isEditable: boolean | undefined | IsColumnFunc) => {
    try {
      if (isEditable) {
        col["onCellValueChanged"] = (params: any) => this.cellValueChanged(col.field, params);
      }
      if (this.props.highlightEditableColumn) {
        col["cellClass"] = (params: any) => {
          const editing = GetValue(isEditable, this.props.data, params);
          if (editing) {
            this.setCssClass(col, "editing");
          }
        };
      }
      if (props !== undefined) {
        const edit = props;
        switch (edit.editType) {
          case "Text":
          default:
            col["cellEditor"] = "agTextCellEditor";
            break;
          case "Number":
            col["cellEditor"] = "numericCellEditor";
            break;
          case "Combo":
            col["cellEditor"] = "agRichSelectCellEditor";
            col["cellEditorParams"] = (params: any) => {
              if (typeof edit.comboData === "function") return { values: edit.comboData(params) };
              else return { values: edit.comboData };
            };
            break;
          case "Multiline":
            col["cellEditor"] = "agLargeTextCellEditor";
            break;
          case "Checkbox":
            col["editable"] = false;
            col["cellEditor"] = "agSelectCellEditor";
            col["cellRenderer"] = (p: any) => this.checkBoxRenderer(p, isEditable, edit);
            col["edit"] = isEditable;
            break;
        }
      }
      return col;
    } catch (error) {
      ErrorHandler("getSimpleEdititng", error, [field, col, props, isEditable]);
    }
  };

  /** Add Custom header */
  setHeader = (field: string, col: any, props: any, isSuppressMenu: boolean | undefined) => {
    try {
      let value = false;
      if ( !RamdaExtensions.empty(this.state.data)) {
        value = this.state.data.every((item: any) => (item[field]));
      }
      col["headerComponentParams"] = {
        field: field,
        checkBox: props.checkBox,
        disableCheckBox: props.disableCheckBox,
        icon: props.icon,
        iconColor: props.iconColor,
        iconSize: props.iconSize,
        cssClass: props.cssClass,
        isSuppressMenu: isSuppressMenu === undefined ? false : isSuppressMenu,
        iconPosition: props.iconPosition,
        checkBoxValue: value,
        onClick:
          props.onClick !== undefined
            ? (params: any) => {
              props.onClick(params);
            }
            : undefined,
      };
      col["headerComponent"] = "customHeaderComponent";

      return col;
    } catch (error) {
      ErrorHandler("setHeader", error, [field, col, props, isSuppressMenu]);
    }
  };

  /** If detailedRowComponent is defined and our first available column is custom
   * component then we will add a dummy column in our grid to provide expand/collapse button */
  addCustomGroupColumnIfRequired = (columns: any) => {
    try {
      let col: any = {};
      let cols: any = [];
      let columnAdded: boolean = false;
      if (this.props.detailedRowComponent !== undefined) {
        for (const column of columns) {
          if ((column["hide"] === undefined || !column["hide"]) && !columnAdded) {
            if (column["cellRenderer"] === undefined) {
              column["cellRenderer"] = "agGroupCellRenderer";
              columnAdded = true;
            } else {
              col["cellRenderer"] = "agGroupCellRenderer";
              col["maxWidth"] = 30;
              col["minWidth"] = 30;
              col["field"] = "@grpCol";
              cols.push(col);
              this.setState((prev) => ({ ...prev, isCustomGroupColumnAdded: true }));
              columnAdded = true;
            }
          }
          cols.push(column);
        }
      } else {
        cols = columns;
      }
      return cols;
    } catch (error) {
      ErrorHandler("addCustomGroupColumnIfRequired", error, columns);
    }
  };

  /** Prepare the grid columns */
  initColumns = (props: any, isRepetative: boolean) => {
    try {
      let cols: any = [];
      if (props.columns && props.columns.length > 0) {
        cols = this.setColumnProperties(props.columns, cols, isRepetative);
      } else if (props.data && props.data.length > 0) {
        const dataColumns = Object.keys(props.data[0]);
        for (const dc of dataColumns) {
          let col: any = {};
          col["field"] = dc;
          col["headerName"] = dc;
          col = this.applyPropsToColumns(dc, col);
          cols.push(col);
        }
      }
      cols = this.addCustomGroupColumnIfRequired(cols);
      this.setState((prev) => ({ ...prev, columnDefs: cols }));
      return cols;
    } catch (error) {
      ErrorHandler("initColumns", error, props);
    }
  };

  /** Prepare the grid defualt properties applied on all columns */
  initDefColumns = (props: any) => {
    try {
      if (props.defColumns) {
        let defCols: any = {};
        for (const [key, value] of Object.entries(props.defColumns)) {
          defCols[key] = value;
        }
        return defCols;
      }
    } catch (error) {
      ErrorHandler("initDefColumns", error, props);
    }
  };

  /** As per the defined column defination on parent form prepare columns */
  setColumnProperties = (columns: any, cols: any, isRepetative: boolean) => {
    try {
      if (columns && columns.length > 0) {
        columns.forEach((column: IGridColumn) => {
          let col: any = {};
          col["cellStyle"] = (params: any) => this.setCellStyle(column.field!, params);
          col = this.applyPropsToColumns(column.field!, col);
          for (const [key, value] of Object.entries(column)) {
            const val: any = value;
            if (key === "editable") {
              col[key] = value;
              col = this.getSimpleEdititng(column.field!, col, column.editor, val);
            } else if (key === "customHeader") {
              col = this.setHeader(column.field!, col, val, column.suppressMenu);
            } else if (key === "rowGroup" && value) {
              let groupedColumns = this.state.groupedColumns;
              if (!groupedColumns.find((c) => c === column.field)) {
                groupedColumns.push(column.field!);
              }
              col[key] = value;
              this.setState((prev) => ({ ...prev, isGroupingDefined: true, groupedColumns: groupedColumns }));
            } else if (key === "cellClass") {
              col = this.setCssClass(col, val);
            } else if (column.cType === "Button" && key === "component") {
              col = this.getBtnComponenet(column.field!, col, value);
            } else if (column.cType === "Date" && key === "component") {
              col = this.getDateComponenet(column.field!, col, value);
            } else if (column.cType === "Custom" && key === "component") {
              col = this.getCustomComponenet(column.field!, col, value);
            } else if (key === "cellStyle") {
              col["cellStyle"] = (params: any) => this.setCellStyle(column.field!, params);
            } else if (key === "valueFormatter") {
              col[key] = (params: any) => this.setValueFormatter(value, params);
            } else if (key !== "cType" && key !== "editor" && typeof val === "object") {
              //if its another array
              let childCols: any = [];
              col[key] = this.setColumnProperties(val, childCols, isRepetative);
            } else if (key !== "cType" && key !== "editor") {
              col[key] = value;
            }
          }
          cols.push(col);
        });
      }
      return cols;
    } catch (error) {
      ErrorHandler("setColumnProperties", error, [columns, cols]);
    }
  };

  /** Apply the custom styling on cell */
  setCellStyle = (key: string, params: any) => {
    try {
      let style: any = {};
      if (this.props.setCellStyle !== undefined) {
        style = this.props.setCellStyle(key, params);
      }
      return style;
    } catch (error) {
      ErrorHandler("setCellStyle", error, [key, params]);
    }
  };

  /** Apply the custom styling on cell */
  setValueFormatter = (formatterType: any, params: any) => {
    try {
      if (formatterType === ValueFormatter.Amount) return params && params.value ? this.amountFormat(params.value) : params.value;
      else if (formatterType === ValueFormatter.Date) return DateHelpers.formatDate(new Date(params.value), 4);
      else if (typeof formatterType === "function") {
        return formatterType(params);
      }
    } catch (error) {
      ErrorHandler("setValueFormatter", error, [formatterType, params]);
    }
  };

  amountFormat = (value: any) => {
    let floatVal = parseFloat(value),
      number,
      integer,
      decimal,
      rgx;
    let decimalSym = ".";
    let thousandSym = ",";
    let precision = 2;

    if (isNaN(floatVal)) {
      return "";
    }

    number = floatVal.toFixed(precision);
    number = String(number).split(".");
    integer = number[0];
    decimal = number.length > 1 ? decimalSym + number[1] : "";
    rgx = /(\d+)(\d{3})/;

    while (rgx.test(integer)) {
      integer = integer.replace(rgx, "$1" + thousandSym + "$2");
    }
    return floatVal < 0 ? `(${integer.replace("-", "")}${decimal})` : `${integer}${decimal}`;
  };

  /** Apply the custom styling on row */
  getRowStyle = (params: any) => {
    try {
      let style: any = {};
      if (this.props.getRowStyle !== undefined) {
        style = this.props.getRowStyle(params);
      }
      return style;
    } catch (error) {
      ErrorHandler("getRowStyle", error, params);
    }
  };

  /** As soon as the first data rendered below event get triggered */
  // onFirstDataRendered = (params: any) => {
  //   if (this.props.detailedRowComponent !== undefined) {
  //     params.api.forEachNode(function (node: any) {
  //       node.setExpanded(node.id === "1");
  //     });
  //   }
  // };

  //#endregion

  render() {
    if (this.columnsDef === null) {
      return null;
    }
    return (
      <div className="grid-container">
        <div className="loadingx" hidden={!this.props.showLoading && !this.state.showLoading}>
          <div className="loader">
            <span className="message"> Loading Data ...</span>
            <div className="spinner"></div>
          </div>
        </div>
        <AgGridReact
          columnDefs={this.columnsDef}
          onGridReady={this.onGridReady}
          gridOptions={this.gridOptions}
          rowData={this.state.data}
          rowSelection={this.props.rowSelection}
          isRowSelectable={this.props.isRowSelectable}
          onRowSelected={this.props.onRowSelected}
          onRowDataChanged={this.onRowDataChanged}
          frameworkComponents={this.frameworkComponent}
          //getRowStyle={this.props.getRowStyle}
          stopEditingWhenGridLosesFocus={this.props.stopEditingWhenGridLosesFocus}
          enableBrowserTooltips={this.props.enableBrowserTooltips}
          disableStaticMarkup={true}
          suppressClipboardPaste={false}
          suppressCopyRowsToClipboard={true}
          suppressRowClickSelection={this.props.suppressRowClickSelection}
          enableRangeSelection={this.props.enableRangeSelection}
          onRangeSelectionChanged={this.props.onRangeSelectionChanged}
          suppressMultiRangeSelection={this.props.suppressMultiRangeSelection}
          pinnedTopRowData={this.props.pinnedData}
          onRowClicked={this.props.onRowClicked}
        ></AgGridReact>
      </div>
    );
  }
}

export default WebGrid;
