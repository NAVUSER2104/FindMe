export interface IOptions {
    label: string,
    value: string;
}

export interface IRadioGroupProps {
    data: Array<IOptions>;
    optionType?: 'default' | 'button';
    handler: (event: any, data: Array<IOptions>) => void;
    buttonStyle?: 'outline' | 'solid';
    size?: 'large' | 'small' | 'middle';
    defaultValue: string;

}