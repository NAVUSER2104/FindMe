// absolute imports
import { FC } from 'react';
import { Radio, Layout } from 'antd';

// relative imports
import { IRadioGroupProps } from 'components/radioGroup/type';
import useRadioGroupHook from 'components/radioGroup/hooks/useRadioGroupHook';

const { Content } = Layout;
const CustomRadioGroup: FC<IRadioGroupProps> = (props: IRadioGroupProps) => {
    const { onClick, state } = useRadioGroupHook(props);

    return (
        <Content>
            <Radio.Group
                options={props.data}
                onChange={onClick}
                value={state.defaultValue}
                optionType={props.optionType}
                size={props.size}
                buttonStyle={props.buttonStyle}
            />
        </Content>
    );
}

export default CustomRadioGroup