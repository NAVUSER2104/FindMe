// absolute imports
import { useState } from 'react';
import * as R from 'ramda';

// relative imports
import { IRadioGroupProps } from "components/radioGroup/type";

const useRadioGrpupHook = (props: IRadioGroupProps) => {
    const [state, setState] = useState({
        defaultValue: props.defaultValue as any,
    });

    const onClick = (e: any) => {
        const value = R.path(['target', 'value'], e);
        setState((prev) => ({ ...prev, defaultValue: value }));
        if (typeof (props.handler) === "function") {
            props.handler(value, props.data);
        }
    };

    return {
        state,
        onClick,
    }
}

export default useRadioGrpupHook;