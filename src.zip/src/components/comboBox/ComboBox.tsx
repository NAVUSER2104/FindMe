import { FC } from 'react';
import * as R from 'ramda';
import { Select } from 'antd';

import { IComboBoxProps } from './type';
import 'assets/styles/components/comboBox.less';
import RamdaExtensions from 'helpers/ramda';

const { Option } = Select;

const ComboBox: FC<IComboBoxProps> = (props: IComboBoxProps) => {
    return (
        <Select
            showSearch
            showArrow
            allowClear={RamdaExtensions.empty(props.allowClear) ? true : props.allowClear}
            mode={props.mode}
            autoFocus={true}
            optionFilterProp="children"
            size={RamdaExtensions.empty(props.size) ? "middle" : props.size}
            placeholder={props.placeHolder}
            onChange={(value, data) => (props.handler(value, data))}
            filterOption={(input, option: any) =>
                R.indexOf(R.toLower(input), R.toLower(option.children)) >= 0
            }
            className="w-100 remove-overflow"
            defaultValue={props.defaultValues}
            key={props.defaultValues?.toString()}
            value={props.groupId}
            onSelect={props.handleSelect}
            onDeselect={props.handleDeselect}
            disabled={props.disabled}
            loading={props.loading}
        >
            {R.map((i) => (<Option value={i.groupId}>{i.groupName}</Option>), props.data)}
        </Select>
    );
}

export default ComboBox

//key={i.key}