import { SizeType } from "antd/lib/config-provider/SizeContext";

export interface IOptions {
    //key: number | string;
    groupId: number | string;
    groupName: number | string;
}

export interface IComboBoxProps {
    placeHolder: string;
    data: IOptions[];
    handler: Function;
    mode?: "multiple" | "tags"
    defaultValues?: any
    groupId?: any;
    handleSelect?: (value: any, options: any) => void;
    handleDeselect?: (value: any, options: any) => void;
    /** if not passed defaults to true */
    allowClear?: boolean;
    loading?: boolean;
    disabled?: boolean;
    size?: SizeType;
}