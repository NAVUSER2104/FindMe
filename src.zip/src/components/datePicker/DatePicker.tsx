// absolute imports
import React, { FC, useEffect, useRef } from 'react';
import { DatePicker } from 'antd';
import * as ReactDOM from 'react-dom';

// relative imports
import { IDatePickerProps } from 'components/datePicker/type';

const CustomDatePicker: FC<IDatePickerProps> = (props: IDatePickerProps) => {

  const addHyphen = (x: any, y: any) => {
    // const indexes = props.format?.
    // const newDate = 
    console.log(x.key)
    // props.onChange(x, y)
  }
  const datePickerRef = useRef(null)

  const reformatDate = (event: any) => {
    const strippedInput = event.target.value.replaceAll("/", "")
    let newInput = "";
    for (let i = 0; i < strippedInput.length; i += 1) {
      if (i === 2 || i === 4)
        newInput += "/"
      newInput += strippedInput.charAt(i)
    }
    event.target.value = newInput
  }

  useEffect(() => {
    const input = ReactDOM.findDOMNode(datePickerRef.current)?.firstChild?.firstChild as HTMLInputElement
    input.maxLength = 10
    input?.addEventListener("keyup", reformatDate)

    return () => {
      input?.removeEventListener("keyup", reformatDate)
    }
  }, [])

  return (
    <DatePicker
      picker={props.picker}
      placeholder={props.placeholder}
      value={props.defaultValue}
      onChange={props.onChange}
      onKeyDown={addHyphen}
      format={props.format}
      allowClear={false}
      ref={datePickerRef}
    />
  );
}

export default CustomDatePicker;