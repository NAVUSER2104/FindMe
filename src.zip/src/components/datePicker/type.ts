export interface IOptions {
    key: number;
    value: number | string;
    text: number | string;
}

export interface IDatePickerProps {
    picker?: "week" | "month" | "year";
    placeholder?: string;
    onChange: (date: moment.Moment | null, dateString: string) => void;
    defaultValue?: moment.Moment;
    format?: string;
    label?: string;
}