//absoluet imports
import { notification } from 'antd';
import * as R from 'ramda';

//relative imports
import { INotificationProps, IArgsProps } from 'components/notification/type';

const notifications = {
    Error: (args: IArgsProps) => notification.error({ ...args, placement: 'topRight' }),
    Info: (args: IArgsProps) => notification.info({ ...args, placement: 'topRight' }),
    Warning: (args: IArgsProps) => notification.warning({ ...args, placement: 'topRight' }),
    Success: (args: IArgsProps) => notification.success({ ...args, placement: 'topRight' }),
}

const openNotification = (props: INotificationProps) => {

    const args: IArgsProps = {
        message: props.notificationType,
        description: props.message,
        duration: (props.duration) ? props.duration : 10,
    };

    R.prop(props.notificationType, notifications)(args);
}

export default openNotification;