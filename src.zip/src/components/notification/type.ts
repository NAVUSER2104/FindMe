import { ReactNode } from 'react'

export interface INotificationProps {
    notificationType: "Error" | "Success" | "Info" | "Warning",
    message: string | ReactNode,
    duration?: number
}

export interface IArgsProps {
    message: ReactNode,
    description: ReactNode,
    duration: number
}
