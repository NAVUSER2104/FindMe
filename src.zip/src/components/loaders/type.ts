export interface AjaxType {
    isLoading: boolean
}