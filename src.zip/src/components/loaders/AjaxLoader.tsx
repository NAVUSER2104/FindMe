import { FC } from 'react';
import { Spin } from 'antd';

// relative imports
import { AjaxType} from 'components/loaders/type';

export const AjaxLoader: FC<AjaxType> = (props) => {
    return (
        <div className={`loader-mask ${props.isLoading ? '' : 'd-none'}`}>
            <div className="loader-area align-self-center">
                <Spin />
            </div>
        </div>
    );
};
