import { createSlice } from "@reduxjs/toolkit";

// relative imports
import { RootState } from 'redux/rootReducer';

export interface SidebarState {
    openKeys: Array<any>,
    currentMenuItem: string,
    collapsed: boolean
}

const initialState: SidebarState = {
    currentMenuItem: 'ProcessFunds',
    openKeys: ['ProcessFunds'],
    collapsed: false
}

export const sidebarReducer = createSlice({
    name: 'sidebar',
    initialState,
    reducers: {
        setOpenMenuKeys: (state, { payload }: any) => {
            state.openKeys = [payload.openKeys]
        },
        setCurrentMenuItem: (state, { payload }: any) => {
            state.currentMenuItem = payload.currentMenuItem
        },
        setCollapsed: (state, { payload }: any) => {
            state.collapsed = payload;
        },
    }
});

export const { setOpenMenuKeys, setCurrentMenuItem, setCollapsed} = sidebarReducer.actions;
export const sidebarSelector = (state: RootState) => state.sidebarReducer;