//absolute imports
import * as R from 'ramda';
import React, { FC } from "react";
import { withRouter } from 'react-router-dom';
import { Scrollbars } from 'react-custom-scrollbars';
import { Layout, Menu, Dropdown, Button, Row, Col } from 'antd';
import { useSelector, useDispatch } from 'react-redux';
import {
    ContainerOutlined,
    LogoutOutlined,
    DownOutlined,
    UserOutlined,
    MenuUnfoldOutlined,
    MenuFoldOutlined,
    ContactsOutlined,
    SettingOutlined,
    DollarOutlined,
    BarChartOutlined,
    BarsOutlined,
    DashboardOutlined,
    EyeOutlined,
} from '@ant-design/icons';

// relative imports
//import SecurityHandlers from 'components/hoc/auth/hooks/useSecurityHandlers';
import { setCurrentMenuItem, setOpenMenuKeys, sidebarSelector } from "components/navigations/reducerSidebar";
import { IPropsSidebar, MenuItems } from "components/navigations/type";
import DateHelpers from 'helpers/dateHelpers';
import DataHelpers from 'helpers/dataHelpers';
import RamdaExtensions from "helpers/ramda";

// logo and less
import navLogo from "assets/images/nav-logo-desktop.png";
//import SetDefaultReducer from 'screens/setDefaults/reducerSetDefault';
//import UserDetailsReducer from 'screens/login/reducerUserDetails';
import { Application } from 'helpers/enum';
//import LoginReducer from 'screens/login/reducerLogin';
import { persistSelector } from 'redux/reducerPersist';
import LoginReducer from 'screens/login/reducerLogin';
import SecurityHandlers from 'components/hoc/auth/hooks/useSecurityHandlers';

// constant or global variables
const SubMenu = Menu.SubMenu;
const { Sider } = Layout;
const routes = {
    admin: 'Admin',
    dashboard: 'Dashboard',
    apistatus:'ApiStatus'
    
};
export const menus: MenuItems[] = [    
    { icon: <BarChartOutlined />, key: routes.dashboard, name: routes.dashboard, application: Application.NAVMain2, subMenus: [] },
    { icon: <DashboardOutlined />, key: routes.apistatus, name: routes.apistatus, application: Application.NAVMain2, subMenus: [] }    
];

const SidebarNav: FC<IPropsSidebar> = (props: IPropsSidebar): JSX.Element => {
    const dispatch = useDispatch(); // action to be invoked using dispatch
    const { openKeys: openMenuKeys, currentMenuItem } = useSelector(sidebarSelector);  // get the redux value using the reducer
    const { application } = useSelector(persistSelector); 
    const { userData } = useSelector(LoginReducer.loginSelector);
    const userName = R.pathOr(openMenuKeys, ['userName'], userData);
    const onOpenChange = (openKeys: Array<any>) => {
        const [latestOpenKey] = R.filter(key => R.indexOf(key, RamdaExtensions.compact(openMenuKeys)) === -1, RamdaExtensions.compact(openKeys));
        dispatch(setOpenMenuKeys({ openKeys: latestOpenKey }));
    };

    const linkTo: any = (item: any) => {
        console.log(item ,"++++++++++")
        const subMenu = R.path(['item', 'props', 'subMenuKey'], item);
        const menu = R.prop('key', item);
        console.log(menu ,"++++++++++, menu")
        dispatch(setCurrentMenuItem({ currentMenuItem: menu })); //Set Current Menu Item

        // set menu without submenu
        const routeToBeUsed = R.prop(R.toLower(menu), routes);
        console.log(routeToBeUsed, "=======================")
        if (!RamdaExtensions.empty(routeToBeUsed))
            props.history.push(`/${routeToBeUsed}`);

        // set submenu routes
        switch (subMenu) {
            case 'FundAccounting-menu-':
                return props.history.push(`/FundAccounting/${menu}`);
            case 'PostApproval-menu-':
                return props.history.push(`/PostApproval/${menu}`);
            case 'Utilities-menu-':
                return props.history.push(`/Utilities/${menu}`);
            case 'Preferences-menu-':
                return props.history.push(`/Preferences/${menu}`);
            case 'OpexCategoryMappings-menu-':
                return props.history.push(`/OpexCategoryMappings/${menu}`);
            case 'ReportMappings-menu-':
                return props.history.push(`/ReportMappings/${menu}`);
        }
    };

    const getMenu = (item: MenuItems) => (
       // item.application === application || RamdaExtensions.empty(item.application) ?
            <Menu.Item key={R.prop('key', item)} icon={R.prop('icon', item)}>
                <span className="nav-text">{R.prop('name', item)}</span>
            </Menu.Item>
         //   : null
    );

    const getSubMenu = (item: MenuItems) => (
        // item.application === application || RamdaExtensions.empty(item.application) ?
            <SubMenu key={R.prop('key', item)} icon={R.prop('icon', item)} title={<span>{R.prop('name', item)}</span>}>
                {R.map(getMenu, R.prop('subMenus', item))}
            </SubMenu>
            //: null

    );

    const renderMenuItems = () => R.map((item: MenuItems) => {
        if (!RamdaExtensions.empty(R.prop('subMenus', item))) return getSubMenu(item);
        else return getMenu(item);
    }, menus);

    const handleLogout = () => {
        (async () => { await SecurityHandlers.handleLogout() })()
    }

    const handleUserSettings = () => {
        props.history.push(`/UserSettings`);
    }

    const userMenu = (
        <Menu>
            <Menu.Item>
                <div><b>User: </b> {userName}</div>
            </Menu.Item>
            <Menu.Item>
                <Button type="link" onClick={handleUserSettings} icon={<SettingOutlined />}>User Settings</Button>
            </Menu.Item>
            <Menu.Item>
                <Button type="link" onClick={handleLogout} icon={<LogoutOutlined />}>Logout</Button>
            </Menu.Item>
        </Menu>);

    return (
        <React.Fragment>
            <Sider
                className='bg-sidenav'
                width={300}
                breakpoint="sm"
                collapsedWidth={"80"}
                trigger={null}
                collapsible
                collapsed={props.collapsed}
                style={{
                    display: "flex", flexDirection: "column", justifyContent: 'space-between', maxHeight: '100vh',
                    position: 'fixed', minHeight: '100vh', zIndex: 1
                }}
            >
                <div className="sidenav-upperview">
                    <div className="logo-wrapper">
                        {props.collapsed ?
                            <Button type="primary" onClick={props.handleToggle} style={{ margin: 16 }}>
                                {React.createElement(MenuUnfoldOutlined)}
                            </Button> :
                            <div className={props.collapsed ? "logo-after-collapsed" : "logo-before-collapsed"}>
                                <img alt={navLogo} src={navLogo} />
                                <Button type="primary" onClick={props.handleToggle} className="hamburger-icon">
                                    {React.createElement(MenuFoldOutlined)}
                                </Button>
                            </div>
                        }
                        <div className="user-profile-menu">
                            <Dropdown overlay={userMenu} className="text-white">
                                <a className="ant-dropdown-link" onClick={e => e.preventDefault()}>
                                    <UserOutlined />
                                    <b className={props.collapsed ? "d-none" : "mx-1"}>{userName}</b>
                                    <DownOutlined className={props.collapsed ? "d-none" : ""} />
                                </a>
                            </Dropdown>
                        </div>
                    </div>
                    <div className="d-flex flex-grow-1 side-navbar">
                        <Scrollbars
                            autoHide={true}
                            universal
                            renderTrackVertical={props => <div {...props} className="track-vertical" />}
                            renderThumbVertical={props => <div {...props} className="thumb-vertical scrollbar-thumb" />}
                            renderTrackHorizontal={props => <div {...props} className="track-horizontal" />}
                            renderThumbHorizontal={props => <div {...props} className="thumb-horizontal" />}
                            hideTracksWhenNotNeeded={true}
                            style={{ height: 'auto' }}
                            className='dark-theme-sidebar'
                        >
                            <Menu defaultSelectedKeys={[routes.dashboard]}
                                theme='dark'
                                mode="inline"
                                onClick={linkTo}
                                openKeys={openMenuKeys}
                                onOpenChange={onOpenChange}
                                className="sidebar-navigation"
                                selectedKeys={[!DataHelpers.isNullOrEmptyString(currentMenuItem) ? currentMenuItem : routes.dashboard]}
                            >
                                {renderMenuItems()}
                            </Menu>
                        </Scrollbars>
                    </div>
                </div>
                {!props.collapsed &&
                    <div className="px-4 pb-2 pt-3">
                        <Row justify="center">
                            <Col sm={24} md={24} className="text-white text-center">
                                <small><span>© {DateHelpers.getCopyrightYear()} NAV Consulting, Inc.<br /> All Rights Reserved.</span></small>
                            </Col>
                        </Row>
                    </div>
                }
            </Sider>
        </React.Fragment>
    )
}
export default withRouter(SidebarNav);