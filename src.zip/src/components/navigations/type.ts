import React, { MouseEventHandler } from 'react';
import { RouteComponentProps } from 'react-router-dom';

export interface MenuItems {
    key: string,
    subMenus: Array<any> | [],
    icon?: React.ReactNode,
    name: string,
    application?: string
}
export interface IPropsSidebar extends RouteComponentProps<any> {
    collapsed: boolean,
    handleToggle: MouseEventHandler<HTMLElement>,
}
