import HighchartsReact from 'highcharts-react-official';
import React from 'react';

const HighchartWrapper = (props: any) => {
    return (
        // <HighchartsReact
        //     options = {props.options}
        // />
        test
    );

}

export default HighchartWrapper;