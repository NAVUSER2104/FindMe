import { Popconfirm } from 'antd';
import { FC } from 'react';

// relative imports
import { IPropsConfirmDialog } from 'components/confirmDialog/type';
import RamdaExtensions from 'helpers/ramda';

export const ConfirmDialog: FC<IPropsConfirmDialog> = (props: IPropsConfirmDialog): JSX.Element => {

    return (
        <Popconfirm
            title={(RamdaExtensions.empty(props.title) ? "Are you sure to delete this?" : props.title)}
            onConfirm={props.confirm}
            onCancel={props.cancel}
            okText="Yes"
            cancelText="No"
            placement={props.placement}
            disabled={props.disabled}
        >
            {props.component}
        </Popconfirm>
    )

}