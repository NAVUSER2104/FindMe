export interface IPropsConfirmDialog {
    confirm?: (e?: React.MouseEvent<HTMLElement>) => void;
    cancel?: (e?: React.MouseEvent<HTMLElement>) => void;
    component: JSX.Element;
    placement: "topLeft" | "top" | "topRight" | "leftTop" | "left" | "leftBottom" | "rightTop" | "right" | "rightBottom" | "bottomLeft" | "bottom" | "bottomRight";
    title?: string;
    disabled?: boolean;
}
