// absolute imports
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

// relative imports
import { RootState } from 'redux/rootReducer';

export interface AlertState {
    message: string,
    type: string
}

const initialState: AlertState = {
    message: '',
    type: ''
}

export const alertReducer = createSlice({
    name: 'alert',
    initialState,
    reducers: {
        setMessage: (state, { payload }: PayloadAction<AlertState>) => {
            state.message = payload.message
            state.type = payload.type
        }
    }
});

export const { setMessage } = alertReducer.actions;
export const alertSelector = (state: RootState) => state.alertReducer;