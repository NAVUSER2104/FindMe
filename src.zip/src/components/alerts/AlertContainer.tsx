import { FC } from 'react';
import { Alert } from 'antd';

interface AlertContainerType {
    message: any,
    type: any,
    onClose?: React.MouseEventHandler<HTMLButtonElement>
}


const AlertContainer: FC<AlertContainerType> = (props) => {
    return (
        <Alert message={props.message}
            key={new Date().toString()}
            className={`mb-md-1 my-2`}
            type={props.type}
            onClose={props.onClose}
            closable
            showIcon
        />
    );
}

export default AlertContainer;