import { MenuTheme } from "antd";
import { ChangeEvent } from "react";

export interface ITitleBar {
    searchDisabled? : boolean;
    onSearchChange?: (event: ChangeEvent<HTMLInputElement>) => void;
    onRefresh?: Function;
    showSearch?: boolean;
    showRefresh?: boolean;
    title?: string;
}

export const Themes = {
    DARK: 'dark',
    LIGHT: 'light'
} as { DARK: MenuTheme, LIGHT: MenuTheme}