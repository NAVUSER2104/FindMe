import React, { ChangeEvent, FC, useEffect } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAdjust } from '@fortawesome/free-solid-svg-icons';
import { Tooltip, Row, Col, Input, Button, Divider } from "antd";
import { ReloadOutlined } from "@ant-design/icons";
import * as R from 'ramda';
//redux
import { useDispatch, useSelector } from "react-redux";
import { setTheme, themeSelector } from "redux/reducerTheme";
//type
import { ITitleBar, Themes } from "./type";
//import useHttpHook from "screens/preferences/groupSettings/commonHooks/useHttpHook";
import RamdaExtensions from "helpers/ramda";
//import GroupReducer from "screens/preferences/groupSettings/reducerGroup";
//import LoginReducer from "screens/login/reducerLogin";

const TitleBar: FC<ITitleBar> = (props: ITitleBar): JSX.Element => {

    const { theme } = useSelector(themeSelector);
    //const { defaultSetting } = useSelector(GroupReducer.groupSelector);
    //const { updateDefaultSetting, createDefaultSetting, getDefaultSettings } = useHttpHook();
    //const userReduxState = useSelector(LoginReducer.loginSelector)

    const dispatch = useDispatch()
    const updateTheme = () => {
        let themeName = theme;
        if (themeName) {
            // remove current theme 
            document.documentElement.classList.remove('light');
            document.documentElement.classList.remove('dark');
            // apply new theme
            document.documentElement.classList.add(themeName);
        }
    }

    useEffect(() => {
        updateTheme()
    }, [theme])

    const toggleTheme = async () => {
        const finalTheme = theme === Themes.DARK ? Themes.LIGHT : Themes.DARK;
        dispatch(setTheme(finalTheme));
        // if (!RamdaExtensions.empty(defaultSetting)) {
        //     const reqBody = {
        //         ...defaultSetting,
        //         theme: finalTheme,
        //         userID: R.pathOr('', ['userData', 'userID'], userReduxState),
        //     };
        //     try {
        //         (RamdaExtensions.empty(reqBody.id)) ? (await createDefaultSetting(reqBody)) : (await updateDefaultSetting(reqBody));
        //         await getDefaultSettings()
        //     } catch (err) {
        //         console.log('== error in toggleTheme ==', err);
        //     }
        // }
    }

    const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
        if (typeof props.onSearchChange == 'function') {
            props.onSearchChange(e)
        }
    }

    const handleRefresh = (e: any) => {
        if (typeof props.onRefresh == 'function') {
            props.onRefresh(e)
        }
    }
    return (
        <React.Fragment>
            <Row gutter={[24, 0]} justify="space-between" align="middle">
                <Col className='screen-header'>{props.title}</Col>
                <Col>
                    <Row className='mb-1' gutter={[6, 6]} align="middle" justify="end">
                        {
                            props.showSearch ?
                                <Col>
                                    <Input.Search disabled={props.searchDisabled} placeholder="Filter Text" allowClear onChange={handleSearchChange} />
                                </Col>
                                : null
                        }
                        {
                            props.showRefresh ?
                                <Col>
                                    <Button
                                        type="primary"
                                        icon={<ReloadOutlined />}
                                        loading={false}
                                        onClick={handleRefresh}
                                    />
                                </Col>
                                : null
                        }
                        <Tooltip title="Toogle dark/light theme">
                            <Col>
                                <Button
                                    type="primary"
                                    icon={<FontAwesomeIcon icon={faAdjust} />}
                                    loading={false}
                                    onClick={toggleTheme}
                                />
                            </Col>
                        </Tooltip>
                    </Row>
                </Col>
            </Row>
            <Divider className=' mt-2 mb-3'/>
        </React.Fragment>
    )
}

export default TitleBar;