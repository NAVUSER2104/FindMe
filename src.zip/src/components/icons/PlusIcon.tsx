// absolute imports
import { FC } from 'react';
import { PlusOutlined, MinusOutlined, EditOutlined, CopyOutlined, MailFilled } from '@ant-design/icons';

// relative imports
import { IIconProps } from 'components/icons/type';

const GridIcons: FC<IIconProps> = (props: IIconProps) => { 

    return (
        
        <div>   
                     
            {props.type === "plus" ? 
            (
            <PlusOutlined style={{ color: "green", ...props.style }}>
                </PlusOutlined>) : props.type === "minus" ? (
                    < MinusOutlined style={{ color: "red", ...props.style }}>
                    </MinusOutlined >) : props.type === "copy" ? (
                        <CopyOutlined style={{ color: "black", ...props.style }}></CopyOutlined>
                    ) : props.type === "MailFilled" ? (
                        <MailFilled style={{ color: "black", ...props.style }}></MailFilled>
                    ) : (
                < EditOutlined style={{ color: "black", ...props.style }}>
                </EditOutlined >)        
        }
        </div>
    );
}
export default GridIcons;