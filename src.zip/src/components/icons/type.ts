export interface IIconProps {
    style?: object;
    type: "plus" | "minus" | "edit" | "copy" | "MailFilled"
}
