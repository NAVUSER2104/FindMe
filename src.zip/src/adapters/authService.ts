// absolute imports
import config from "react-global-configuration";

// relative imports
import getAxiosInstance from "adapters/axiosWrapper";

const authServiceInstance = (initializers: object = {}) => getAxiosInstance(config.get("authServiceUri"), initializers);
export default authServiceInstance;
