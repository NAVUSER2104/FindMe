// absolute imports
import config from "react-global-configuration";

// relative imports
import getAxiosInstance from "adapters/axiosWrapper";

export const adServiceINDInstance = (initializers: object = {}) => getAxiosInstance(config.get("adServiceUri"), initializers);

export const adServiceUSInstance = (initializers: object = {}) => getAxiosInstance(config.get("adServiceUSUri"), initializers);
