// absolute imports
import config from "react-global-configuration";

// relative imports
import getAxiosInstance from "adapters/axiosWrapper";

const dashboardServiceInstance = (initializers: object = {}) => getAxiosInstance(config.get("main2DashboardServiceUri"), initializers, true);
export default dashboardServiceInstance;
