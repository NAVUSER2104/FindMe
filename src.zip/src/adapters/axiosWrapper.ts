import axios from 'axios';
import * as R from 'ramda';
import settingConfig from 'react-global-configuration';

// relative imports
import { FlagType } from 'components/hoc/auth/type';
import securityHandlers from 'components/hoc/auth/hooks/useSecurityHandlers';

const getAxiosInstance = (baseURL: string, initializers: object = {}, enableAuth: boolean = false) => {  //enableAuth - true if token authentication is needed for the request
    const isProductionEnv = settingConfig.get('productionEnv') === "true";

    const axiosInstance = axios.create({ baseURL, ...initializers });
    // for multiple requests
    let failedQueue: Array<any> = [];
    let flagObj: FlagType = { isRefreshing: false, isLoggingOut: false }

    axiosInstance.interceptors.request.use((config) => {
         if (enableAuth) {
             securityHandlers.addAuthorizationHeaders(config)
         }
        console.log('%c Request URL ', 'background: yellow', config.url, config)
        return config;
    }, (error) => {
        console.log(error);
        return Promise.reject(error);
    });

    axiosInstance.interceptors.response.use((response) => {
        console.log('%c Response URL ', 'background: lightgreen', response.config.url, isProductionEnv ? response.status : response)
        return response;
    }, async(error) => {
        console.log('%c API Reject', 'background: pink');
        if (R.prop('response', error)) {
            //The request was made and the server responded with a status code that fails out of range of 2xx
            console.log('ErrorResponse: ', error.response);

             if (enableAuth){
                 return await securityHandlers.reprocessFailedRequests(error, flagObj, failedQueue)
             }
                
        }
        else if (error.request) {
            // The request was made but no response was received
            // 'error.request' is an instance of XMLHttpRequest in the browser and an instance of http.ClientRequest
            console.log('ErrorRequest: ', error.message, error.request);

        }
        else {
            // something happened in setting up the request that triggered an error
            console.log('ErrorMessage: ', error.message ? error.message : error);
        }
        throw error;
    });
    return axiosInstance;
}
export default getAxiosInstance;