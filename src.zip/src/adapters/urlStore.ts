
export const Main2ApiUrl = {
    GetProcessWisePortfolioStatus: "/PortfolioLog/GetProcessWisePortfolioStatus",
    GetClientPortfolioStatus:'/ClientwiseDeliveryLog/GetClientPortfolioStatus',
    GetApiStatus:'/ApiStatus/GetApiStatus',
    SendApiNotification:'/ApiStatus/SendApiNotification',
    GetFundPortfolioSummary: '/PortfolioLog/GetFundPortfolioSummary',
    GetGroupData: '/PortfolioLog/GetGroupData'
};
const AdServiceUrl = {
    GetUserName: "/ADDetail/GetUserName",
    GetADUserByUserName: "/ADDetail/GetADUserByUserName",
    GetUserAdDetails: "/ADDetail/GetUserAdDetails",
};

export const AuthUrl = {
    RegisterUser: '/register',
    LoginUser: '/Authentication/Login',
    RefreshToken: '/oauth/refresh',
    Logout: '/logout'
}
const LoginUrl = {
    GetUsers: "/login/GetUsers",
    UpdateUserRole: "/login/UpdateUserRole",
    UpdateUserPassword: "/login/UpdateUserPassword",
    UpdateUserProfile: "/login/UpdateUserProfile",
    SendOTP: "/login/SendOTP",
    ResetPassword: "/login/ResetPassword",
    GetLoginServiceID: "/login/GetLoginServiceID",
    UpdateLoginServiceID: "/login/UpdateLoginServiceID"
};

export const UrlStore = { 
    Main2ApiUrl,
    AuthUrl,
    LoginUrl,
    AdServiceUrl
};

export default UrlStore;