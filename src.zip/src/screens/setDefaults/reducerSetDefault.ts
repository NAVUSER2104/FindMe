// absolute imports
import { createSlice } from "@reduxjs/toolkit";

// relative imports
import { RootState } from 'redux/rootReducer';


export interface SetDefaultState {
    open: boolean
}

const initialState: SetDefaultState = {
    open: false
}

export const setDefaultReducer = createSlice({
    name: 'setDefault',
    initialState,
    reducers: {
        setDefaultSettingOpen: (state, { payload }) => {
            state.open = payload
        },
    }
})

const setDefaultSelector = (state: RootState) => state.setDefaultReducer

export const SetDefaultReducer = {
    setDefaultSelector,
    ...setDefaultReducer.actions
};
export default SetDefaultReducer;