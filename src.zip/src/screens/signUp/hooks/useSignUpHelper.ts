// absolute imports
import * as R from 'ramda';
import config from 'react-global-configuration';

// relative imports
import { HTTP_OK, HTTP_INVALIDARGUMENT, USERNAME_EXISTS, EMAIL_EXISTS } from '../../../helpers/constants';
import RamdaExtensions from '../../../helpers/ramda';
import AuthHttpHandlers from '../../../components/hoc/auth/hooks/useAuthHttpHandlers';
import { SignUpRequest } from '../type';

const initialState = {
    userName: '',
    password: '',
    email: '',
    isEditDisabled: false,
    isLoading: false,
    message: '',
    signupSuccess: false,
}

const signupSuccess = () => ({
    success: true,
    message: 'Successfully registered. Please login!'
});

const signupError = (error: any) => {
    const finalRes = {
        error: true,
        message: 'Some error occurred. Please try again later or contact NAVPortfolio'
    };
    if (error?.message) {
        const [code, ...errorMsg] = R.split(':', error?.message);
        const msg = errorMsg.join(':')
        if (code === USERNAME_EXISTS || code === EMAIL_EXISTS || code === R.toString(HTTP_INVALIDARGUMENT))
            finalRes['message'] = msg
    };
    return finalRes;
}

const signUp = async (values: SignUpRequest) => {
    try {
        const { data, status } = await AuthHttpHandlers.post_registerCall(values)
        return (status === HTTP_OK) ? signupSuccess() : signupError(data)

    } catch (err) {
        return signupError(err);
    }
}
const handleSignUp = async ({ state, setState, values }:
    { state: any; setState: Function; values: SignUpRequest; }) => {
    setState({ ...state, isLoading: true, message: '' });
    const signupRes = await signUp(values);
    if (R.path(['success'], signupRes)) {
        const userName = R.prop('userName', values);
        await AuthHttpHandlers.post_loginServiceID(userName)
        setState({ ...state, message: R.prop('message', signupRes), isLoading: false, signupSuccess: true, });

    } else {
        setState({ ...state, message: R.prop('message', signupRes), isLoading: false });
    }
}

const signUpUseEffect = async ({ state, setState, form, adDetailsRes }: { state: object; setState: Function; form: any; adDetailsRes: any }) => {
    setState({ ...state, isLoading: true });
    const isProductionEnv = config.get('productionEnv') === "true";

    if (!RamdaExtensions.empty(R.prop('userName', adDetailsRes))) {
        form.setFieldsValue({ userName: R.prop('userName', adDetailsRes), email: R.prop('email', adDetailsRes) });
        setState({ ...state, userName: R.prop('userName', adDetailsRes), isLoading: false, email: R.prop('email', adDetailsRes), isEditDisabled: isProductionEnv });
    } else {
        setState({ ...state, message: R.prop('message', adDetailsRes), isLoading: false, isEditDisabled: false });
    }
}

const SignUpHandlers = {
    handleSignUp,
    signUpUseEffect,
    initialState,
}
const SignUpHelpers = () => SignUpHandlers;
export default SignUpHelpers;