/* eslint-disable react-hooks/exhaustive-deps */

//absolute imports
import React, { FC, useEffect, useState, } from 'react';
import { UserOutlined, LockOutlined, MailOutlined } from '@ant-design/icons';
import { Row, Col, Input, Form, Button } from 'antd';

// relative imports
import { AjaxLoader } from '../../components/loaders/AjaxLoader';
import AlertContainer from '../../components/alerts/AlertContainer';
import { IPropsSignUp, SignUpRequest } from './type';

//Less & Icons
import '../../assets/styles/screens/login.less';
import SignUpHelpers from './hooks/useSignUpHelper';

const SignUp: FC<IPropsSignUp> = (props: IPropsSignUp): JSX.Element => {
  const [form] = Form.useForm()
  const { handleSignUp, signUpUseEffect, initialState } = SignUpHelpers();
  const [state, setState] = useState(initialState);

  const handleSignupFunc = async (values: SignUpRequest) => await handleSignUp({ state, setState, values });

  useEffect(() => {
    (async (adDetailsRes) => await signUpUseEffect({ state, setState, form, adDetailsRes }))(props.adData)
  }, [props.adData]);

  return (
    <React.Fragment>
      <Row className="w-100 py-2">
        <Col md={12} lg={12} xl={12} className="flex-column mx-auto align-self-center" style={{ zIndex: 10 }}>
          <h2 className="login-title text-center py-1 text-primary text-uppercase mb-4 font-weight-light">User Registration </h2>
          <Form
            form={form}
            name="signuppage"
            className="signup-form"
            initialValues={{
              remember: true,
            }}
            onFinish={handleSignupFunc}
          >
            <Form.Item
              name="userName"
              initialValue={form.getFieldValue('userName')}
              rules={[
                {
                  required: true,
                  message: 'Please enter username!',
                },
              ]}
            >
              <Input disabled={state.isEditDisabled} size="large" addonBefore={<UserOutlined className="site-form-item-icon" />}
                placeholder="Username"
              />
            </Form.Item>
            <Form.Item
              name="email"
              initialValue={form.getFieldValue('email')}
              rules={[
                {
                  required: true,
                  message: 'Please enter email!',
                },
              ]}
            >
              <Input disabled={state.isEditDisabled} size="large" addonBefore={<MailOutlined className="site-form-item-icon" />}
                placeholder="Email"
              />
            </Form.Item>
            <Form.Item
              name="password"
              rules={[
                {
                  required: true,
                  message: 'Please enter password!',
                },
              ]}
            >
              <Input.Password size="large" addonBefore={<LockOutlined className="site-form-item-icon" />}
                placeholder="Password"
              />
            </Form.Item>
            < AjaxLoader isLoading={state.isLoading} />
            {state.message &&
              <AlertContainer message={state.message} type={state.signupSuccess ? "success" : "error"} ></AlertContainer>
            }
            <Form.Item>
              <div className="flex-column">
                <Button type="primary" htmlType="submit" size="large" className="w-100">
                  Submit
                  </Button>
              </div>

            </Form.Item>
          </Form>
        </Col>
      </Row>
    </React.Fragment>
  )
};

export default SignUp;