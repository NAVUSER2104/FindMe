import { RouteComponentProps } from 'react-router-dom';

export interface SignUpRequest {
    userName: string,
    password: string,
    email: string
}


export interface IPropsSignUp extends RouteComponentProps<any> {
    adData: any
}
