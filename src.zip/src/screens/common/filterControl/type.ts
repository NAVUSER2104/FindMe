import { IDatePickerProps } from "components/datePicker/type";
import { PeriodType } from "helpers/enum"; 

export interface IFilterControlProps {
    /** if group control is required */
    isShowGroupControl?: boolean;
    /** if client control is required */
    isShowClientControl?: boolean;
    /** if fund control is required */
    isShowFundControl?: boolean;
    /** if frequency control is required */
    isShowFrequencySwitch?: boolean;
    /** group control width */
    groupControlWidth?: number;
    /** client control width */
    clientControlWidth?: number;
    /** fund control width */
    fundControlWidth?: number;
    /** frequency control width */
    frequencyControlWidth?: number;
    /** is Deafult selection required in case of group */
    isDefaultSelection?: boolean;
    /** if deafult selection is true then onLoad will pass all the default selected values */
    onLoad?: Function;
    /** will pass the seleted group, clients, funds and frequency data*/
    groupHandler?: Function;
    /** will pass the seleted clients, funds data*/
    clientHandler?: Function;
    /** will pass the seleted funds data*/
    fundHandler?: Function;
    /** will pass the seleted frequency data*/
    frequencyHandler?: Function;
    /** is date constrol is required*/
    isShowDateControl?: boolean;
    /**Array of type IFilterDatePickerProps containing details of all the dates required] */
    dateControlProps?: IFilterDatePickerProps[];
    /** Width of each date control */
    dateControlWidth?: number;
    /** if you want to enable fund relationship constraints and return the related funds*/
    isRelationShipRequired?: boolean;
    /** if group select then clear the client dropdown data viceversa */
    onlySelectGroupOrClient?: boolean;
    /** if you want to show label alongwith the filter control*/
    showLabel?: boolean;
    isFundSelectionSingleMode?: boolean;
    frequencyOptions?: IFrequencyControlOptions[];
}  

export interface IFilterControlResult {
    groupValues?: Array<string>;
    fundValues?: Array<number>;
    clientValues?: Array<number>;
    frequencyValue?: PeriodType | Array<PeriodType>;
    fromDate?: string;
    toDate?: string;
}

export interface IFilterDatePickerProps extends IDatePickerProps {
    dateType?: IDateType
}

export interface IFrequencyControlOptions{
    key: number;
    value: "Daily" | "Periodically" | "Yearly" | "Quarterly" | "Custom",
    text: "Daily" | "Periodically" | "Yearly" | "Quarterly" | "Custom"
}

export type IDateType = "fromDate" | "toDate"
