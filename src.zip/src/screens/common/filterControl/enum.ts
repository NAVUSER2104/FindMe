import { IOptions } from "components/comboBox/type";

enum ComboOptions {
    SELECTALL = "Select All",
    UNSELECTALL = 'Unselect All'
}


export const SELECTALLOPTION: IOptions = { groupId: ComboOptions.SELECTALL, groupName: ComboOptions.SELECTALL };

export const UNSELECTALLOPTION: IOptions = {  groupId: ComboOptions.UNSELECTALL, groupName: ComboOptions.UNSELECTALL };

const Enums = {
    ComboOptions
}

export default Enums;

//key: -1