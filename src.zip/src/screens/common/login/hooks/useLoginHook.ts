// absolute imports
import * as R from 'ramda';
import config from 'react-global-configuration';

// relative imports
import { adServiceINDInstance, adServiceUSInstance } from 'adapters/adService';
import UrlStore from 'adapters/urlStore';
import history from 'helpers/history';
import SecurityHandlers from 'components/hoc/auth/hooks/useSecurityHandlers';
import RamdaExtensions from 'helpers/ramda';
import UrlHelpers from 'helpers/urlHelpers';
import DataHelpers from 'helpers/dataHelpers';

const fetchAdDetails = async (setState: Function) => {
    const isProductionEnv = config.get('productionEnv') === "true";

    try {
        const userIND = await adServiceINDInstance().get(UrlStore.AdServiceUrl.GetUserAdDetails, {
            withCredentials: true,
        });
        var userData = R.prop('data', userIND);
        fetchAdDetailsForUSUsers(setState, userData);
    }
    catch (err) {
        await fetchAdDetailsForUSUsers(setState, null);
        !isProductionEnv && setState({
            error: true,
            message: `Some error occurred In India Ad Service. Please try again later or contact NAVPortfolio`
        });
    }
}

const fetchAdDetailsForUSUsers = async (setState: Function, userData: any) => {
    try {
        if (typeof userData !== 'object' || userData === null) {

            const userUS = await adServiceUSInstance().get(UrlStore.AdServiceUrl.GetUserAdDetails, {
                withCredentials: true,
            });
            userData = R.prop('data', userUS);
            if (typeof userData === 'object') {
                setState(userData);
            }
        }
        else {
            if (!RamdaExtensions.empty(userData)) {
                setState(userData)
            }
        }
    }
    catch (err) {
        console.log("Some error occurred In US Ad Service. Please try again later or contact NAVPortfolio", err);
    }
}

const autoLogin = () => {
    window.addEventListener('storage', (e) => {
        if (e && e.key === 'rload' && !e.newValue) {
            history.push("/login")
            window.location.reload()
        }
    })
    localStorage.getItem('rload') && (async () => {
        try {
            await SecurityHandlers.handleRefresh()
            history.push(DataHelpers.getLandingPage())
        } catch (e) {
            history.push("/login")
            localStorage.removeItem('rload')
            window.location.reload()
        }
    })()
}

const LoginHandlers = {
    fetchAdDetails,
    autoLogin
}
const LoginHelpers = () => LoginHandlers;
export default LoginHelpers;