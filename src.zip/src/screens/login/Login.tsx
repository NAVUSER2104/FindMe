/* eslint-disable react-hooks/exhaustive-deps */

//absolute imports
import React, { FC } from 'react';
import { UserOutlined, LockOutlined, TranslationOutlined } from '@ant-design/icons';
import { Row, Col, Input, Form, Button, Select, Radio, Tooltip } from 'antd';

// relative imports
import { AjaxLoader } from '../../components/loaders/AjaxLoader';
import AlertContainer from '../../components/alerts/AlertContainer';
import useLoginHook from './hooks/useLoginHook';
import { IPropsLogin, LoginRequest } from './type';

//Less & Icons
import '../../assets/styles/screens/login.less';
import { useSelector } from 'react-redux';
import { persistSelector } from 'redux/reducerPersist';

const Login: FC<IPropsLogin> = (props: IPropsLogin): JSX.Element => {
  const { state, form, handleLogin, handleApplication, overrideDefaultApp } = useLoginHook(props);
  const { application } = useSelector(persistSelector);
  const { Option } = Select;

  return (
    <React.Fragment>
      <Row className="w-100 py-2">
        <Col md={12} lg={12} xl={12} className="flex-column mx-auto align-self-center" style={{ zIndex: 10 }}>
          <h2 className="login-title text-center py-1 text-primary text-uppercase mb-4 font-weight-light">Registered User Login </h2>
          <Form
            form={form}
            name="loginpage"
            className="login-form"
            initialValues={{
              remember: true,
            }}
            onFinish={async (values: LoginRequest) => { await handleLogin({ values, props, application }) }}
          >
            <Form.Item
              name="username"
              initialValue={form.getFieldValue('username')}
              rules={[
                {
                  required: true,
                  message: 'Please enter username!',
                },
              ]}
            >
              <Input disabled={state.isEditDisabled} size="large" addonBefore={<UserOutlined className="site-form-item-icon" />}
                placeholder="Username"
              />
            </Form.Item>
            {/* <Form.Item
              name="password"
              hidden={state.isPasswordDisabled}
              rules={[
                {
                  required: !state.isPasswordDisabled,
                  message: 'Please enter password!',
                },
              ]}
            >
              <Input.Password size="large" addonBefore={<LockOutlined className="site-form-item-icon" />}
                placeholder="Password"
              />
            </Form.Item> */}
            <Form.Item>
              <div className="flex-column">
                <Row align="middle" className='application-icon'>
                  <Col span={2} className='text-center'>
                    <TranslationOutlined className="site-form-item-icon" />
                  </Col>
                  <Col span={22}>
                    <Select
                      className="login-select-app"
                      size="large"
                      placeholder="Application"
                      value={application}
                      onChange={handleApplication}
                    >
                      {state.applicationOptions.map(item => (
                        <Select.Option key={item.key} value={item.value}>
                          <Tooltip placement="right" title="Set default app">
                            <Radio checked={item.checked} onChange={(e) => overrideDefaultApp(e, item.text)} />
                          </Tooltip>
                          {item.text}
                        </Select.Option>
                      ))}
                    </Select>
                  </Col>
                </Row>
              </div>
            </Form.Item>
            < AjaxLoader isLoading={state.isLoading} />
            {state.message &&
              <AlertContainer message={state.message} type={state.loginSuccess ? "success" : "error"} />
            }

            <Form.Item>
              <div className="flex-column">
                <Button type="primary" htmlType="submit" size="large" className="w-100">
                  Submit
                </Button>
              </div>

            </Form.Item>
          </Form>
        </Col>
      </Row>
    </React.Fragment >
  )
};

export default Login;