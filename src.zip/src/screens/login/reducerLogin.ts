// absolute imports
import { createSlice } from "@reduxjs/toolkit";

// relative imports
import { RootState } from '../../redux/rootReducer';
import { UserData, userModel } from "./type";

export interface UserState {
    message: string,
    isAuthenticated: boolean,
    isLoggedOut: boolean,
    userData: UserData,
    accessToken?: string,

}

const initialState: UserState = {
    message: '',
    isAuthenticated: false,
    isLoggedOut: false,
    userData: userModel,
    accessToken: undefined,
}

export const loginReducer = createSlice({
    name: 'user',
    initialState,
    reducers: {
        setUserData: (state, { payload }) => {
            state.userData = payload
        },
        logoutSuccess: state => {
            state.isAuthenticated = false
            state.isLoggedOut = true
            state.message = 'You have successfully logged out.'
        },
        setAuthToken: (state, { payload }) => {
            state.accessToken = payload
            state.isAuthenticated = true
        },
        setLogOut: state => {
            state.accessToken = undefined
            state.isAuthenticated = false
            state.isLoggedOut = true
        },
    }
})

const { logoutSuccess, setUserData, setAuthToken, setLogOut, } = loginReducer.actions
const loginSelector = (state: RootState) => state.loginReducer

export const LoginReducer = {
    loginSelector,
    logoutSuccess,
    setUserData,
    setAuthToken,
    setLogOut,
};
export default LoginReducer;