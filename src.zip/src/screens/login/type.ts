import { RouteComponentProps } from 'react-router-dom';

export interface LoginRequest {
    username: string,
    password: string,
    application: string
}

export interface UserData {
    userID: string,
    roleID: string,
    loginID: number,
    userName: string,
    email: string,
    application: string
}

export const userModel = {
    userID: '',
    roleID: '',
    loginID: -1,
    userName: '',
    email: '',
    application: ''
}

export interface IPropsLogin extends RouteComponentProps<any> {
    adData: any
}

export interface IUseState {
    username: string,
    password: string,
    email: string,
    isEditDisabled: boolean,
    isPasswordDisabled: boolean,
    isLoading: boolean,
    message: string,
    loginSuccess: boolean,
    applicationOptions: IAppOptions[],
}

export interface IAppOptions {
    checked: boolean;
    key: number | string;
    value: string;
    text: string;
}