// absolute imports
import * as R from 'ramda';
import config from 'react-global-configuration';
import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Form } from 'antd';

// relative imports
import LoginReducer from 'screens/login/reducerLogin';
import { HTTP_UNAUTHORIZED, HTTP_FORBIDDEN, HTTP_OK, HTTP_INVALIDARGUMENT } from 'helpers/constants';
import RamdaExtensions from 'helpers/ramda';
import AuthHttpHandlers from 'components/hoc/auth/hooks/useAuthHttpHandlers';
import SecurityHandlers from 'components/hoc/auth/hooks/useSecurityHandlers';
import { LoginRequest, IPropsLogin, IUseState, IAppOptions } from 'screens/login/type';
//import SetDefaultReducer from 'screens/setDefaults/reducerSetDefault';
import { setApplication } from 'redux/reducerPersist';
import dashboardServiceInstance from 'adapters/dashboardService';
//import { ApplicationLookupUrl } from 'adapters/urlStore';
import UrlHelpers from 'helpers/urlHelpers';
import { Application } from 'helpers/enum';
import DataHelpers from 'helpers/dataHelpers';
import openNotification from 'components/notification/notification';
const ApplicationLookupUrl = {
    GetFasApplications: "/application/GetFasApplications",
    GetDefaultApplication: "/application/GetDefaultApplication",
    UpdateDefaultApplication: "/application/UpdateDefaultApplication"
}
const useLoginHook = (props: IPropsLogin) => {
    const dispatch = useDispatch(); // action to be invoked using dispatch
    const [form] = Form.useForm();
    const username = R.prop('userName', props.adData);

    const [state, setState] = useState<IUseState>({
        username: '',
        password: '',
        email: '',
        isEditDisabled: false,
        isPasswordDisabled: true,
        isLoading: false,
        message: '',
        loginSuccess: false,
        applicationOptions: [],
    });

    useEffect(() => {
        if (props.adData) {
            setState({ ...state, isLoading: true });
            const isProductionEnv = config.get('productionEnv') === "true";
            if (!RamdaExtensions.empty(R.prop('userName', props.adData))) 
            {
                form.setFieldsValue({ username: R.prop('userName', props.adData) });
                setState(({ ...state, username: R.prop('userName', props.adData), isLoading: false, email: R.prop('email', props.adData), isPasswordDisabled: true, isEditDisabled: isProductionEnv }));
            } 
            else 
            {
                setState({ ...state, message: R.prop('message', props.adData), isLoading: false, isPasswordDisabled: !isProductionEnv, isEditDisabled: false });
            }
        } else {
            setState({ ...state, isLoading: false, isPasswordDisabled: false, isEditDisabled: false });
        }
    }, [props.adData]);

    useEffect(() => {


        (async () => {
            try {
                let defaultApplication = Application.NAVMain2;
                /*if (!RamdaExtensions.empty(username)) 
                {
                    let relativeUrl = UrlHelpers.prepareRelativeUrl(ApplicationLookupUrl.GetDefaultApplication, { loginName: username })
                    let defaultApplicationJob = dashboardServiceInstance().get(relativeUrl)
                    defaultApplication = (await defaultApplicationJob)?.data
                    if (RamdaExtensions.empty(defaultApplication)) {
                        defaultApplication = Application.NAVMain2
                    }
                }

                let applicationComboDataJob = dashboardServiceInstance().get(ApplicationLookupUrl.GetFasApplications)
                let applicationComboData = await applicationComboDataJob
                let applicationOptions: IAppOptions[] = applicationComboData?.data?.map((item: any, index: number) => ({
                    key: index,
                    value: item.appName,
                    text: item.appName,
                    checked: item.appName?.toLowerCase() === defaultApplication?.toLowerCase() ? true : false
                }));
                if (RamdaExtensions.empty(applicationOptions)) {
                    applicationOptions = []
                }
                setState(prev => ({ ...prev, applicationOptions }))
            */
                dispatch(setApplication(defaultApplication))

            } catch (e) {
                console.log('=== GetFasApplications and GetDefaultApplication error: ', e);
            }
        })()
    }, [username])

    const loginSuccess = async (data: any) => 
    {
    debugger;

        const token = R.prop('access_token', data)
        const userData = SecurityHandlers.extractUserClaim(token); 
        dispatch(LoginReducer.setAuthToken(token));
        localStorage.setItem('rload', "1"); // used for automatic refresh on page reload
        if (config.get('productionEnv') === "false") 
        {
            localStorage.setItem('Token', token);  // to bypass auth on dev
        }
      /*  if (!R.prop('loginID', userData)) 
        {
            const userName = R.prop('userName', userData);
            userData.loginID = await AuthHttpHandlers.post_loginServiceID(data.userName)
        }
        */
        dispatch(LoginReducer.setUserData(userData));
        //dispatch(SetDefaultReducer.setDefaultSettingOpen(true))
        dispatch(setApplication(userData.application))
        return {
            success: true,
            message: 'Login Succesfully'
        };
    }

    const loginError = (error: any) => {
        const finalRes = {
            error: true,
            message: 'Some error occurred. Please try again later or contact NAVPortfolio'
        };
        if (error?.message) {
            const [code, ...errorMsg] = R.split(':', error?.message);
            const msg = errorMsg.join(':')

            if (code === R.toString(HTTP_UNAUTHORIZED))
                finalRes['message'] = 'You are not registered. Please signup first.';
            else if (code === R.toString(HTTP_INVALIDARGUMENT))
                finalRes['message'] = msg;
            else if (code === R.toString(HTTP_FORBIDDEN) && state.isPasswordDisabled === false)  // Incorrect Password
                finalRes['message'] = msg;
        };
        return finalRes;
    }
    
    const login = async (values: LoginRequest) => {
        try {
         //debugger
            
            const { data, status } = await AuthHttpHandlers.post_loginCall(values, state.isPasswordDisabled)
            return (status === HTTP_OK) ? await loginSuccess(data) : loginError(data)
           
           // return  await loginSuccess(values) 
        } catch (err) {
            return loginError(err);
        }
    }

    const handleLogin = async ({ values, props, application }: { values: LoginRequest; props: any; application: string }) => 
    {
        setState({ ...state, isLoading: true, message: '' });
        values.application = application;
        const loginRes = await login(values);
        if (R.path(['success'], loginRes)) 
        {
            setState({ ...state, message: R.prop('message', loginRes), isLoading: false, loginSuccess: true, });
            props.history.push(DataHelpers.getLandingPage());
        } else {
            setState((prev: any) => ({ ...prev, message: R.prop('message', loginRes), isLoading: false }));
        }
    }

    const handleApplication = (value: string) => {
        dispatch(setApplication(value))
    }

    const overrideDefaultApp = (e: any, value: string | number) => {
        let newAppOptions = state.applicationOptions.map(x => {
            x.checked = (x.value === value)
            return x
        });

        (async () => {
            try {
                let relativeUrl = UrlHelpers.prepareRelativeUrl(ApplicationLookupUrl.UpdateDefaultApplication, { loginName: username, appName: value })
                await dashboardServiceInstance().post(relativeUrl, {})
            } catch (e) {
                console.log('=== UpdateDefaultApplication error: ', e);
                openNotification({ notificationType: 'Error', message: '' })
            }
        })()

        dispatch(setApplication(value.toString()))

        setState(prev => {
            return { ...prev, applicationOptions: newAppOptions }
        })

    }
    return {
        state,
        handleLogin,
        login,
        form,
        handleApplication,
        overrideDefaultApp
    }

}

export default useLoginHook;