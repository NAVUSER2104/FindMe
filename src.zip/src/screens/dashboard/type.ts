
export interface IGetProcessWisePortfolioResponse {
    processDate: string;
    items: IArrayProcessWiseStatus[]
}


export interface IArrayProcessWiseStatus {    
    processName: string;
    percentage: number;
    
}

export interface IGetPortfolioStatusResponse {
    processDate: string;
    items: IArrayPortfolioStatus[]
}


export interface IArrayPortfolioStatus {        
    portfolioStatus: string;
    percentage: number;
}


export interface IFundPortfolioDashboard {
    processDate: string;
    items: IArrayFundPortfolioDashboard[]
}
export interface IArrayFundPortfolioDashboard {
    clientId: number,
    clientName: string,
    accountName: string,
    //status: string 
}

export interface IGetGroupData {
    items: IArrayPortfolioStatus[]
}

export interface IArrayGetGroupData { 
     
    groupId: string;
    groupName: string;
    
}
