// absolute imports
import { createSlice } from "@reduxjs/toolkit";

// relative imports
import { RootState } from 'redux/rootReducer';

export interface DashboardState {
    refresh: Date
}


const initialState: DashboardState = {
    refresh: new Date()
}

export const dashboardReducer = createSlice({
    name: 'dashboard',
    initialState,
    reducers: {
        setRefresh: (state, { payload }) => {
            state.refresh = payload;
        }
    }
})

const dashboardSelector = (state: RootState) => state.dashboardReducer

export const DashboardReducer = {
    dashboardSelector,
    ...dashboardReducer.actions
};
export default DashboardReducer;