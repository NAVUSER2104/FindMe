import dashboardServiceInstance from "adapters/dashboardService";
import UrlStore from "adapters/urlStore";
import RamdaExtensions from "helpers/ramda";
import UrlHelpers from "helpers/urlHelpers";
import { useSelector } from "react-redux"; 
import axios from 'axios'
import { Result } from "antd";
import DateHelpers from "helpers/dateHelpers";
import { group } from "console";

const useHttpHook = () => {
 
    const dashboardInstance = dashboardServiceInstance();
    
    const getPortfolioStatus = async(asOfDateTime: string,groupId: string) => {        
        // const result = await dashboardInstance.get(UrlStore.Main2ApiUrl.GetPortfolioStatus, {
        //     asOfDateTime: asOfDateTime,
        // });
        // return result; 
        // };

        try 
        { 
            const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetProcessWisePortfolioStatus,
                {
                    asOfDateTime: DateHelpers.formatDate(new Date(asOfDateTime), DateHelpers.DateFormatEnum["YYYY-MM-DDTHH:mm:ss"]),
                    groupId : ""
                }
            );
            return await dashboardServiceInstance().get(relativeUrl);
        } 
        catch (e) 
        {
            console.log(e)
        }
    };
    
    const getClientWiseDeliveryStatus = async(asOfDateTime: string) => {        
        //debugger 
        
        // const result = await dashboardInstance.get(UrlStore.Main2ApiUrl.GetClientWiseDeliveryStatus,
            //     {
            //         asOfDateTime: asOfDateTime,
            //     });
            // return result; 
            // };
            try 
            {
  
                const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetClientPortfolioStatus,
                    {
                        asOfDateTime: DateHelpers.formatDate(new Date(asOfDateTime), DateHelpers.DateFormatEnum["YYYY-MM-DDTHH:mm:ss"]),
                        
                    }
                );
 
                return await dashboardServiceInstance().get(relativeUrl);
            } 
            catch (e) 
            {
                console.log(e)
            }
        };
        

    return {
        getPortfolioStatus,
        getClientWiseDeliveryStatus
    }

    
 
}



export default useHttpHook;