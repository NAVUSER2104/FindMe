import { useEffect, useState } from "react";
import useFormattingHelpers from "screens/dashboard/hooks/useFormattingHelpers";
import useHttpHook from "screens/dashboard/hooks/useHttpHook";
import DashboardEnums from "screens/dashboard/enum";
import Highcharts, { chart } from "highcharts";
import * as R from "ramda";
import { IArrayProcessWiseStatus, IFundPortfolioDashboard, IGetProcessWisePortfolioResponse , IArrayGetGroupData } from "../type";
import RamdaExtensions from "helpers/ramda";
import openNotification from "components/notification/notification";
import { useSelector } from "react-redux"; 
 
import DateHelpers from "helpers/dateHelpers";
import { DateComparatorResults } from "helpers/enum";
import Dashboard from "../Dashboard";
import { DateComponent } from "components/agGrid/CustomComponent"; 
import UrlHelpers from "helpers/urlHelpers";
import UrlStore from "adapters/urlStore";
import dashboardServiceInstance from "adapters/dashboardService";
import { isNull, values } from "lodash";


require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);

const usePortfolioStatusHook = (props: any, handler: Function,prop : any) => {
    console.log(prop)
    const { getPortfolioStatus } = useHttpHook();
    const { getGraphTitle } = useFormattingHelpers;
    const [isLoading, setIsLoading] = useState(false);
    const dashboardInstance = dashboardServiceInstance(); 

    const [chartData, setChartData] = useState({
        subTitle: "NAVMain2", 
        entityNames: [],
        entityValues: [],
        valueSuffix: ' %',
        title: 'Process Wise Status'
    });

    

    //uncomment this to fetch data from API and add a parameter also for groupId
    const getFundPortfolioSummary = async (asOfDateTime: string, name: any) => {
        
        

        /*const getApiStatusUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetFundPortfolioSummary,
            {               
                asOfDateTime: asOfDateTime,
                name: name
            })*/
            
            
        try {
             /*let res = await dashboardInstance.get(getApiStatusUrl);

             var apiSummary = res.data.data;

         //   let localProcessWiseStatus:IFundPortfolioDashboard[];
            
             //localProcessWiseStatus.push("",)

             //let localEntityNames: string[] = R.map((item: IFundPortfolioDashboard) => (item.items[].), items)


                // let values = [];
                // values.push(1312);
                // values.push("sdfdsfd");*/
          

            const userData = [
                {clientid : '1', clientname : 'LGT' , accountname : 'Crown managed account' , status : 'File Reading'},
                {clientid : '2', clientname : 'Crabel' , accountname : 'crabel account' , status : 'File Reading'},
                {clientid : '3', clientname : 'Steben' , accountname : 'Steben account' , status : 'File Reading'}
            ]

            handler(userData);    

            
             /*if (apiSummary && apiSummary.items.length > 0) 
             {
                 //debugger;
                    handler(apiSummary.items)
             }*/
            
            
             
        }
        catch (ex) {
            setIsLoading(false);
           // openNotification({ notificationType: 'Error', message: `Exception while getApiStatusSummary for applicationName:${applicationName} and serverName ${serverName}` })
            //console.log(`Exception while getApiStatusSummary for applicationName:${applicationName} and serverName ${serverName}`)
        }
    }
    
    const [isModalVisible, setIsModalVisible] = useState(false);
  

    const [filterValue, setFilterValue] = useState(DashboardEnums.ClientFundsFilter.AUM)

    const [topPortfolioStatusOptions, setPortfolioStatusOptions] = useState({
        lang: {
                noData : 'No Data Found'
        },
        chart: {
            height: 280, 
            options3d: {
                enabled: true,
                alpha: 45
            }
        },
        title: {
            text: getGraphTitle(chartData.title, chartData.subTitle),
            useHTML: true,
            align: 'left',
            style: {
                color: '#007acc',
            }
        },
        subtitle: {
            text: '',
            align: 'left',
        }, 
        legend: {
            enabled: false
        },
        tooltip: {
            valueSuffix: chartData.valueSuffix
        },
        plotOptions: {
            pie: {
                innerSize: 100,
                depth: 45
            }, 
            series: {
                point: {
                  events: {
                    click() {
                        getFundPortfolioSummary(props.asOfDateTime,this.options.name );
                        //handler(userData);
                        //alert();
                    }
                  }
                }
              }
            
        },
        credits: {
            enabled: false
        },
        series: [
            {
                name: "Process Wise Status",
                data: chartData.entityValues,
                type: "pie" 
            }
        ],
 
    } as Highcharts.Options)

    useEffect(() => {       

        (async () => {
            try {
                let response = await getPortfolioStatus(props.asOfDateTime,prop.asOfGroupName);
                
                if (response)
                    updateLocalEntitiesHandler(response.data.data)
            } catch (ex) {
                console.log(ex);
                openNotification({
                    notificationType: "Error",
                    message: "Error in fetching Portfolio data"
                })
            }
        })();

    }, [props.asOfDateTime,prop.asOfGroupName]);

    function updateLocalEntitiesHandler(result: IGetProcessWisePortfolioResponse) {
        
        const items: IArrayProcessWiseStatus[] = result.items;
        let localEntityNames: string[] = R.map((item: IArrayProcessWiseStatus) => (item.processName), items)
             
            
        let localProcessWiseStatus:any = []
            items.forEach((val) => {
                let values = [];
                values.push(val.processName + ': '+ val.percentage+'%');
                values.push(val.percentage);
                localProcessWiseStatus.push(values);
            })  

            
            
            
        setChartData((prev: any) => ({
            ...prev,
            entityNames: localEntityNames,
            entityValues:localProcessWiseStatus,
        })); 
        
    }
 
    
    useEffect(() => {
        setPortfolioStatusOptions((prev) => ({
            ...prev,
            title: {
                ...prev.title,
                text: getGraphTitle(chartData.title, chartData.subTitle),
            }, 
            tooltip: {
                valueSuffix: chartData.valueSuffix
            },
            series: [
                {
                    name: "Process Wise Status",
                    data: chartData.entityValues,
                    type: "pie" 
                }
            ],

        }));
    }, [chartData])
    
    return {
        
        topPortfolioStatusOptions
    };


}


export default usePortfolioStatusHook;