import { useEffect, useState } from "react";
import useFormattingHelpers from "screens/dashboard/hooks/useFormattingHelpers";
import useHttpHook from "screens/dashboard/hooks/useHttpHook";
import DashboardEnums from "screens/dashboard/enum";
import Highcharts from "highcharts";
import * as R from "ramda";
import { IArrayPortfolioStatus, IGetPortfolioStatusResponse } from "../type";
import RamdaExtensions from "helpers/ramda";
import openNotification from "components/notification/notification";
import { useSelector } from "react-redux";
import DashboardReducer from "screens/dashboard/reducerDashboard";
require('highcharts/modules/exporting')(Highcharts);
require('highcharts/modules/export-data')(Highcharts);


const useClientWiseDeliveryStatusHook = (props: any) => {
    const { refresh } = useSelector(DashboardReducer.dashboardSelector);
    const { getClientWiseDeliveryStatus } = useHttpHook();
    const { getGraphTitle } = useFormattingHelpers;

    const [chartData, setChartData] = useState({
        subTitle: "NAVMain2",
        yAxisTitle: "Population of AUM (numbers)",
        entityNames: [],
        entityValues: [],
        valueSuffix: ' percentage',
        title: 'New Client/ Fund Setup'
    });

    const [filterValue, setFilterValue] = useState(DashboardEnums.ClientFundsFilter.AUM)

    const [clientWiseDeliveryStatusOptions, setPortfolioStatusOptions] = useState({
        chart: {
            height: 280
        },
        title: {
            text: useFormattingHelpers.getGraphTitle(chartData.title, chartData.subTitle),
            align: 'left',
            useHTML: true,
            style: {
                color: '#007acc',
                textTransform: 'capitalize',
                fontWeight: '400'
            }
        },
        xAxis: {
            accessibility: {
                rangeDescription: `Range: 2012 to ${new Date().getFullYear()}`,
            },
        },
        yAxis: {
            min: 0,
            title: {
                text: "Number of Funds"
            }
        },
        legend: {
            align: 'center',
            verticalAlign: 'bottom',
            itemStyle: {
                font: '8pt "Lucida Sans Unicode", Arial, Helvetica, sans-serif',
                color: 'grey'
            },
            itemHoverStyle: {
                color: 'black'
            },
            itemHiddenStyle: {
                color: '#444'
            }
        },
        credits: {
            enabled: false
        },
        plotOptions: {
            series: {
                label: {
                    connectorAllowed: true,
                },
                pointStart: 2014,
            },
        },
        series: [{
            name: 'Client',
            data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
        }, {
            name: 'Funds',
            data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
        }, {
            name: 'Broker Accounts',
            data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
        }, {
            name: 'Other',
            data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]
        }],
    } as unknown as Highcharts.Options)

    useEffect(() => {

        (async () => {
            try {
                let response = await getClientWiseDeliveryStatus(props.asOfDateTime);
                if (response)
                    updateLocalEntitiesHandler(response.data.data)
            } catch (ex) {
                console.log(ex);
                openNotification({
                    notificationType: "Error",
                    message: "Error in fetching client wise delivery data"
                })
            }
        })();

    }, [props.asOfDateTime]);

    function updateLocalEntitiesHandler(result: IGetPortfolioStatusResponse) {
        const items: IArrayPortfolioStatus[] = result.items;
        let localEntityNames: string[] = R.map((item: IArrayPortfolioStatus) => (item.portfolioStatus), items),
            localEntityValues: number[] = R.map((item: IArrayPortfolioStatus) => (item.percentage), items)

        setChartData((prev: any) => ({
            ...prev,
            entityNames: localEntityNames,
            entityValues: localEntityValues,
        }));
    }


    return {
        clientWiseDeliveryStatusOptions
    };


}

export default useClientWiseDeliveryStatusHook;