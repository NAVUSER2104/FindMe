import React from "react";
import { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import * as R from 'ramda';
import { IFilterControlProps } from "screens/common/filterControl/type";
import { IArrayGetGroupData, IGetGroupData } from "../type";
import UrlHelpers from "helpers/urlHelpers";
import UrlStore from "adapters/urlStore";
import dashboardServiceInstance from "adapters/dashboardService";
import DateHelpers from "helpers/dateHelpers";

const useFilterControlHook = () => {
    
    const [group,setgroup] = useState({groupsdata : []})
    
    const dashboardInstance = dashboardServiceInstance();
  
    const getGroupData = async() => {        
        
        try 
        { 
            const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetGroupData,
                {
                    
                }
            );
            return await dashboardServiceInstance().get(relativeUrl);
        } 
        catch (e) 
        {
            console.log(e)
        }
    };
    useEffect(() => {       

        (async () => {
            try {
                let response = await getGroupData();
                //debugger
                if (response)
                    {
                        setgroup((prev: any) => ({
                            ...prev,
                            groupsdata : response?.data
                        })); 
                    }
            } catch (ex) {
                console.log(ex);
            }
        })();

    }, []);

    
    
    
    return {group}
}

export default useFilterControlHook;