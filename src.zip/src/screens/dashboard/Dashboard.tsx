    //absolute imports
    import { Row, Col, Layout,Divider,TimePicker,DatePicker, Card,Modal, Button  } from "antd";
    import Highcharts from "highcharts";
    import HighchartsReact from "highcharts-react-official";
    import moment from "moment";
    import { useDispatch } from "react-redux";

    import NoDataToDisplay from 'highcharts/modules/no-data-to-display';

    import usePortfolioStatusHook from 'screens/dashboard/hooks/usePortfolioStatusHook';
    import useClientWiseDeliveryStatusHook from 'screens/dashboard/hooks/useClientWiseDeliveryStatusHook';
    import 'assets/styles/screens/login.less'; 

    import TitleBar from "components/title/TitleBar"; 
    import DateHelpers from "helpers/dateHelpers";
    import { useEffect, useState } from "react";
    import { DateComparatorResults } from "helpers/enum";
    import openNotification from "components/notification/notification";
    import { any, props } from "ramda";
    import { Console } from "console";
    import { AgGridReact} from "ag-grid-react"
    import 'ag-grid-community/dist/styles/ag-grid.css'
    import 'ag-grid-community/dist/styles/ag-theme-balham.css'
    import { truncate } from "fs";
    import WebGrid from "components/agGrid/Grid";
    import { IDefGridColumn, IGridColumn } from "components/agGrid/IGridColumn";
    import { sizeColumnsToFit } from "components/agGrid/CommonFunctions";
    import ComboBox from "components/comboBox/ComboBox";
    import { isNull, map } from "lodash";
    import useFilterControlHook from "./hooks/useFilterControlHook";
    import { SearchOutlined } from "@ant-design/icons";
    const { Content } = Layout;

    const Dashboard = (): JSX.Element => 
    {
        
        const [groupData,setgroupData] = useState([])
        const [isModalVisible, setIsModalVisible] = useState(false);
        const [modalData, setModalData] = useState([])

        var defaultColDef: IDefGridColumn = {
            sortable: true,
            resizable: true,
            minWidth: 300
        };

    const showModal = (data:any) => {

        
        setModalData(data)
        setIsModalVisible(true);
    };

    const handleOk = () => {
        setIsModalVisible(false);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
    };

        const [isChecked, setIsChecked] = useState(true);
        const [time, setTime] = useState(
            {
                interval: 0 as any
            }
        );
        
        const [state, setState] = useState(
            {  
                asOfDateTime: new Date()
            }
        );


        useEffect(() => {
        
            let interval = setInterval(() =>  setState((prev) => ({ ...prev,  asOfDateTime: new Date() })),800000);   
                    setTime({interval: interval})      
            
        }, []);
    
        var columnDefs: IGridColumn[] = [
            {
                headerName: 'Client ID',
                filter: true,
                rowGroup: true,
                field: 'clientid', 
                minWidth: 30,
                maxWidth: 90,
            },
            {
                headerName: 'Client Name',
                filter: true,
                field: 'clientname',
                minWidth: 100,
                maxWidth: 150 
            },
            {
                headerName: 'Account Name',
                filter: true,
                field: 'accountname',
                minWidth: 300,
                maxWidth: 350
            },
            {
                headerName: 'Status',
                filter: true,
                field: 'status',
                minWidth: 150,
                maxWidth: 200,
            }
        ];
        const [gridApi, setGridApi] = useState({} as any);
        const onGridReady = (event: any) => {
            setGridApi(event);
            sizeColumnsToFit(event);
        }
        const [isGroup,setGroup] = useState({
            asOfGroupId : "0000",
            asOfGroupName : "Select Groups"
        });
        const { group } = useFilterControlHook();
        console.log(group.groupsdata)
        
        const { topPortfolioStatusOptions } = usePortfolioStatusHook(state, showModal,isGroup.asOfGroupName);
        const { clientWiseDeliveryStatusOptions } = useClientWiseDeliveryStatusHook(state) ;
        
        const handleCheckbox = (event : any) => 
        {
            if(event)
            {
                let e = event
                setIsChecked(!e.target.checked)

                if(e.target.checked)
                {                
                    clearInterval(time.interval);
                }
                else
                {
                    let interval = setInterval(() =>  setState((prev) => ({ ...prev,  asOfDateTime: new Date() })),10000);   
                    setTime({interval: interval})                
                    
                }
            }
        }
        const [changeinterval, setchangeinterval] = useState(
            {  
                asOfDateTime: new Date()
            }
        );


        useEffect(() => {
        
            let intervall = setInterval(() =>  setchangeinterval((prev) => ({ ...prev,  asOfDateTime: new Date() })),10000);   
            clearInterval(intervall)          
            
        }, []);
        
        const handleFromDateChange = (event: any) => {
            //debugger
            if (event) 
            {
                let date = event._d;    
                if (date) 
                {
                    setState((prev) => ({ ...prev,  asOfDateTime: date }))
                    
                }
                else 
                {
                    openNotification({ notificationType: 'Info', message: 'Date should not be empty' });
                }
            }
        };
        
        const handleGroup = (groupIds : any,groupNames : any) =>    
        {
            //debugger
            if (groupIds && groupNames) 
            {
                let groupId = groupIds;
                let groupName = groupNames.children;    
                if (groupName && groupId) 
                {
                    setGroup((prev) => ({ ...prev,  asOfGroupId : groupId , asOfGroupName : groupName }))
                }
                else 
                {
                    openNotification({ notificationType: 'Info', message: 'Group should not be empty' });
                }
            }
        }

        
//console.log(isGroup.asOfGroupName)
        return (
            <Content className="wrapper-container">
                <div className="main-container">
                <TitleBar  title="Dashboard" showSearch={false} showRefresh={true}/>

                    <div className='child-wrapper mt-3 py-3 px-3'>
                        <Row justify="space-between">
                            <Col xs={24}>
                                <Card size="small">
                                    <Card.Meta description={
                                        <Row align="middle" gutter={[6, 6]}>
                                            <Col style = {{paddingLeft : 30}} xs={2}>Live </Col>
                                            <input type = "checkbox" checked = {!isChecked} onChange = {(e) => handleCheckbox(e)} /> 
                                            <Col  style = {{paddingLeft : 10}} xs={4}>
                                            <DatePicker format="YYYY-MM-DD HH:mm:ss" defaultValue={moment()} 
                                            showTime={{ defaultValue: moment('00:00:00', 'HH:mm:ss') }} 
                                            onChange={(date) => handleFromDateChange(date)}  disabled= {isChecked}                                        
                                            />
                                            </Col>
                                            
            
            
                                            <Col style = {{paddingLeft : 30}} xs={2}>Groups </Col>
                                            <Col xs={4}> 
                                            <ComboBox handler = {handleGroup} placeHolder="Select Groups"  data = {group.groupsdata} /> 
                                            </Col>
                                            <Col xs={6}></Col>
                                            <Col xs={4}>
                                            <Button type="primary" icon={<SearchOutlined/>} onClick = {() => topPortfolioStatusOptions} >
                                            Search
                                            </Button>
                                            </Col>
                                        </Row>
                                    }>
                                    </Card.Meta>
                                </Card>
                            </Col>
                        </Row>
                
                        <Row gutter={[16, 16]} className="mt-1">
                        <Col xs={12}>
                                <Card>
                                
                                {NoDataToDisplay(Highcharts)}
                                <HighchartsReact highcharts={Highcharts} options={topPortfolioStatusOptions} /> 
                                </Card>
                            </Col>
                            <Col xs={12}>
                                <Card>
                                
                                { <HighchartsReact highcharts={Highcharts} options={clientWiseDeliveryStatusOptions} /> }
                                </Card>
                            </Col>
                            
                        </Row>
                    </div>
                    <div>
                    <Modal  visible={isModalVisible} onOk={handleOk} onCancel={handleCancel}  width={800}>               
                <div >

                <Row gutter={[24, 0]} justify="space-between" align="middle">
                    <Col className='screen-header'>Fund Wise Status Summary</Col>
                    </Row> 
                    <Row gutter={[6, 6]} className="ag-theme-balham py-1 ag-odd-even" style={{ height: "28rem" }}>
                                <Col className="w-100 charts-style" style={{ height: "28rem" }}>
                    <WebGrid  defColumns={defaultColDef}
                                        columns={columnDefs}
                                        data={modalData}  
                                        onGridInitialize={onGridReady}
                                        groupUseEntireRow={true}   
                                    >
                                    </WebGrid>
                                    </Col>
                            </Row>

                </div>
                </Modal>

                    </div>
                </div>         
        </Content>
        )                 
    }

    export default Dashboard;