import * as R from 'ramda';
import { useEffect, useState } from "react";
import { IApiStatusViewModel } from 'screens/apiStatus/type';
import dashboardServiceInstance from "adapters/dashboardService";
import UrlStore from "adapters/urlStore";
import UrlHelpers from "helpers/urlHelpers";
import openNotification from 'components/notification/notification';
import { DateHelpers } from "helpers/dateHelpers";
import { DateFormatEnum, DateComparatorResults } from "helpers/enum";
import { IFilterDatePickerProps } from "screens/common/filterControl/type";
import moment from "moment";
import { sizeColumnsToFit } from "components/agGrid/CommonFunctions";
import RamdaExtensions from 'helpers/ramda';
import { themeSelector } from 'redux/reducerTheme';
import { useSelector } from 'react-redux';

const useApiStatusHook = (props: any) => {

    const dashboardInstance = dashboardServiceInstance();
    const [gridApi, setGridApi] = useState({} as any);
    const [isLoading, setIsLoading] = useState(false);
    const [isImportStarted, setIsImportStarted] = useState(false);

    const [isBankSummaryModalVisible, setIsBankSummaryModalVisible] = useState(false);
    const { theme } = useSelector(themeSelector);

    const [state, setState] = useState({
        clientComboOptions: new Map(),
        fundComboOptions: new Map(),
        fundsList: new Map(),
        applicationName: String,
        globalFundId: Number,
        comboBoxLoading: true,
        headerContent: "Cash Code Mappings",
        subHeaderContent: "Map RTA Cash Codes to FAS Tags/Budgets.",
        serverName: String,
        filterValue: '',
        isLoading: false,
        isSaving: false,
        openModal: false,
        statusMessage: "",
        showAll: true,
        selectedFundsAccountsData: [],
        importBankSummaryDate: new Date(),
        tableData: [] as Array<IApiStatusViewModel>,
        filteredData: [] as Array<IApiStatusViewModel>,
        isCallForImportSummary: false
    });

    const onGridReady = (event: any) => {
        setGridApi(event);
        sizeColumnsToFit(event);
    }
    
    useEffect(() => {
        if (gridApi && gridApi.api) {
            gridApi.api.redrawRows({ force: true })
        }
    }, [theme])

    const prepareSelectedFundsList = (data: any) => {
        if (!RamdaExtensions.empty(data.fundValues)) {
            const fund: any = data.fundData[Number(data.fundValues)];

            setState((prev: any) => ({
                ...prev,
                applicationName: fund.fundId,
                globalFundId: fund.globalFundId,
            }));
        }
        else {
            setState((prev: any) => ({
                ...prev,
                applicationName: 0,
                globalFundId: 0
            }));
        }
    }

    const onLoad = (data: any) => {
        prepareSelectedFundsList(data);
        setState((prev: any) => ({ ...prev, serverName: data.serverName }));
    }

    const groupHandler = (data: any) => {
        prepareSelectedFundsList(data);
    }

    const handleFundChange = (data: any) => {
        prepareSelectedFundsList(data);
    }

    const handleClientChange = (data: any) => {
        setState((prev: any) => ({ ...prev, selectedClientIds: data.clientValues }));
        handleFundChange(data);
    };

    const handleFilterTextChange = (e: any) => {
        let filterValue = e.target.value;
        if (RamdaExtensions.empty(filterValue)) {
            setState((prev: any) => ({ ...prev, filteredData: R.clone(prev.tableData), filterValue }));
        }
        else {
            const filterText = filterValue.toLowerCase();
            let filteredData: Array<IApiStatusViewModel> = [];
            R.forEach((item: IApiStatusViewModel) => {
                const existingVal = Object.values(item)
                for (let value of existingVal) {
                    if (!RamdaExtensions.empty(value) && value.toString().toLowerCase().includes(filterText)) {
                        filteredData.push(item);
                        break;
                    }
                }
            }, state.tableData);
            setState((prev: any) => ({ ...prev, filteredData: filteredData, filterValue }));
        }
    };

    const modalHandler = () => {
        setIsBankSummaryModalVisible(prev => !prev)
    };

    const ShowBankSummary = () => {
        modalHandler();
    } 

    const getApiStatusSummary = async (applicationName: string, serverName: string) => {
        
        setIsLoading(true);

        const getApiStatusUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetApiStatus,
            {               
                applicationName: '',
                serverName: ''
            })
            
        try {
            let res = await dashboardInstance.get(getApiStatusUrl);

            var apiSummary = res.data.data;

            setState((prev: any) => ({ ...prev, filteredData: apiSummary.items, tableData: apiSummary.items }));
            if (apiSummary && apiSummary.items.length > 0) {
                openNotification({ notificationType: 'Success', message: "Api Status Data loaded successfully" })
            }
            else {
                openNotification({ notificationType: 'Info', message: "No data found" })
            }
            if (gridApi && gridApi.api) {
                gridApi.api.redrawRows({ force: true });
            }
            setIsLoading(false);
        }
        catch (ex) {
            setIsLoading(false);
            openNotification({ notificationType: 'Error', message: `Exception while getApiStatusSummary for applicationName:${applicationName} and serverName ${serverName}` })
            console.log(`Exception while getApiStatusSummary for applicationName:${applicationName} and serverName ${serverName}`)
        }
    }

    const handleSearch = () => {
        getApiStatusSummary(state.applicationName.toString(), state.serverName.toString());
    }

    useEffect(() => {
       
            getApiStatusSummary(props.applicationName, props.serverName);
       
    }, [props.applicationName, props.serverName, props.showSummary]);

    const handleFromDateChange = (date: moment.Moment | null, dateString: string) =>
        setState((prev: any) => ({ ...prev, serverName: dateString }));
 

    const dateControlProps: IFilterDatePickerProps[] = [
    {
        placeholder: 'serverName',
        label: 'Server Name',        
        onChange: handleFromDateChange     
    }]

    return {
        state,
        isLoading,
        isImportStarted,
        onGridReady,
        dateControlProps,
        handleSearch, 
        handleFilterTextChange,
        handleClientChange,
        handleFundChange,
        onLoad,
        groupHandler,
        modalHandler,
        ShowBankSummary,
        isBankSummaryModalVisible 
    }
}

export default useApiStatusHook;