import DataHelpers from 'helpers/dataHelpers';
import * as R from 'ramda';

const getGraphTitle = (title: string, subtitle: string) => {
    return `
            <span class="highchart-custom-title">
                ${title}
            </span>
            <span style="font-size:12px;" class="highchart-custom-subtitle">
                (${subtitle})
            </span>
        `;
}

const convertDataToBillion = (data: number[]) => {
    const newData: number[] = [];
    R.forEach((item: number) => {
        newData.push(DataHelpers.convertToBillion(item));
    }, data);
    return newData;
}

const convertDataToMillion = (data: number[]) => {
    const newData: number[] = [];
    R.forEach((item: number) => {
        newData.push(DataHelpers.convertToMillion(item));
    }, data);
    return newData;
}

const useFormattingHelpers = {
    getGraphTitle,
    convertDataToBillion,
    convertDataToMillion
}

export default useFormattingHelpers;