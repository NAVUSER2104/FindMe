import dashboardServiceInstance from "adapters/dashboardService";
import UrlStore from "adapters/urlStore";
import RamdaExtensions from "helpers/ramda";
import UrlHelpers from "helpers/urlHelpers";
import { useSelector } from "react-redux"; 
import axios from 'axios'
import { Result } from "antd";
import DateHelpers from "helpers/dateHelpers";

const useHttpHook = () => {
 
    const dashboardInstance = dashboardServiceInstance();
  
    const getApiStatus = async(applicationName: string, serverName: string) => {   
        try 
        { 
            const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.GetApiStatus,
                {
                    applicationName: applicationName,
                    serverName: serverName
                }
            );
            return await dashboardServiceInstance().get(relativeUrl);
        } 
        catch (e) 
        {
            console.log(e)
        }
    };
        
    const sendApiNotification = async(applicationName: string, serverName: string) => {   
        try 
        { 
            const relativeUrl = UrlHelpers.prepareRelativeUrl(UrlStore.Main2ApiUrl.SendApiNotification,
                {
                    applicationName: applicationName,
                    serverName: serverName
                }
            );
            return await dashboardServiceInstance().post(relativeUrl);
        } 
        catch (e) 
        {
            console.log(e)
        }
    };

    return {
        getApiStatus,
        sendApiNotification 
    }    
 
}



export default useHttpHook;