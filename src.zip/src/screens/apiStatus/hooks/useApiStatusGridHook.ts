import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';

import { IGridColumn, IDefGridColumn } from "components/agGrid/IGridColumn";
import { Themes } from 'components/title/type';
import { debug } from 'console';
import { getColorPalette } from 'helpers/color';
import { ValueFormatter } from "helpers/enum"
import * as R from 'ramda';
import { useSelector } from 'react-redux';
import { themeSelector } from 'redux/reducerTheme';
import GridIcons from "components/icons/PlusIcon"
import UrlHelpers from 'helpers/urlHelpers';
import UrlStore from 'adapters/urlStore';
import dashboardServiceInstance from "adapters/dashboardService";
import openNotification from 'components/notification/notification';
import { useState } from 'react';

const useApiStatusGridHook = () => {
 
    const dashboardInstance = dashboardServiceInstance();
    var defaultColDef: IDefGridColumn = {
        sortable: true,
        resizable: true,
        minWidth: 300
    };
    const [isLoading, setIsLoading] = useState(false);
    const { theme } = useSelector(themeSelector);
    const { red, black, green } = getColorPalette(theme);
    const darkTheme = getColorPalette(Themes.DARK);

    function setCellStyle(key: any, params: any) {
        if (R.equals(params.colDef.field, "status")) {
            if (params.data.status !== 'Running') 
            {
                return (theme === Themes.DARK) ? { color: red, backgroundColor: 'transparent' } : { color: black, backgroundColor: darkTheme.red };
            }
            if (params.data.status == 'Running') 
            {
                return (theme === Themes.DARK) ? { color: green, backgroundColor: 'transparent' } : { color: black, backgroundColor: darkTheme.green };
            }
        }
    }

    function setGridIcon(key: any, params: any) {
        if (R.equals(params.colDef.field, "Notification")) 
        {        
            console.log(params,"+++++++++++")
            
            if (params.data.status == 'Running') 
            {
                return null;
            }
            else
            {
                return GridIcons({ type:  "MailFilled"});
            }
        }
    }
 


    var columnDefs: IGridColumn[] = [
        {
            headerName: 'Sr.No',
            filter: true,
            rowGroup: true,
            field: 'id', 
            minWidth: 30,
            maxWidth: 80,
        },
        {
            headerName: 'Application Name',
            filter: true,
            field: 'applicationName',
            minWidth: 90,
            maxWidth: 140 
        },
        {
            headerName: 'Server Name',
            filter: true,
            field: 'serverName',
            minWidth: 90,
            maxWidth: 140
        },
        {
            headerName: 'Service Name',
            filter: true,
            field: 'serviceName',
            minWidth: 160,
            maxWidth: 220,
        },
        {
            headerName: 'Log File Path',
            filter: true,
            field: 'serviceUrl',
            minWidth: 160,
            maxWidth : 220, 
        },
        {
            headerName: 'Description',
            filter: true,
            field: 'serviceDescription',
            minWidth: 220,
            maxWidth: 280,
        },
        {
            headerName: 'Status',
            filter: true,
            field: 'status',
            minWidth: 60,
            maxWidth: 100,
            cellStyle: setCellStyle
        },
        {
            headerName: 'Notification', 
            field: 'Notification',
            minWidth: 90,
            maxWidth: 150,
            cellClass: "grid-cell-center",
            cType: "Custom",
            component: {
                 comp: GridIcons({ type:  "MailFilled"}),
                onClick: (p: any) => buttonHandler(p),
            },
        } 
    ];
 

    const buttonHandler = (props: any) => 
    {
        if (props.data.status !== 'Running') 
        {
            sendApiStatusSummary(props);
        } 
        props.api.redrawRows({
            force: true,
            rowNodes: [props.node],
        });
    }

    const sendApiStatusSummary = async (props: any) => {
        
        setIsLoading(true);
       // debugger;
            
        try {
            let res = await dashboardInstance.post(UrlStore.Main2ApiUrl.SendApiNotification,
                {               
                    id: props.data.id,
                    applicationName: props.data.applicationName,
                    serverName: props.data.serverName,
                    serviceName: props.data.serviceName,
                    serviceUrl: props.data.serviceUrl,
                    serviceDescription: props.data.serviceDescription,
                    status: props.data.status,
                    userName:'rohitt'
                });
 
            var apiSummary = res.data.data;
            
            if (apiSummary == true) {
                openNotification({ notificationType: 'Success', message: "Api Notification Sent successfully" })
            }
            else {
                openNotification({ notificationType: 'Info', message: "Problem in Sending email notification" })
            } 
            setIsLoading(false);
        }
        catch (ex) {
            setIsLoading(false);
            openNotification({ notificationType: 'Error', message: `Exception while sendApiStatusSummary for service:${props.data.serviceName} and serverName ${props.data.serverName}` })
            console.log(`Exception while sendApiStatusSummary for service:${props.data.serviceName} and serverName ${props.data.serverName}`)
        }
    }

    function getRowStyle(params: any) {
        if (params.node.group) {
            return { 'font-weight': 'bold', 'color': 'black' }
        }
    }
 

    return {
        defaultColDef,
        columnDefs,
        getRowStyle,
        setCellStyle 
    }

}

export default useApiStatusGridHook;