
import { RouteComponentProps } from "react-router-dom";
export interface IApiStatusViewModel {
    id: number,
    applicationName: string,
    serverName: string,
    serviceName: string,
    serviceUrl: string,
    serviceDescription: string,
    status: string,
    userName: string,
}