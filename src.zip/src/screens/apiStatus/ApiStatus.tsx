//absolute imports
import { Row, Col, Layout,Divider,TimePicker,DatePicker, Card, Button  } from "antd";
 
import moment from "moment"; 
 
import 'assets/styles/screens/login.less';

//relative imports
import TitleBar from "components/title/TitleBar";  
import { FC, useState } from "react";  
import useApiStatusHook from "./hooks/useApiStatusHook";
import WebGrid from "components/agGrid/Grid";
import { ImportOutlined, LoadingOutlined, SearchOutlined } from "@ant-design/icons";
import useApiStatusGridHook from "./hooks/useApiStatusGridHook";
import React from "react";

const { Content } = Layout;

const ApiStatus: FC<any> = (props): JSX.Element => {
    const { state,
        isLoading,
        isImportStarted,
        onGridReady,
        dateControlProps,
        onLoad,
        groupHandler,
        handleSearch,
        handleFilterTextChange,
        handleClientChange,
        handleFundChange,
    } = useApiStatusHook(props)

    const { defaultColDef, columnDefs, getRowStyle, setCellStyle } = useApiStatusGridHook()

    const titleAndFilterTagCodeBlock = (
        <div>
            <TitleBar title="Api Status Summary"
                showSearch={true}
                searchDisabled={isLoading}
                onSearchChange={handleFilterTextChange}
                showRefresh={true}
                onRefresh={handleSearch}
            />
            <Row gutter={[6, 6]}>
                <Col span={20} >
                    {/* <FilterControl
                        isShowGroupControl={true}
                        isShowFundControl={true}
                        isShowClientControl={true}
                        isShowDateControl={true}
                        isShowFrequencySwitch={false}
                        onLoad={onLoad}
                        groupHandler={groupHandler}
                        clientHandler={handleClientChange}
                        fundHandler={handleFundChange}
                        groupControlWidth={4}
                        clientControlWidth={7}
                        fundControlWidth={7}
                        dateControlWidth={3}
                        dateControlProps={dateControlProps}
                        isFundSelectionSingleMode={true}
                        isDefaultSelection={true}
                    /> */}
                </Col>
                <Col >
                    <Button
                        type="primary"
                        size="middle"
                        onClick={handleSearch}
                        disabled={isLoading}
                        icon={<SearchOutlined />}
                    >
                        Search
                    </Button>
                </Col>
              
            </Row>
        </div>
    );
    console.log(state.filteredData,"------------------------")
    return (
        <React.Fragment>
            <Content className="wrapper-container">
                <div className="main-container">
                    {(props.hideFilterControls) ? <div></div> : <div>{titleAndFilterTagCodeBlock}</div>}
                    <div className="child-wrapper mt-3 py-3 px-3">
                        <Row gutter={[6, 6]} className="ag-theme-balham py-1 ag-odd-even" style={{ height: "36rem" }}>
                            <Col className="w-100 charts-style" style={{ height: "35rem" }}>
                                <WebGrid
                                    defColumns={defaultColDef}
                                    columns={columnDefs}
                                    data={state.filteredData}
                                    onGridInitialize={onGridReady}
                                    groupUseEntireRow={true}
                                    getRowStyle={getRowStyle}
                                    showLoading={isLoading}
                                    setCellStyle={setCellStyle}
                                >
                                </WebGrid>
                            </Col>
                        </Row>

                    </div>
                </div>
            </Content>
        </React.Fragment >
    )                 
}

export default ApiStatus;