enum ClientFundsFilter {
    ACCOUNTS = 1,
    INVESTORS = 2,
    FUNDS = 3,
    AUM = 4
}


const DashboardEnums = {
    ClientFundsFilter 
}

export default DashboardEnums;