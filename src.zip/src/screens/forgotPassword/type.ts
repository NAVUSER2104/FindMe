import { RouteComponentProps } from 'react-router-dom';

export interface ResetPasswordRequest {
    userName: string,
    newPassword: string,
    otp: string
}

export interface IPropsForgotPassword extends RouteComponentProps<any> {
    adData: any
}
