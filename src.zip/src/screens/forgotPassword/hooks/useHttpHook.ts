// absolute imports
import * as R from 'ramda';
//import CryptoJs from 'crypto-js';

//Relative imports
import UrlStore from "adapters/urlStore";
import dashboardServiceInstance from "adapters/dashboardService";
import UrlHelpers from "helpers/urlHelpers";
import { ResetPasswordRequest } from 'screens/forgotPassword/type';

const useHttpHook = () => {

    const sendOtpForUser = async (userName: string) => {
        try {
            return await dashboardServiceInstance().get(UrlHelpers.prepareRelativeUrl(UrlStore.LoginUrl.SendOTP, { userName }));
        } catch (e) {
            console.log(e);
            throw e;
        }
    }


    const resetUserPassword = async (userData: ResetPasswordRequest) => {
        try {
            return await dashboardServiceInstance().post(UrlStore.LoginUrl.ResetPassword, {
                userName: R.prop('userName', userData),
                otp: R.prop('otp', userData),
                newPassword: CryptoJS.SHA256(R.prop('newPassword', userData)).toString(),
            });
        } catch (e) {
            console.log(e);
            throw e;
        }
    }

    return {
        sendOtpForUser,
        resetUserPassword,
    }

}
export default useHttpHook;