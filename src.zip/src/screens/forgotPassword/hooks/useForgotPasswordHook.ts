// absolute imports
import * as R from 'ramda';
import { useState, useEffect } from 'react';
import { Form } from 'antd';

// relative imports
import RamdaExtensions from 'helpers/ramda';
import { IPropsForgotPassword, ResetPasswordRequest } from 'screens/forgotPassword/type';
import useHttpHook from 'screens/forgotPassword/hooks/useHttpHook';
import openNotification from 'components/notification/notification';

const useForgotPassowrdHook = (props: IPropsForgotPassword) => {
    const OTP_EXPIRATION_TIME = 200;
    const { sendOtpForUser, resetUserPassword } = useHttpHook();
    const [state, setState] = useState({
        userName: '',
        email: '',
        isLoading: false,
        message: '',
        counter: 0,
        otpLoader: false,
        otp: ''
    });
    const [resetPasswordForm] = Form.useForm();
    const [otpForm] = Form.useForm();

    useEffect(() => {
        if (!RamdaExtensions.empty(R.prop('userName', props.adData))) {
            setState((prev: any) => ({
                ...prev, userName: R.prop('userName', props.adData),
                email: R.prop('email', props.adData)
            }));
        } else {
            setState((prev: any) => ({ ...prev, message: R.prop('message', props.adData) }));
        }
        resetPasswordForm.resetFields();
    }, [props.adData]);

    useEffect(() => {
        const timer = state.counter > 0 && setInterval(() =>
            setState(prev => ({ ...prev, counter: prev.counter - 1 })), 1000) as any;
        return () => clearInterval(timer);
    }, [state.counter]);

    const maskEmail = (email: string) => {
        var index = email.indexOf('@');
        if (index === -1)
            return;
        return email.substring(0, 2) + '****' + email.substring(index);
    };

    const sendOTP = async (values: any) => {
        try {
            if (!state.email) {
                setState(prev => ({ ...prev, userName: values.userName }));
            }
            setState(prev => ({ ...prev, otpLoader: true, counter: 0, isLoading: true }));
            const result = await sendOtpForUser(state.email ? state.userName : values.userName) as any;
            if (result?.data?.Status === 200) {
                setState(prev => ({ ...prev, otpLoader: false, counter: OTP_EXPIRATION_TIME, isLoading: false }));
                resetPasswordForm.resetFields();
            } else {
                openNotification({
                    notificationType: 'Error',
                    message: result?.data?.Message
                });
                setState(prev => ({ ...prev, otpLoader: false, isLoading: false }));
            }
        } catch (err) {
            openNotification({
                notificationType: 'Error',
                message: "Some error occurred. Please try again later or contact NAVPortfolio"
            });
            setState(prev => ({ ...prev, otpLoader: false, isLoading: false }));
        }
    };

    const handleResetPassword = async ({ values }: { values: any }) => {
        try {
            setState((prev: any) => ({ ...prev, isLoading: true }));
            if (R.prop('confirmPassword', values) !== R.prop('newPassword', values)) {
                setState((prev: any) => ({ ...prev, isLoading: false }));
                return openNotification({ notificationType: 'Error', message: "Confirm password must match new password" });
            }
            const result = await resetUserPassword({
                userName: state.userName,
                newPassword: R.prop('newPassword', values),
                otp: R.prop('otp', values),
            } as ResetPasswordRequest);
            if (result?.data?.Status === 200) {
                openNotification({ notificationType: 'Success', message: result?.data?.Message });
                window.location.replace('/')
            } else {
                openNotification({ notificationType: 'Error', message: result?.data?.Message });
            }
            setState((prev: any) => ({ ...prev, isLoading: false }));
        } catch (err) {
            setState((prev: any) => ({ ...prev, isLoading: false }));
        }
    };

    return {
        state,
        maskEmail,
        sendOTP,
        resetPasswordForm,
        otpForm,
        handleResetPassword,
    }
}

export default useForgotPassowrdHook;