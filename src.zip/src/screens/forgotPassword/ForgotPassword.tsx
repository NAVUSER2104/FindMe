/* eslint-disable react-hooks/exhaustive-deps */

//absolute imports
import React, { FC, } from 'react';
import { Row, Col, Input, Form, Button, Typography } from 'antd';
import { LockOutlined, MessageOutlined, UserOutlined } from '@ant-design/icons';

// relative imports
import { AjaxLoader } from 'components/loaders/AjaxLoader';
import { IPropsForgotPassword } from 'screens/forgotPassword/type';
import useForgotPassowrdHook from 'screens/forgotPassword/hooks/useForgotPasswordHook';

//Less & Icons
import 'assets/styles/screens/login.less';

const ForgotPassword: FC<IPropsForgotPassword> = (props: IPropsForgotPassword): JSX.Element => {
  const { state, maskEmail, sendOTP, resetPasswordForm, otpForm, handleResetPassword } = useForgotPassowrdHook(props);

  const sendOtpComponent = (
    <Form
      form={otpForm}
      name="sendOtp"
      className="signup-form"
      initialValues={{
        remember: true,
      }}
      onFinish={sendOTP}
    >
      <Form.Item >
        <Typography style={{ fontSize: '14px', color: 'grey' }}>
          An OTP {state.counter ? 'has been' : 'will be'} sent to your registered email {maskEmail(state.email)}
        </Typography>
      </Form.Item>
      {state.counter ? null : <div>
        {!state.email ?
          <Form.Item name="userName" initialValue={state.userName}
            rules={[{ required: true, message: 'Please input your user name!' }]}
          >
            <Input placeholder="Username" disabled={state.counter ? true : false} addonBefore={<UserOutlined className="site-form-item-icon" />}
            />
          </Form.Item> : null
        }
        < AjaxLoader isLoading={state.isLoading} />
        {state.counter ? null : <Form.Item>
          <Row gutter={[6, 6]}>
            <Col lg={12} md={12} sm={12} xs={12}>
              <Button disabled={state.isLoading} type="primary" htmlType="submit" size="large" className="w-100">
                Send OTP
              </Button>
            </Col>
            <Col lg={12} md={12} sm={12} xs={12}>
              <Button type="primary" className="w-100" size="large" onClick={() => window.location.replace('/')} >
                Back
              </Button>
            </Col>
          </Row>
        </Form.Item>}
      </div>}
    </Form>
  );

  const resetPasswordComponent = (
    <Form
      form={resetPasswordForm}
      name="forogotPassword"
      className="signup-form"
      initialValues={{
        remember: true,
      }}
      onFinish={async (values: any) => { await handleResetPassword({ values }) }}
    >
      <Form.Item style={{ color: '#0091ea', textAlign: 'center' }}> Time Remaining: {state.counter} seconds </Form.Item >
      {!state.email ?
        <Form.Item name="userName" initialValue={state.userName}
        >
          <Input placeholder="Username" disabled={true} addonBefore={<UserOutlined className="site-form-item-icon" />}
          />
        </Form.Item> : null
      }
      <Form.Item name="otp" rules={[{ required: true, message: 'Please enter OTP!' }]} >
        <Input.Password placeholder="OTP" addonBefore={<MessageOutlined className="site-form-item-icon" />} />
      </Form.Item>
      <Form.Item style={{ marginBottom: '5px', marginTop: '-20px' }}>
        <a style={{ color: '#0091ea', float: 'right' }}
          onClick={(async () => await sendOTP({ userName: state.userName }))}>
          Resend OTP</a>
      </Form.Item>

      <Form.Item name="newPassword" rules={[{ required: true, message: 'Please input your new password!' }]}
      >
        <Input.Password placeholder="New Password" addonBefore={<LockOutlined className="site-form-item-icon" />} />
      </Form.Item>
      <Form.Item name="confirmPassword"
        rules={[{ required: true, message: 'Please input your new password again!' }]}
      >
        <Input.Password placeholder="Confirm Password" addonBefore={<LockOutlined className="site-form-item-icon" />} />
      </Form.Item>
      < AjaxLoader isLoading={state.isLoading} />
      <Form.Item >
        <Row gutter={[6, 6]}>
          <Col lg={12} md={12} sm={12} xs={12}>
            <Button disabled={state.isLoading} type="primary" htmlType="submit" size="large" className="w-100">
              Change Password
            </Button>
          </Col>
          <Col lg={12} md={12} sm={12} xs={12}>
            <Button type="primary" className="w-100" size="large" onClick={() => window.location.replace('/')} >
              Back
            </Button>
          </Col>
        </Row>
      </Form.Item>
    </Form>
  );

  return (
    <React.Fragment>
      <Row className="w-100 py-2">
        <Col md={12} lg={12} xl={12} className="flex-column mx-auto align-self-center" style={{ zIndex: 10 }}>
          <h2 className="login-title text-center py-1 text-primary text-uppercase mb-4 font-weight-light">Forgot Password </h2>
          {sendOtpComponent}
          {state.counter ? resetPasswordComponent : null}
        </Col>
      </Row>
    </React.Fragment>
  )
};

export default ForgotPassword;