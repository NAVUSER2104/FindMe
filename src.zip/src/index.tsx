// absolute import
import React from 'react';
import ReactDOM from 'react-dom';
import * as R from 'ramda';
import { ConnectedRouter } from 'connected-react-router';
import { store } from './redux/store';
import { Provider } from 'react-redux';
import config from 'react-global-configuration';
import { PersistGate } from 'redux-persist/integration/react';
import { persistStore } from 'redux-persist';

// relative imports
import App from 'App';
import reportWebVitals from 'reportWebVitals';
import History from 'helpers/history';
import * as appSettings from 'config/appSettings.json';

// LESS
import 'assets/styles/common/index.less';
import 'antd/dist/antd.less';
import 'assets/styles/common/app.less';
import 'assets/styles/common/common.less';
import 'assets/styles/themes/light.less';
import 'assets/styles/themes/dark.less';

const rootElement = document.getElementById('root');
config.set(R.path(['default'], appSettings));

let persistor = persistStore(store);

ReactDOM.render(
  <Provider store={store}>
    <PersistGate loading={null} persistor={persistor}>
      <ConnectedRouter history={History}>
        <App />
      </ConnectedRouter>
    </PersistGate>
  </Provider>,
  rootElement
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
