// absolute imports
import * as R from 'ramda';
import moment from "moment"
import { Application } from 'helpers/enum';
import { store } from 'redux/store';

const getKeyByValue = (object: any, value: any) => Object.keys(object).find(key => object[key] === value);

const isNullOrEmptyString = (value: any) => {
    if (typeof value === "string")
        return (value === null || value === undefined || value === "" || !(value || '').trim());
    else
        return (value === null || value === undefined || value === "" || !(value || ''));
};

const convertToObject = (key: string, data: Array<any>) => {
    let object: { [key: string]: any; } = {}
    R.forEach((item: any) => {
        let itemKey = item[key] as string;
        object[itemKey] = item;
    }, data);
    return object;
}

const convertToMap = (data: any, key: any) => {
    var dataMap = new Map();
    data.forEach((obj: any) => {
        dataMap.set(obj[key], obj);
    });
    return dataMap;
};

const getFundIdFromPartitionId = (partitionId: number) => {
    const a = partitionId / 1e8;
    return parseInt(a.toString());
}
const convertToObjectWithArrayValue = (key: string, data: Array<any>) => R.reduce((acc: any, val: any) =>
    ({ ...acc, [val[key]]: acc[R.toString(val[key])] ? [...acc[val[key]], val] : [val] }), {}, data);

const insertComma = (value: number) => value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

const getPreviousWorkday = () => {
    const today = moment().day();
    switch (today) {
        case 0:
        case 1:
        case 6:
            return moment().subtract(6, 'days').day(5).toString();
        default:
            return moment().day(today - 1).toString();
    }
}

const amountFormat = (value: any) => {
    let floatVal = parseFloat(value),
        number,
        integer,
        decimal,
        rgx;
    let decimalSym = ".";
    let thousandSym = ",";
    let precision = 2;

    if (isNaN(floatVal)) {
        return "";
    }

    number = floatVal.toFixed(precision);
    number = String(number).split(".");
    integer = number[0];
    decimal = number.length > 1 ? decimalSym + number[1] : "";
    rgx = /(\d+)(\d{3})/;

    while (rgx.test(integer)) {
        integer = integer.replace(rgx, "$1" + thousandSym + "$2");
    }
    return floatVal < 0 ? `(${integer.replace("-", "")}${decimal})` : `${integer}${decimal}`;
};

const convertToBillion = (number: number) => parseFloat((number / 1.0e+9).toFixed(2));

const convertToMillion = (number: number) => parseFloat((number / 1000000).toFixed(2));

const numberFormattor = (num: number) => {
    if (Math.abs(num) > 1.0e+9)
        return { number: ((Math.abs(num) / (1.0e+9)).toFixed(2)), sign: 'bn' }
    else if (Math.abs(num) > 1.0e+6)
        return { number: ((Math.abs(num) / (1.0e+6)).toFixed(2)), sign: 'mn' }
    else if (Math.abs(num) > 1.0e+3)
        return { number: ((Math.abs(num) / (1.0e+3)).toFixed(2)), sign: 'k' }
    else
        return { number: 0, sign: "k" }
}

const getLandingPage = () => {
    const { persistReducer } = store.getState();
    switch (persistReducer.application) {
        case Application.NAVMain2: return '/Dashboard';
        default: return '/Dashboard';
    }
}
export const DataHelpers = {
    getKeyByValue,
    isNullOrEmptyString,
    convertToObject,
    convertToMap,
    getFundIdFromPartitionId,
    convertToObjectWithArrayValue,
    insertComma,
    getPreviousWorkday,
    amountFormat,
    convertToBillion,
    convertToMillion,
    numberFormattor,
    getLandingPage
};

export default DataHelpers;