const R = require('ramda');
/* In JavaScript, a `truthy` value is a value that is considered true
 * when evaluated in a Boolean context. All values are truthy unless
 * they are defined as falsy (i.e., except for `false`, `0`, `""`, `null`, `undefined`, and `NaN`).
 */
const isTruthy = R.curryN(1, Boolean);
const isFalsy = R.complement(isTruthy);
const compact = R.reject(isFalsy); // similar to lodash compact

const empty = R.either(R.isNil, R.isEmpty); // return true for [],{}, null.'',undefined etc.

const mapIndexed = R.addIndex(R.map);  //(val, idx) => use val and idx

export const RamdaExtensions = {
    compact,
    empty,
    mapIndexed
}
export default RamdaExtensions;