import { MenuTheme } from "antd";
import { Themes } from "components/title/type";

export const getColorPalette = (theme: MenuTheme) => {

    let prefix = `--${theme}-theme`
    let styles = getComputedStyle(document.documentElement)
    let red = styles.getPropertyValue(`${prefix}-red`),
        green = styles.getPropertyValue(`${prefix}-green`),
        orange = styles.getPropertyValue(`${prefix}-orange`),
        yellow = styles.getPropertyValue(`${prefix}-yellow`),
        black = styles.getPropertyValue(`${prefix}-black`),
        white = styles.getPropertyValue(`${prefix}-white`),
        blue = styles.getPropertyValue(`${prefix}-blue`);

    let defaultColor = theme === Themes.DARK ? white : black

    return {
        red, green, orange, yellow, black, white, blue, defaultColor
    }

}