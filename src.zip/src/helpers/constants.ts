// HttpVerb Constants
export const HTTP_OK = 200
export const HTTP_CREATED = 201
export const HTTP_BADREQUEST = 400
export const HTTP_UNAUTHORIZED = 401
export const HTTP_FORBIDDEN = 403
export const HTTP_NOTFOUND = 404
export const HTTP_INVALIDARGUMENT = 406
export const HTTP_INTERNAL_SERVER_ERROR = 500


//Token Constants
export const TOKEN_MISSING = 601
export const TOKEN_EXPIRED = 602
export const TOKEN_INVALID = 603


//Register Response
export const USERNAME_EXISTS = "U01"
export const EMAIL_EXISTS = "U02"

// Funds Selection Limit ComboBox
export const MAX_ALLOWED_FUND_SELECTION_COUNT = 100;

export const PercentFormatTags = new Set(["Gross Intensive Fee ROR", "Gross of Operating Expense ROR", "Gross ROR", "Net ROR", "Portfolio ROR",
    "Realized+Unrealized Gain ROR", "Trading Level Net ROR", "Trading Level Portfolio ROR"]);


export const Applications = [{
    key: -1,
    text: "Select Application",
    value: -1
},
{
    key: 1,
    text: "NAVMain2",
    value: 1
},
{
    key: 2,
    text: "NAVMain",
    value: 2
},
{
    key: 3,
    text: "NAVMDM",
    value: 3
}];

