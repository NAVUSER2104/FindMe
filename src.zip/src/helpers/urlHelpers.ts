// import because of type related issue
const queryString = require('query-string');

const getParamsString = (params: object) => queryString.stringify(params);

const prepareRelativeUrl = (relativeUrl: string, params: object) => {
   
    let paramsString = getParamsString(params)
    return paramsString !== '' ? `${relativeUrl}?${paramsString}` : relativeUrl;
}

export const UrlHelpers = {
    getParamsString,
    prepareRelativeUrl,
};

export default UrlHelpers;