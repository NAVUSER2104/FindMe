// absolute imports
import moment from 'moment';
import * as R from 'ramda';

// relative imports
import { DateComparatorResults } from 'helpers/enum';

const getCopyrightYear = () => new Date().getFullYear();

const dateFormat = {
    MMDDYYYY: "MM/DD/YYYY",
}

const DateFormatEnum = {
    "MM/DD/YYYY HH:mm:ss": 0,
    "YYYY-MM-DDTHH:mm:ss": 1,
    "YYYY-MM-DD": 2,
    "YYYY/MM/DD": 3,
    "MM/DD/YYYY": 4,
    "MM/DD/YYYY hh:mm:ss A": 5
};

const dates = {
    minDate: "01/01/1900",
    maxDate: "12/31/9998",
};

const formatDate = (datetime: Date | string | null, format: number = 0) => {
    switch (format) {
        case 0: return moment(datetime).format("MM/DD/YYYY HH:mm:ss");
        case 1: return moment(datetime).format("YYYY-MM-DDTHH:mm:ss");
        case 2: return moment(datetime).format("YYYY-MM-DD");
        case 3: return moment(datetime).format('YYYY/MM/DD');
        case 4: return moment(datetime).format('MM/DD/YYYY');
        case 5: return moment(datetime).format("MM/DD/YYYY hh:mm:ss A");
        case 6: return moment(datetime).format("MM-DD-YYYY");
        case 7: return moment(datetime).format("MM/DD/YYYY");
        default:
            return moment(datetime).format("MM/DD/YYYY HH:mm:ss");
    }
}


/**
 * date1: input first date
 * date2: input second date
 * betweenDate: passed when we want to check if date exists between date1, date2 :
 * granularityLevel: the level at which you want to compare the dates default to "day".
 */
type GranularityLevel = "year" | "month" | "week" | "isoWeek" | "day" | "hour" | "minute" | "second";
const dateComparator = (date1: string | Date, date2: string | Date, betweenDate: string | Date | null = null, granularityLevel: GranularityLevel = "day") => {
    if (betweenDate) {
        if (moment(betweenDate).isBetween(date1, date2) || moment(betweenDate).isBetween(date2, date1)) {
            return DateComparatorResults.DATE_IS_BETWEEN_DATE1_DATE2;
        }
        else {
            return DateComparatorResults.DATE_IS_NOT_BETWEEN_DATE1_DATE2;
        }
    }
    else {
        if (moment(date1).isBefore(date2, granularityLevel)) {
            return DateComparatorResults.DATE1_IS_LESS_THAN_DATE2;
        }
        else if (moment(date1).isAfter(date2, granularityLevel)) {
            return DateComparatorResults.DATE1_IS_GREATER_THAN_DATE2;
        }
        else if (moment(date1).isSame(date2, granularityLevel)) {
            return DateComparatorResults.DATE1_IS_EQUAL_TO_DATE2;
        }
    }
}

const getMaxDate = (dates: string[]) => {
    let moments = R.map((date: string) => (moment(date)), dates);
    if (moments.length > 0) {
        return moment.max(moments);
    }
    return null;

}

const getMinDate = (dates: string[]) => {
    let moments = R.map((date) => (moment(date)), dates);
    return moment.min(moments);
}


export const DateHelpers = {
    getCopyrightYear,
    formatDate,
    dateFormat,
    dates,
    dateComparator,
    DateFormatEnum,
    getMaxDate,
    getMinDate
};
export default DateHelpers;