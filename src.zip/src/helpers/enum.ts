export enum DefaultReporting {
    Daily = "daily",
    Periodic = "periodic"
}
enum FundRelationshipType {
    FOF = 0,
    MASTER_FEEDER = 1,
    STAND_ALONE = 2
}

enum DateComparatorResults {
    DATE1_IS_LESS_THAN_DATE2 = 1,
    DATE1_IS_GREATER_THAN_DATE2 = 2,
    DATE1_IS_EQUAL_TO_DATE2 = 3,
    DATE_IS_BETWEEN_DATE1_DATE2 = 4,
    DATE_IS_NOT_BETWEEN_DATE1_DATE2 = 5,
}

enum CheckStatus {
    CHECK_FAILED = 0,
    CHECK_PASSED = 1,
    WARNING_CHECK = 2
};

enum SignOffStatus {
    SIGN_OFF_PENDING = 0,
    SIGN_OFF_REQUEST_PLACED = 1,
    SIGNED_OFF = 2,
    DISCARD = 3
};

enum ChecksLevel {
    WARNING = 0,
    CRITICAL = 2
};

enum DateFormatEnum {
    MM_DD_YYYY_HH_mm_ss = 0,
    YYYY_MM_DDTHH_mm_ss = 1,
    YYYY_MM_DD_With_Hyphon = 2,
    YYYY_MM_DD_With_Slash = 3,
    MM_DD_YYYY = 4,
    MM_DD_YYYY_hh_mm_ss_A = 5,
    MM_DD_YYYY_With_Hyphon = 6,
    MM_DD_YYYY_With_Slash = 7,
};

enum PeriodType {
    DAILY = 1,
    PERIODIC = 2
};

enum YesOrNo {
    YES = 1,
    NO = 2
};

enum ValueFormatter {
    Amount = 0,
    Date = 1,
}

enum ReportingFrequencies {
    DTD = 1,
    WTD = 2,
    MTD = 3,
    YTD = 4,
    PTD = 5,
    QTD = 6,
    AsOnDate = 7,
    HTD = 8,
    ITD = 9,
    ITDEffective = 10
}

enum PermissionSet {
    EditValidationChecksConfiguration = 'Edit Validation Check Configuration'
}

enum EntityTypeComboOption {
    Investor = 4,
    Investment = 5
}

enum InvestorAttributeComboOption {
    NewIssueIncome = 1
}

enum InvestorClassAttributeComboOption {
    TaxStatus = 1004,
    LockUpDate = 1008,
    ManagementFee = 0,
    PerformanceFee = 1,
}
enum PermissionValue {
    ReadOnly = "Read-Only",
    ReadWrite = "Read-Write"
};

enum FundServicesEnum {
    Daily = 0 as number,
    Monthly = 1 as number,
    RTA = 2 as number,
    Wire = 3 as number,
    FS = 4 as number,
    Tax = 5 as number,
    FATCA = 6 as number,
    OneZeroNineNine = 7 as number
}

enum FundServiceValueEnum {
    yes = 'yes',
    no = 'no'
}


enum Application {
    NAVMain2 = "NAVMain2",
    NAVMain = "NAVMain",
    NAVMDM = "NAVMDM"
}

export {
    FundServicesEnum, FundServiceValueEnum, InvestorAttributeComboOption, InvestorClassAttributeComboOption,
    EntityTypeComboOption, PermissionValue, PermissionSet, FundRelationshipType, DateComparatorResults, DateFormatEnum,
    PeriodType, YesOrNo, ValueFormatter, ReportingFrequencies, ChecksLevel, CheckStatus, SignOffStatus, Application
};
