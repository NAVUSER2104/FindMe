import { createSlice } from "@reduxjs/toolkit";

// realtive imports
import { RootState } from 'redux/rootReducer';

export interface PersistState {
    application: string;
}

const initialState: PersistState = {
    application: ''
}

export const persistReducer = createSlice({
    name: 'persistReducer',
    initialState,
    reducers: {
        setApplication: (state, { payload }) => {
            state.application = payload
        },
    }
})

export const { setApplication } = persistReducer.actions

export const persistSelector = (state: RootState) => state.persistReducer