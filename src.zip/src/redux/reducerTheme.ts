import { createSlice, PayloadAction } from "@reduxjs/toolkit";

// realtive imports
import { RootState } from 'redux/rootReducer';
import { ThemeState } from "redux/type";
import { MenuTheme } from "antd";

const initialState: ThemeState = {
    theme: 'light',
    'fontFamily': '',
}

export const themeReducer = createSlice({
    name: 'theme',
    initialState,
    reducers: {
        setTheme: (state, { payload }: PayloadAction<MenuTheme>) => {
            state.theme = payload
        },
        setFont: (state, { payload }: PayloadAction<String>) => {
            state.fontFamily = payload
        }
    }
})

export const { setTheme, setFont } = themeReducer.actions

export const themeSelector = (state: RootState) => state.themeReducer