import { MenuTheme } from "antd";

export interface ThemeState {
    theme: MenuTheme;
    'fontFamily'?: String;
}