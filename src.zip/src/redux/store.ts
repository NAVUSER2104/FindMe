// absolute imports 
import { configureStore } from '@reduxjs/toolkit'
import { useDispatch } from 'react-redux'
import storage from 'redux-persist/lib/storage';
import { persistReducer } from 'redux-persist';
import thunk from 'redux-thunk';
import { parse, stringify } from 'flatted';

// relative imports
import rootReducer from './rootReducer'
import createTransform from 'redux-persist/es/createTransform';


export const FlatTransform = createTransform(
    (inboundState, key) => stringify(inboundState),
    (outboundState, key) => parse(outboundState),
)

const persistConfig = {
    key: 'root',
    storage,
    whitelist: ['persistReducer'],
    transforms: [FlatTransform]
};
const persistedReducer = persistReducer(persistConfig, rootReducer);
export const store = configureStore({
    reducer: persistedReducer,
    devTools: process.env.NODE_ENV !== 'production',
    middleware: [thunk]
});

export type AppDispatch = typeof store.dispatch
export const useAppDispatch = () => useDispatch()
