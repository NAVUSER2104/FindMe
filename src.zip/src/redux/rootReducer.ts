// absolute imports
import { combineReducers } from '@reduxjs/toolkit';
import { createBrowserHistory } from 'history';
import { connectRouter } from 'connected-react-router';
import { persistReducer } from 'redux/reducerPersist';
import { themeReducer } from 'redux/reducerTheme';
import { sidebarReducer } from 'components/navigations/reducerSidebar';
import { alertReducer } from 'components/alerts/reducerAlert';

// relative imports
 
import { dashboardReducer } from 'screens/dashboard/reducerDashboard'; 
import { loginReducer } from 'screens/login/reducerLogin';
import { setDefaultReducer } from 'screens/setDefaults/reducerSetDefault';

export const history = createBrowserHistory();

const reducers = {  
  loginReducer: loginReducer.reducer,
  dashboardReducer: dashboardReducer.reducer,
  persistReducer: persistReducer.reducer,
  themeReducer: themeReducer.reducer,
  sidebarReducer: sidebarReducer.reducer,
  alertReducer: alertReducer.reducer,
  setDefaultReducer: setDefaultReducer.reducer
};

const rootReducer = combineReducers({
  router: connectRouter(history),
  ...reducers,
})

export type RootState = ReturnType<typeof rootReducer>

export default rootReducer