// absolute imports
import React, { lazy, Suspense, FC, useLayoutEffect, useEffect } from 'react';
import { Switch } from 'react-router-dom';

// relative imports
import { AjaxLoader } from 'components/loaders/AjaxLoader';
import LoginHelpers from 'screens/common/login/hooks/useLoginHook';
import Authentication from 'components/hoc/auth/RequireAuth';
import GoogleFontLoader from 'assets/fonts/GoogleLoader';

// layouts
const MainLayout = lazy(() => import('components/layouts/MainLayout'));
const EmptyLayout = lazy(() => import('components/layouts/EmptyLayout'));
const RouteWithLayout = lazy(() => import('components/layouts/RouteWithLayout'));

// components & screens
const LoginLayoutScreen = lazy(() => import('components/layouts/LoginLayout'));
const DashboardScreen = lazy(() => import('screens/dashboard/Dashboard'));
const ApiStatusScreen = lazy(() => import('screens/apiStatus/ApiStatus'));

const App: FC = () => {

  useLayoutEffect(() => {
    LoginHelpers().autoLogin()
  }, [])

  return (
    <React.Fragment>
      <GoogleFontLoader />
      <Suspense fallback={<AjaxLoader isLoading />}>
        <EmptyLayout>
          <Switch>
            {/* Unprotected Routes */}
            <RouteWithLayout exact path="/" Component={LoginLayoutScreen} />
            <RouteWithLayout exact path="/login" Component={LoginLayoutScreen} />
          </Switch>
        </EmptyLayout>
        <Suspense fallback={<MainLayout></MainLayout>}>
          <MainLayout>
            <Switch>
              {/* Protected Routes */}
              
              <RouteWithLayout exact path='/Dashboard' Component={DashboardScreen} /> 
              <RouteWithLayout exact path='/ApiStatus' Component={ApiStatusScreen} /> 
            </Switch>
          </MainLayout>
        </Suspense >
      </Suspense>
    </React.Fragment >
  );
}

export default App;
