import { useEffect } from 'react';
import { useSelector } from 'react-redux';
import * as R from 'ramda';

import { themeSelector } from 'redux/reducerTheme';

const GoogleFontLoader: any = (props: any) => {
    const { fontFamily } = useSelector(themeSelector) as any;
    let link: any = null;

    const createLink = () => {
        const fonts = getUserFonts();
        const families = fonts.reduce((acc: any, font: any) => {
            const family = font.font.replace(/ +/g, '+');
            const weights = font.weights.join(',');
            acc.push(`${family}:${weights}`);
            return acc;
        }, []).join('|');
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = `https://fonts.googleapis.com/css?family=${families}`;
        return link;
    };

    const appendLink = () => document.head.appendChild(link);

    const removeLink = () => document.head.removeChild(link);

    const replaceLink = () => {
        removeLink();
        link = createLink();
        appendLink();
    };

    useEffect(() => {
        link = createLink();
        appendLink();
    }, [fontFamily]);

    const getUserFonts = () => {
        let googleFonts = [{
            font: "Roboto",
            weights: [300, '300i', 400, '400i', '500i', 700, '700i', 900]
        }];
        const googleFontsWeight = [300, '300i', 400, '400i', '500i', 700, '700i', 900];
        if (fontFamily) {
            document.documentElement.style.setProperty('--font-family', `${fontFamily}, sans-serif`);
            const fontFamilyArr = fontFamily.split(',');
            R.forEach((fontName: any) => {
                googleFonts.push({
                    font: fontName.trim(),
                    weights: googleFontsWeight
                });
            }, fontFamilyArr);
        }
        return googleFonts;
    };
    return () => null;
};

export default GoogleFontLoader;
